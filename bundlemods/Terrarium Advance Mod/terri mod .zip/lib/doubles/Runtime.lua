-- Optional encounter-boundary integration. Singles do not enter this module's
-- move, input, reward or presentation paths when the option is disabled.
local V=...
local req=V.engineRequire or require
local D={version=1,serial=0,byState=setmetatable({},{__mode='k'}),lastSkip=nil}
local function clone(t,seen)
  if type(t)~='table' then return t end
  seen=seen or {};if seen[t] then return seen[t] end
  local n={};seen[t]=n;for k,v in pairs(t) do n[k]=clone(v,seen) end;return n
end
local function live(m) return V.DoublesCore.healthy(m) end
local function log(s)
  if V.mod.log then V.mod.log:info('Colosseum doubles: '..tostring(s)) end
end
function D.session(value)
  if not value then return D.active end
  local direct=D.byState[value];if direct then return direct end
  if type(value)=='table' then
    -- A later SINGLE battle uses the same game object. Never lend it the
    -- previous doubles command/replacement state just because that game matches.
    return D.byState[value._model] or D.byState[value._view] or D.byState[value.battle]
      or D.byState[value.__gen3Source]
  end
end
function D.combat(value)
  local s=D.session(value)
  return s and not s.handoff and not s.progressing and not s.closed and s or nil
end
-- World presentation stays four-actor while native progression owns its UI.
-- The command/UI service deliberately returns nil during that same interval.
function D.presentation(value)
  local s=D.session(value)
  return s and not s.handoff and not s.closed and s or nil
end
local function consumer(game)
  -- Colosseum Overhaul merge: CBE and its paired UI are now one mod, so
  -- V.mod already IS the mod whose install function sets
  -- mod.exports.doublesUI (formerly a separate mod found by id string).
  local api=V.mod and V.mod.exports and V.mod.exports.doublesUI
  if type(api)~='table' or api.version~=1 or type(api.input)~='function' then return nil,'Paired doubles UI is not installed' end
  if type(api.ready)=='function' then
    local ok,ready=pcall(api.ready,game)
    if not ok or not ready then return nil,'Enable Colosseum Battle UI before starting doubles' end
  end
  return api
end
local function eligible(screen,generation)
  local host=generation==2 and screen.battle or screen
  local game=screen.game
  local p=game and game.save and ((V.BattleSettings and V.BattleSettings.prefs(game)) or game.save.colosseumBattle)
  if not (p and p.doubleBattlesEnabled==true) then return false end
  
  -- Check if engine is already in double battle mode
  local isDoubleBattle = false
  
  -- Gen 3: Check for native double battle indicators
  if generation==3 then
    -- The native engine's real flag is `self.double` (see BattleState:isDouble()
    -- in src/battle/BattleState.lua) -- not `doubleBattle`/`isDoubleBattle`,
    -- which nothing in the engine ever sets, and not `battleType`, which
    -- holds strings like "roaming"/"suicune" rather than a doubles marker.
    -- Those three checks never matched anything real; eligibility was
    -- riding on the enemyParty>=2 guess alone, which also fires for an
    -- ordinary single battle against any trainer with a full team. Check the
    -- real flag first and keep the guess only as a fallback for battles that
    -- reach here before `double` is set.
    isDoubleBattle = host.double == true or
                     (type(host.isDouble)=='function' and host:isDouble()) or
                     (host.kind=='trainer' and host.enemyParty and #host.enemyParty>=2)
  -- Gen 2: Check for double battle indicators  
  elseif generation==2 then
    isDoubleBattle = (host.doubleBattle == true) or 
                     (host.isDoubleBattle == true) or
                     (host.kind=='trainer' and host.enemyParty and #host.enemyParty>=2)
  -- Gen 1: Use original logic
  else
    isDoubleBattle = (host.kind=='trainer' and host.enemyParty and #host.enemyParty>=2)
  end
  
  if not isDoubleBattle then return false end
  
  -- Relax the other conditions - just check basic battle validity
  if generation==2 then
    if host.wild or host.linkBattle then return false end
  elseif host.kind~='trainer' or host.demo or host.ghost or host.link or host.spectator then return false end
  
  if p.arenasEnabled==false then return false,'Double battles require Colosseum Arenas ON' end
  local api,why=consumer(game);if not api then return false,why end
  return true,api
end
local function openingBoundary(screen,generation)
  if type(screen)~='table' then return false end
  local arena=V.StandaloneHost and V.StandaloneHost.session
  -- More permissive opening boundary - accept arena OR native double battle start
  local arenaMatch = arena and arena.started and (arena.battle==screen
    or (V.GenerationCompat and V.GenerationCompat.matches and V.GenerationCompat.matches(arena.battle,screen)))
  
  -- For all generations, accept native double battle phases even without arena
  local nativeDoubleStart = false
  if generation==3 then
    nativeDoubleStart = (screen.phase=='messages' and screen.showPlayerBack==true and screen.showEnemyTrainer==true)
  elseif generation==2 then
    nativeDoubleStart = (screen.phase=='intro' and screen.showPlayerTrainer==true)
  else
    nativeDoubleStart = (screen.phase=='messages' and screen.showPlayerBack==true and screen.showEnemyTrainer==true)
  end
  
  -- Make arena optional - if native double battle is detected, accept it even without arena
  return nativeDoubleStart or arenaMatch or false
end
-- Draw can occur once after the native battle screen enters its opening state
-- but before the next BattleState:update call gives doubles ownership to
-- tryBegin(). During that gap Gen II in particular may already have an enemy
-- singles actor resident while only the player trainer flag is still visible.
-- Expose a read-only predicate so CurrentSpriteModels can cover BOTH native
-- picture slots while drawing neither actor. This does not advance the battle,
-- acquire resources, or commit a doubles decision.
function D.openingPending(value,generation)
  local screen=value
  if V.GenerationCompat and V.GenerationCompat.view then
    local view=V.GenerationCompat.view(value)
    if view then screen=view end
  end
  if type(screen)~='table' or screen.__cbeDoublesActive then return false end
  generation=generation or ((type(value)=='table' and value.__cbeGeneration==2) and 2)
    or ((type(value)=='table' and value.__cbeGeneration==3) and 3)
    or ((screen.battle and screen.battle~=screen) and 2) or 1
  if not openingBoundary(screen,generation) then return false end
  local ok=eligible(screen,generation)
  return ok==true
end
function D.tryBegin(screen,generation)
  if screen.__cbeDoublesDecision~=nil then return nil end
  local opening=openingBoundary(screen,generation)
  if screen.phase~='menu' and not opening then return nil end
  local ok,api=eligible(screen,generation)
  screen.__cbeDoublesDecision=ok==true
  if not ok then if type(api)=='string' then D.lastSkip=api;log(api) end;return nil end
  local host=generation==2 and screen.battle or screen
  -- Gen 3 uses the same party structure as Gen 1
  local party=generation==2 and host.party or (host.game and host.game.save and host.game.save.party)
  local ready=false;for _,m in ipairs(party) do if live(m) then ready=true end end
  if not ready then return nil end
  D.serial=D.serial+1
  local backup={player={},enemy={}}
  for i,m in ipairs(party) do backup.player[i]=clone(m) end
  for i,m in ipairs(host.enemyParty) do backup.enemy[i]=clone(m) end
  local itemSave=host.__cbeMtBattleItemSave or screen.game.save
  backup.itemSave=itemSave
  backup.inventory=clone(itemSave and itemSave.inventory);backup.bagOrder=clone(itemSave and itemSave.bagOrder)
  backup.itemSaveFields={}
  for _,key in ipairs({'pikachuHappiness','pikachuMood','pikachuEmotionModifier'})do
    backup.itemSaveFields[key]={value=screen.game.save[key]}
  end
  local oldAmuletCoin=host.amuletCoin
  local adapter=V.DoublesNativeAdapter.new(host,generation)
  adapter.screen=screen
  local pi=generation==2 and host.playerIndex or nil
  -- Gen 3 uses the same playerIndex logic as Gen 1
  if not pi then for i,m in ipairs(party) do if host.player and host.player.mon==m then pi=i end end end
  local core=V.DoublesCore.new{adapter=adapter,id='cbe-double-'..D.serial,generation=generation,
    playerParty=party,enemyParty=host.enemyParty,playerIndex=pi,enemyIndex=host.enemyIndex,
    groupedOpening=opening==true,openingText=opening and (screen.introText or ((host.trainer and host.trainer.name or 'Opponent')..' wants to battle!')) or nil,
    rng=host.rng or math.random}
  local s={screen=screen,host=host,generation=generation,core=core,adapter=adapter,consumer=api,
    backup=backup,oldPlayer=host.player,oldEnemy=host.enemy,oldPlayerIndex=host.playerIndex,
    oldEnemyIndex=host.enemyIndex,oldAmuletCoin=oldAmuletCoin,inputHeld={},awardIndex=1,groupedOpening=opening==true,
    actorPreflight=true,actorPreflightAge=0}
  core.sourceMoveFX=V.DoublesMovePresentation~=nil
  if opening then
    -- Take over before either native singles sendout. Retain the opening queue
    -- for the explicit test-abort path; ordinary native turns never consume it.
    s.openingState={}
    for _,key in ipairs({'phase','queue','message','shown','msgHold','nextInsert','waitFrames','afterQueue','showEnemyTrainer','showPlayerBack','showPlayerTrainer','introBalls','startHuds','ballRows','showEnemyHud','showPlayerHud'})do
      s.openingState[key]={value=screen[key]}
    end
    screen.queue={};screen.message=nil;screen.shown=nil;screen.msgHold=nil
    screen.showEnemyTrainer=false;screen.showPlayerBack=false;screen.showPlayerTrainer=false;screen.introBalls=nil
    screen.startHuds=nil;screen.ballRows={player=false,enemy=false};screen.showEnemyHud=false;screen.showPlayerHud=false
  end
  screen.__cbeDoublesActive=true;host.__cbeDoublesActive=true
  D.byState[screen]=s;D.byState[host]=s;D.active=s
  screen.phase='cbe_doubles'
  if V.DoublesPresenter then V.DoublesPresenter.begin(s) end
  core.onEvent=function(e) if V.DoublesPresenter then V.DoublesPresenter.event(s,e) end end
  core.onProgression=function(phase)
    -- Allow progression even if no defeated enemies (for completion)
    if s.awardIndex>#core.defeated and #core.defeated>0 then return false end
    D.startProgression(s,phase);return true
  end
  log(core.id..' started: generation '..generation..', trainer party '..#host.enemyParty)
  return s
end
function D.close(s)
  if not s or s.closed then return end
  s.closed=true
  if s.core and type(s.core.targetDiagnostics)=='function' then
    D.lastTargetDiagnostics={battleId=s.core.id,rows=s.core:targetDiagnostics()}
  end
  if s.progressGuards then
    s.screen.advanceQueue=s.progressGuards.advanceQueue
    s.screen.submit=s.progressGuards.submit
    s.progressGuards=nil
  end
  s.screen.__cbeDoublesProgressing=nil;s.host.__cbeDoublesProgressing=nil
  if V.DoublesPresenter then V.DoublesPresenter.finish(s) end
  s.screen.__cbeDoublesActive=nil;s.host.__cbeDoublesActive=nil
  D.byState[s.screen]=nil;D.byState[s.host]=nil
  if D.active==s then D.active=nil end
end
local function restoreRecord(dst,src)
  for k in pairs(dst) do dst[k]=nil end
  for k,v in pairs(clone(src)) do dst[k]=v end
end
function D.abort(s)
  if not s or s.handoff or s.rewardsStarted then return false,'Progression has committed; reload the pre-battle save rather than rolling it back.' end
  for i,m in ipairs(s.core.playerParty) do restoreRecord(m,s.backup.player[i]) end
  for i,m in ipairs(s.core.enemyParty) do restoreRecord(m,s.backup.enemy[i]) end
  local host=s.host
  local itemSave=s.backup.itemSave or s.screen.game.save
  if s.backup.inventory then itemSave.inventory=clone(s.backup.inventory) end
  itemSave.bagOrder=clone(s.backup.bagOrder)
  for key,row in pairs(s.backup.itemSaveFields or {})do s.screen.game.save[key]=row.value end
  host.amuletCoin=s.oldAmuletCoin
  host.player=s.oldPlayer;host.enemy=s.oldEnemy;host.playerIndex=s.oldPlayerIndex;host.enemyIndex=s.oldEnemyIndex
  if s.generation==1 or s.generation==3 then
    host.player=s.adapter.native.makeBattler(host.data,s.oldPlayer.mon,true,host.game.save)
    host.enemy=s.adapter.native.makeBattler(host.data,s.oldEnemy.mon,false)
  end
  s.screen.phase='menu';s.screen.__cbeDoublesDecision=false
  if s.openingState then for key,row in pairs(s.openingState)do s.screen[key]=row.value end end
  D.close(s);log('Encounter restored to its initial single-battle command state after test abort')
  return true
end
local function resetNativeQueue(s)
  local screen=s.screen
  screen.queue={};screen.current=nil;screen.message=nil;screen.shown=nil;screen.msgHold=nil
  screen.messagePages=nil;screen.messageCarry=nil
  screen.nextInsert=0;screen.waitFrames=nil;screen.afterQueue='menu'
  screen.waitingUI=nil;screen.waitingSound=nil;screen.waitSoundLeft=nil
  screen.animPlaying=false;screen.anim=nil;screen.pendingHit=nil
  screen.pendingSendOut=nil;screen.afterSendOut=nil;screen.shiftSwitchIndex=nil
end
local function bindNativeView(s)
  local core,host=s.core,s.host
  local player=core:aliveSlots('player')[1]
  if not player then
    for _,id in ipairs({'player-left','player-right'}) do
      if core.slots[id].mon then player=core.slots[id];break end
    end
  end
  if player then
    if s.generation==2 then
      -- For Gen 2, use battler if available, otherwise construct one
      if player.battler then
        host.player=player.battler
      else
        local def=host.data and host.data.pokemon and host.data.pokemon[player.mon.species]
        host.player={
          mon=player.mon,
          def=def,
          name=player.mon.nickname or (def and def.name) or tostring(player.mon.species or '?'),
          species=player.mon.species,
          isPlayer=true,
          badges=host.game and host.game.save and host.game.save.inventory,
          badgeBoosts=host.data and host.data.constants and host.data.constants.badgeBoosts,
          statuses=host.data and host.data.statuses,
          items=host.data and host.data.items,
          natures=host.data and host.data.constants and host.data.constants.natures,
          shownHP=player.mon.hp,
          shownStatus=player.mon.status,
          stages=player.stages or {},
          curStats=player.mon.stats,
          curTypes=def and def.types,
          curMoves=player.mon.moves,
        }
      end
    else
      host.player=player.battler
    end
    host.playerIndex=player.partyIndex
  end
  host.turn=(s.generation==2 and core.turn or host.turn);host.turnCount=core.turn
  if type(host.syncSides)=='function' then host:syncSides() end
end
local function installProgressGuards(s)
  if s.progressGuards or s.generation~=2 then return end
  local screen=s.screen
  s.progressGuards={advanceQueue=rawget(screen,'advanceQueue'),submit=rawget(screen,'submit')}
  local advance=screen.advanceQueue;local submit=screen.submit
  screen.advanceQueue=function(view,...)
    if not s.closed and (s.progressing or s.handoff) and not s.finalizing and #(view.queue or {})==0
        and not (s.host.over) then
      -- Queue completion is a continuation, NEVER Gen II's CheckPlayerLockedIn
      -- -> automatic submit path. Do not clear the real charge/rampage state.
      if type(view.syncShownStatus)=='function' then view:syncShownStatus() end
      view.phase='cbe_progression_idle';view.message=nil
      return
    end
    return advance(view,...)
  end
  screen.submit=function(view,...)
    if not s.closed and (s.progressing or s.handoff) then
      error('Native singles combat submission blocked during doubles progression',0)
    end
    return submit(view,...)
  end
end
function D.startProgression(s,resume)
  assert(not s.progressing,'Doubles progression is already active')
  s.progressing=true;s.rewardResume=resume;s.core.phase='progression';s.core:bump()
  s.progressSaved={player=s.host.player,enemy=s.host.enemy,playerIndex=s.host.playerIndex,
    enemyIndex=s.host.enemyIndex,participants=s.host.participants,events=s.host.events}
  s.screen.__cbeDoublesProgressing=true;s.host.__cbeDoublesProgressing=true
  installProgressGuards(s);bindNativeView(s);resetNativeQueue(s)
  s.screen.phase='cbe_progression_idle'
  -- Start immediately: no transient singles command screen is rendered.
  D.rewardStep(s)
end
local function restoreProgressView(s)
  local saved=s.progressSaved
  if saved then
    for _,key in ipairs({'player','enemy','playerIndex','enemyIndex','participants','events'}) do s.host[key]=saved[key] end
    if type(s.host.syncSides)=='function' then s.host:syncSides() end
  end
  s.progressSaved=nil;s.progressing=nil
  s.screen.__cbeDoublesProgressing=nil;s.host.__cbeDoublesProgressing=nil
  s.screen.phase='cbe_doubles'
  -- Do not replay the A/B edge which dismissed the final native dialog as a
  -- doubles command. The normal edge detector rearms after the button lifts.
  local input=s.screen.game.input
  for _,key in ipairs({'a','b','start','select'}) do
    s.inputHeld[key]=(input and input.isDown and input:isDown(key))
      or (input and input.wasPressed and input:wasPressed(key)) or false
  end
end
function D.startHandoff(s)
  if s.handoff then return end
  s.handoff=true
  if V.DoublesPresenter then V.DoublesPresenter.finish(s) end
  bindNativeView(s)
  local last=s.core.defeated[#s.core.defeated]
  if last then
    if s.generation==2 then
      if last.battler then
        s.host.enemy=last.battler
      else
        -- Construct a minimal battler object for rendering
        local def=s.host.data and s.host.data.pokemon and s.host.data.pokemon[last.mon.species]
        s.host.enemy={
          mon=last.mon,
          def=def,
          name=last.mon.nickname or (def and def.name) or tostring(last.mon.species or '?'),
          species=last.mon.species,
          isPlayer=false,
          shownHP=last.mon.hp,
          shownStatus=last.mon.status,
          curStats=last.mon.stats,
          curTypes=def and def.types,
        }
      end
    else
      s.host.enemy=last.battler
    end
    s.host.enemyIndex=last.partyIndex or s.host.enemyIndex
  end
  s.host.payDay=s.adapter.k.payDay or s.host.payDay
  s.host.payDayMoney=s.adapter.k.payDayMoney or s.host.payDayMoney
  installProgressGuards(s);resetNativeQueue(s);s.screen.phase='cbe_progression_idle'
end
local function awardOne(s,defeated)
  local core,host,screen=s.core,s.host,s.screen
  assert(defeated.rewardState~='started','An interrupted EXP award cannot be replayed safely')
  defeated.rewardState='started';s.rewardCurrent=defeated;s.rewardsStarted=true
  s.rewardLevels={};for _,m in ipairs(core.playerParty) do s.rewardLevels[m]=m.level end
  host.participants={}
  for mon in pairs(defeated.participants or {}) do
    -- The controller captured eligibility at this KO. No later-turn HP filter
    -- is permitted here; live combat is suspended until this queue completes.
    if mon then host.participants[mon]=true end
  end
  -- Debug: check if participants table is being populated
  if next(host.participants) == nil then
    -- Fallback: use all alive player Pokemon as participants
    for _,m in ipairs(core.playerParty) do
      if healthy(m) then host.participants[m]=true end
    end
  end
  -- Debug logging
  if not host.game or not host.game.save then
    error("Host game or save not available for experience awarding",0)
  end
  -- For Gen 2, construct a battler object if we only have the mon
  if s.generation==2 then
    if defeated.battler then
      host.enemy=defeated.battler
    else
      -- Construct a minimal battler object for rendering and exp calculation
      local def=host.data and host.data.pokemon and host.data.pokemon[defeated.mon.species]
      host.enemy={
        mon=defeated.mon,
        def=def,
        name=defeated.mon.nickname or (def and def.name) or tostring(defeated.mon.species or '?'),
        species=defeated.mon.species,
        isPlayer=false,
        shownHP=defeated.mon.hp,
        shownStatus=defeated.mon.status,
        curStats=defeated.mon.stats,
        curTypes=def and def.types,
      }
    end
  else
    host.enemy=defeated.battler
  end
  host.enemyIndex=defeated.partyIndex or host.enemyIndex
  resetNativeQueue(s)
  if s.generation==2 then
    host.events={}
    -- Use awardExperience for Gen 2 (the original mod uses this)
    if type(host.awardExperience)=='function' then
      local ok,err=pcall(host.awardExperience,host,defeated.mon)
      if not ok then error(err,0) end
    elseif type(host.awardExp)=='function' then
      local ok,err=pcall(host.awardExp,host,defeated.mon)
      if not ok then error(err,0) end
    else
      -- Fallback: use Gen 1/3 experience logic
      local player=host.player
      if next(host.participants)==nil and player and player.mon and (player.mon.hp or 0)>0 then
        local facade={};for k,v in pairs(player) do facade[k]=v end
        facade.mon=setmetatable({hp=0},{__index=player.mon});host.player=facade
      end
      local ok,err=pcall(host.awardExp,host);host.player=player
      if not ok then error(err,0) end
    end
    -- Use Gen 1/3 approach for event handling
    screen.phase='messages';screen.afterQueue='menu'
  else
    -- Gen 1 and Gen 3 use the same experience awarding logic
    -- With zero participants the native singles helper pays its current user.
    -- That fallback is not legal for doubles. A call-local read-only view
    -- suppresses ONLY that fallback, without writing any real Pokemon's HP,
    -- bypassing EXP.ALL, replacing applyShare, or changing deferred commits.
    local player=host.player
    if next(host.participants)==nil and player and player.mon and (player.mon.hp or 0)>0 then
      local facade={};for k,v in pairs(player) do facade[k]=v end
      facade.mon=setmetatable({hp=0},{__index=player.mon});host.player=facade
    end
    local ok,err=pcall(host.awardExp,host);host.player=player
    if not ok then error(err,0) end
    screen.phase='messages';screen.afterQueue='menu'
  end
end
local function finishNative(s)
  if s.finalizing then return false end
  local core,host,screen=s.core,s.host,s.screen
  s.finalizing=true;resetNativeQueue(s)
  if s.generation==2 then
    host.events={}
    if core.outcome=='win' then
      -- Reuse native prize/Pay Day/result semantics while excluding the final
      -- already-presented faint and its already-settled EXP. Both temporary
      -- interceptors are restored even if the native handler raises an error.
      local rt=req('src.mods.Runtime')
      local oldAward,oldEmit,oldPublic=host.awardExperience or host.awardExp,host.emit,rt.emit
      if type(host.awardExperience)=='function' then
        host.awardExperience=function() end
      elseif type(host.awardExp)=='function' then
        host.awardExp=function() end
      end
      host.emit=function(h,e,...) if e.kind=='faint' then return e end;return oldEmit(h,e,...) end
      rt.emit=function(name,e,...) if name=='battle.fainted' and e and e.battle==host then return end;return oldPublic(name,e,...) end
      -- Call enemyMonFainted instead of resolveFaints (which doesn't exist in Gen 2)
      local ok,err=pcall(host.enemyMonFainted,host)
      if type(host.awardExperience)=='function' then
        host.awardExperience=oldAward
      elseif type(host.awardExp)=='function' then
        host.awardExp=oldAward
      end
      host.emit=oldEmit;rt.emit=oldPublic
      if not ok then D.close(s);error(err,0) end
    else
      host:emit{kind='message',text='You have no more POKéMON!'}
      host:endBattle('lose')
    end
    -- Use Gen 1/3 approach for event handling
    screen.phase='messages'
  else
    -- Gen 1 and Gen 3 use the same finishing logic
    screen.phase='messages'
    if core.outcome=='win' then
      local previous=host.awardExp;host.awardExp=function() end
      local ok,err=pcall(host.enemyMonFainted,host);host.awardExp=previous
      if not ok then D.close(s);error(err,0) end
    else
      local previous=host.playerPartyView
      host.playerPartyView=function()
        local party={};for _,mon in ipairs(core.playerParty) do
          if not mon.isEgg and not mon.egg then party[#party+1]=mon end
        end;return party
      end
      local ok,err=pcall(host.playerMonFainted,host);host.playerPartyView=previous
      if not ok then D.close(s);error(err,0) end
    end
    screen.afterQueue='finish'
  end
  D.close(s);return true
end
function D.rewardStep(s)
  local core,host,screen=s.core,s.host,s.screen
  local idle=screen.phase=='cbe_progression_idle' or screen.phase=='menu'
  -- Old producers/tests may arrive at this native state. Intercept it BEFORE
  -- its update submits a move; the live guard above never creates it.
  idle=idle or (screen.phase=='locked-in' and #(screen.queue or {})==0)
  if not idle then return false end
  if s.rewardCurrent then
    s.rewardCurrent.rewardState='complete';s.rewardCurrent=nil
    s.awardIndex=s.awardIndex+1;s.rewardsCompleted=(s.rewardsCompleted or 0)+1
    if s.adapter.refreshAfterProgression then s.adapter:refreshAfterProgression(s.rewardLevels) end
    s.rewardLevels=nil
  end
  local defeated=core.defeated[s.awardIndex]
  while defeated and defeated.rewardState=='complete' do
    s.awardIndex=s.awardIndex+1;defeated=core.defeated[s.awardIndex]
  end
  if defeated then awardOne(s,defeated);return true end
  if s.progressing then
    local resume=s.rewardResume;s.rewardResume=nil
    restoreProgressView(s);core:continueAfterEvents(resume)
    if core.phase=='finished' then D.startHandoff(s) end
    return true
  end
  return finishNative(s)
end
function D.fail(s,err)
  s.core.phase='fault';s.progressing=nil;s.handoff=nil
  s.screen.phase='cbe_doubles'
  s.screen.__cbeDoublesProgressing=nil;s.host.__cbeDoublesProgressing=nil
  s.core.messageText='Doubles test error: '..tostring(err)..(s.rewardsStarted
    and ' | Progression has committed; reload the pre-battle save.' or ' | B: restore encounter as singles.')
  s.core:bump();log(s.core.messageText)
  if V.mod.cache then pcall(V.mod.cache.write,V.mod.cache,'build/doubles-test-error.txt',s.core.messageText) end
end
function D.update(s,dt)
  if s.handoff or s.progressing then return D.rewardStep(s) end
  -- This wrapper is called from the engine fixed step. Never replace that dt with
  -- wall time: at 4X/10X several logic ticks occur before one render, and a wall
  -- clock made all but the first tick effectively zero, stalling doubles queues,
  -- sendouts and animations while native battle logic raced ahead.
  dt=math.max(0,math.min(.1,tonumber(dt) or 0))
  local input=s.screen.game.input;local pressed={}
  for _,key in ipairs({'up','down','left','right','a','b','start','select'}) do
    local down=input and type(input.isDown)=='function' and input:isDown(key) or false
    local raw=input and type(input.wasPressed)=='function' and input:wasPressed(key) or false
    pressed[key]=(raw or down) and not s.inputHeld[key]
    s.inputHeld[key]=down or raw
  end
  if s.core.phase=='fault' then
    if pressed.b then D.abort(s) end
    return true
  end

  -- Prepare all active 3D bodies BEFORE Core starts the opening send queue.
  -- The previous 4/4 invariant was enforced inside each send event, which could
  -- deadlock on the opening text when the missing model depended on the external
  -- cooperative worker. Pump that worker here, inside the same update owner that
  -- is waiting for readiness, so Gen I and Gen II cannot starve themselves.
  if s.actorPreflight and V.DoublesPresenter and type(V.DoublesPresenter.prepareActive)=='function' then
    local cert=V.DoublesPresenter.prepareActive(s,1)
    if not cert.ready and V.PokemonActors and type(V.PokemonActors.pumpBattlePrewarm)=='function' then
      local game=s.screen and s.screen.game
      local frameOwns=V.FrameWork and type(V.FrameWork.active)=='function' and V.FrameWork.active(game)
      -- The normal Game.update wrapper drains ONE slice after all speed-scaled
      -- logic ticks. Pumping 6ms on each preflight tick multiplied buffering at
      -- high battle speeds. Stripped/legacy hosts still own a local progress path.
      if not frameOwns then
        pcall(V.PokemonActors.pumpBattlePrewarm,3)
        cert=V.DoublesPresenter.prepareActive(s,1)
      end
    end
    s.modelReadiness=cert;s.actorPreflightAge=(tonumber(s.actorPreflightAge) or 0)+dt
    if not cert.ready then return true end
    s.actorPreflight=nil;s.actorPreflightAge=nil
  end
  -- Belt-and-suspenders guard around the per-send presentationPending contract.
  -- A future queue/order regression must still never make the command phase
  -- interactive with only three of four required actors.  This applies to both
  -- Gen I and Gen II because the doubles Core slot contract is generation-neutral.
  if s.core.phase=='command' and V.DoublesPresenter and type(V.DoublesPresenter.activeReady)=='function'
      and not V.DoublesPresenter.activeReady(s) then
    if type(V.DoublesPresenter.update)=='function' then V.DoublesPresenter.update(s,dt) end
    s.modelReadiness=V.DoublesPresenter.readiness and V.DoublesPresenter.readiness(s) or {ready=false}
    return true
  end
  local success,err=pcall(function()
    local inputChanged=s.inputTicket~=s.core.ticket or s.inputPhase~=s.core.phase
    for _,down in pairs(pressed) do if down then inputChanged=true;break end end
    if inputChanged then
      s.consumer.input(D.service,s.core:snapshot(),pressed,s.screen.game)
      s.inputTicket=s.core.ticket;s.inputPhase=s.core.phase
      D.inputSnapshots=(D.inputSnapshots or 0)+1
    end
    if s.closed then return end
    s.core.autoProgress=not V.BattleAutoProgress or V.BattleAutoProgress.enabled(s.screen.game)
    s.core:update(dt,pressed.a or pressed.b)
    if V.DoublesPresenter then V.DoublesPresenter.update(s,dt) end
    if s.core.phase=='finished' then D.startHandoff(s) end
  end)
  if not success then
    D.fail(s,err)
  end
  return true
end
D.service={version=1,format='double',experimental=false,snapshotOptionsVersion=1,
  snapshot=function(value,options)
    local s=D.combat(value);if not s then return nil end
    D.snapshotRequests=(D.snapshotRequests or 0)+1
    local snap=s.core:snapshot(options)
    if V.DoublesPresenter and type(V.DoublesPresenter.readiness)=='function' then
      local readiness=V.DoublesPresenter.readiness(s);s.modelReadiness=readiness;snap.modelReadiness=readiness
      -- Snapshot-only phase masking keeps the command panel off screen if an
      -- unexpected queue transition reaches command before the actor certificate.
      -- Core itself is left untouched and Runtime above continues retrying actors.
      if (s.actorPreflight or snap.phase=='command') and not readiness.ready then
        snap.phase='present';snap.commandSlot=nil
        local miss=readiness.missing and readiness.missing[1]
        snap.message='Preparing battle models'..(miss and (' / '..tostring(miss.slot)) or '')..'...'
      end
    end
    return snap
  end,
  submit=function(request)
    local s=D.combat();if not s then return false,'No active doubles encounter' end
    if s.core.phase=='command' and V.DoublesPresenter and type(V.DoublesPresenter.activeReady)=='function'
        and not V.DoublesPresenter.activeReady(s) then
      return false,'Battle models are still preparing'
    end
    return s.core:submit(request)
  end,
  status=function() local s=D.session();local fx=V.DoublesMovePresentation;local readiness=s and V.DoublesPresenter and V.DoublesPresenter.readiness and V.DoublesPresenter.readiness(s);return {active=s~=nil,battleId=s and s.core.id,phase=s and s.core.phase,lastSkip=D.lastSkip,
    inputSnapshots=D.inputSnapshots or 0,snapshotRequests=D.snapshotRequests or 0,
    modelReadiness=readiness,
    targetDiagnostics=s and s.core and type(s.core.targetDiagnostics)=='function' and s.core:targetDiagnostics() or nil,
    lastTargetDiagnostics=not s and D.lastTargetDiagnostics and clone(D.lastTargetDiagnostics) or nil,
    presentationError=s and s.presentationError,presentationWarning=s and s.presentationWarning,
    moveFX=fx and {starts=fx.starts,sourceStarts=fx.sourceStarts,nativeAudioFallbacks=fx.nativeAudioFallbacks,lastError=fx.lastError}} end,
  abort=function(request)
    local s=D.combat();if not s then return false,'No doubles battle' end
    local ok,why=s.core:validateRequest(request);if not ok then return false,why end
    return D.abort(s)
  end,
}
function D.install()
  if D.installed then return end
  D.installed=true;V.mod.exports.doubles=D.service
  local Runtime=req('src.mods.Runtime')
  if not Runtime.__cbeDoublesEmitGuard then
    local old=Runtime.emit
    Runtime.emit=function(name,payload,...)
      if type(payload)=='table' and type(payload.battle)=='table' and payload.battle.__cbeDoublesKernel then return end
      return old(name,payload,...)
    end
    Runtime.__cbeDoublesEmitGuard=true
  end
  -- Both native battle classes are patched unconditionally, every session,
  -- regardless of which cartridge happens to be loaded when install() runs.
  --
  -- This mod bundles several generations at once and the launcher can switch
  -- between them (GameVersion.set) without restarting the process, so there
  -- is no single "the generation" to read once here -- a session can (and,
  -- per play reports, routinely does) visit Gen II and Gen III in the same
  -- run. Previously this read V.GenerationCompat.current() ONE TIME, at
  -- mod-install, and used that single answer both to pick ONE of the two
  -- classes below to patch and as the fixed `generation` handed to every
  -- later D.tryBegin call. Whichever class did not match the one-shot
  -- snapshot never got the CBE doubles hook wired onto its update method at
  -- all, so at most one of {Gen II} or {Gen I/III} could ever trigger CBE
  -- doubles in a given process lifetime -- and if the snapshot was taken
  -- before any save was loaded (GameVersion.current defaults to "red"), it
  -- was possible for neither branch to line up with what was actually being
  -- played. That is what made doubles look permanently off for Gen II and
  -- Gen III alike: only whichever generation happened to be current at
  -- mod-load time was ever wired up, and often that was neither.
  local function patchClass(class,resolveGeneration)
    if not class or type(class.update)~='function' then return end
    if class.__cbeDoublesPatched then return end
    class.__cbeDoublesPatched=true
    local old=class.update
    class.update=function(screen,dt,...)
      local generation=resolveGeneration(screen)
      local s=D.byState[screen] or D.tryBegin(screen,generation)
      if s and not s.closed then
        if s.handoff or s.progressing then
          -- Native dialogs/stat boxes/learning run, but native combat
          -- submission cannot. The arena presenter keeps its four
          -- independent actor handles.
          if s.progressing and V.DoublesPresenter then V.DoublesPresenter.update(s,dt) end
          local ok,handled=pcall(D.rewardStep,s)
          if not ok then D.fail(s,handled);return end
          if handled then return end
          local success,result=pcall(old,screen,dt,...)
          if not success then D.fail(s,result);return end
          if not s.closed and (s.progressing or s.handoff) then
            local settled,why=pcall(D.rewardStep,s)
            if not settled then D.fail(s,why) end
          end
          return result
        else D.update(s,dt);return end
      end
      return old(screen,dt,...)
    end
  end
  -- Gen 3 uses the same BattleState class as Gen 1, so this one class serves
  -- both -- ask GenerationCompat fresh (it is no longer cached) rather than
  -- assume either.
  local okG13,classG13=pcall(req,'src.battle.BattleState')
  if okG13 then
    patchClass(classG13,function() return V.GenerationCompat.current() end)
  end
  -- Gen 2 has always had its own separate class, so it is unambiguous: this
  -- update method is only ever reached by a Gen II battle.
  local okG2,classG2=pcall(req,'src.battle.BattleState')
  if okG2 then
    patchClass(classG2,function() return 2 end)
  end
  -- Freeze native checkpoints at the unsupported custom phase (not 'menu').
  -- Engine BattleSafety already rejects this phase; no save serializer changes.
  if V.mod.events then V.mod.events:on('battle.ended',function(e)
    local s=e and D.session(e.battle)
    if s and not s.handoff then D.close(s) end
  end) end
end
return D