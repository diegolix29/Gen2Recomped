local U={active=false,disabled=false,lastDraw=0,lastLabel=nil}

local function graphicsReady()
  if U.disabled then return false end
  if not (love and love.graphics) then return false end
  if love.graphics.isActive then
    local ok,v=pcall(love.graphics.isActive)
    if ok and not v then return false end
  end
  return type(love.graphics.getDimensions)=="function" and type(love.graphics.present)=="function"
end

local function stageInfo(label)
  local s=tostring(label or "BUILDING CACHE"):upper()
  if s:find("DISC",1,true) then return 1,"VALIDATING COLOSSEUM DISC" end
  if s:find("FSYS",1,true) then return 2,"INDEXING COLOSSEUM ARCHIVES" end
  if s:find("ARENA",1,true) then return 3,"BUILDING ARENA CACHE" end
  if s:find("TRAINER",1,true) then return 4,"BUILDING TRAINER CACHE" end
  if s:find("TRANSITION",1,true) then return 5,"BUILDING TRANSITION CACHE" end
  if s:find("AUDIO",1,true) then return 6,"BUILDING AUDIO CACHE" end
  if s:find("VERIFY",1,true) or s:find("READY",1,true) then return 7,"FINALIZING GENERATED RUNTIME" end
  return 1,"BUILDING GENERATED RUNTIME"
end

local function clamp(v,a,b) if v<a then return a elseif v>b then return b end return v end
local function printWrapped(g,text,x,y,w)
  if type(g.printf)=="function" then g.printf(tostring(text or ""),x,y,w,"left") else g.print(tostring(text or ""),x,y) end
end

local function beginFrame(heightOverride)
  local g=love.graphics
  local w,h=g.getDimensions()
  if g.push then g.push("all") end
  if g.setCanvas then g.setCanvas() end
  if g.origin then g.origin() end
  g.clear(0.035,0.045,0.04,1)
  local panelW=math.min(w-48,760);local panelH=math.min(h-48,heightOverride or 390)
  local x=(w-panelW)/2;local y=(h-panelH)/2
  g.setColor(0.08,0.10,0.09,0.98);g.rectangle("fill",x,y,panelW,panelH,8,8)
  g.setColor(0.54,0.50,0.26,1);g.rectangle("fill",x,y,panelW,5)
  return g,panelW,panelH,x,y
end

local function endFrame(g)
  if g.pop then g.pop() end
  g.present()
end

-- A full-screen clear + present + event pump costs an entire display frame on
-- a phone. The old throttle was bypassed whenever the LABEL changed, and the
-- extractors change their label per move / per species / per member -- so a
-- 251-move pass paid hundreds of full presents purely to redraw a progress
-- bar. The throttle is now on time alone (still ~22 updates/second, which is
-- more than a human reads), and `force` still bypasses it for stage
-- transitions and the final frame.
--
-- Event pumping is deliberately NOT throttled with the redraw: Android needs
-- the message queue drained during a long synchronous build or the OS reports
-- the app as unresponsive. Pumping without redrawing is nearly free.
local function pumpOnly()
  if love and love.event and love.event.pump then pcall(love.event.pump) end
end

local function draw(label,current,total,force,finalText)
  if not graphicsReady() then return end
  local now=(love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  if not force and now-U.lastDraw<0.045 then
    U.lastLabel=label
    pumpOnly()
    return
  end
  U.lastDraw=now;U.lastLabel=label;U.active=true
  local ok=pcall(function()
    local g,panelW,_,x,y=beginFrame()
    g.setColor(0.90,0.86,0.65,1);g.print("COLOSSEUM SOURCE CACHE",x+28,y+24)
    g.setColor(0.70,0.74,0.69,1);g.print("BUILDING GENERATED RUNTIME FROM YOUR VALIDATED GC6E01 DISC",x+28,y+56)

    local stage,stageName=stageInfo(label)
    local c=tonumber(current) or 0;local t=tonumber(total) or 0
    local localFrac=t>0 and clamp(c/t,0,1) or 0
    local overall=clamp(((stage-1)+localFrac)/7,0,1)
    g.setColor(0.94,0.92,0.78,1);g.print(("STAGE %d / 7   %s"):format(stage,stageName),x+28,y+104)
    g.setColor(0.86,0.88,0.82,1);g.print(tostring(label or stageName),x+28,y+132)
    if t>0 then g.setColor(0.66,0.70,0.65,1);g.print(("%d / %d"):format(c,t),x+28,y+158) end

    local bx=x+28;local by=y+198;local bw=panelW-56;local bh=24
    g.setColor(0.15,0.17,0.15,1);g.rectangle("fill",bx,by,bw,bh,4,4)
    g.setColor(0.68,0.62,0.32,1);g.rectangle("fill",bx,by,math.max(2,bw*overall),bh,4,4)
    g.setColor(0.78,0.80,0.74,1);g.print(("OVERALL CACHE  %d%%"):format(math.floor(overall*100+0.5)),bx,by+34)

    g.setColor(0.58,0.62,0.57,1)
    g.print("Visual cache work is normally short; first portable soundtrack synthesis on mobile can take several minutes once.",x+28,y+275)
    g.print("The current source/member is shown above; progress heartbeats confirm the build is still active.",x+28,y+301)
    if finalText then g.setColor(0.90,0.86,0.65,1);printWrapped(g,finalText,x+28,y+330,panelW-56) end
    endFrame(g)
    if love.event and love.event.pump then love.event.pump() end
  end)
  if not ok then U.disabled=true end
end

local function short(v,n)
  v=tostring(v or ""):gsub("[%s\r\n]+"," ")
  n=n or 150
  if #v>n then return v:sub(1,n-3).."..." end
  return v
end

-- The source-runtime cache policy is intentionally a separate first screen,
-- not another build-failure action.  Its geometry is derived from the current
-- viewport so keyboard, mouse and touch all address the same three choices on
-- desktop and narrow mobile screens.
local function cacheChoiceButtonsForDimensions(w,h)
  w,h=tonumber(w),tonumber(h);if not (w and h) then return nil end
  local panelW=math.min(w-48,760);local panelH=math.min(h-48,520)
  local x=(w-panelW)/2;local y=(h-panelH)/2
  local bx=x+28;local bw=panelW-56;local bh=38;local gap=7
  local first=y+panelH-28-(bh*3+gap*2)
  return {
    reuse={x=bx,y=first,w=bw,h=bh},
    rebuild={x=bx,y=first+bh+gap,w=bw,h=bh},
    delete={x=bx,y=first+(bh+gap)*2,w=bw,h=bh},
  },{panelW=panelW,panelH=panelH,x=x,y=y}
end
local function cacheChoiceButtons()
  if not (love and love.graphics and type(love.graphics.getDimensions)=="function") then return nil end
  local w,h=love.graphics.getDimensions();return cacheChoiceButtonsForDimensions(w,h)
end
local function cacheChoiceActionAtDimensions(x,y,w,h)
  x,y=tonumber(x),tonumber(y);if not x or not y then return nil end
  local rows=cacheChoiceButtonsForDimensions(w,h);if not rows then return nil end
  for action,r in pairs(rows) do if x>=r.x and x<=r.x+r.w and y>=r.y and y<=r.y+r.h then return action end end
  return nil
end
local function cacheChoiceActionAt(x,y)
  if not (love and love.graphics and type(love.graphics.getDimensions)=="function") then return nil end
  local w,h=love.graphics.getDimensions();return cacheChoiceActionAtDimensions(x,y,w,h)
end

local function cacheChoiceFrame()
  if not graphicsReady() then return false end
  local ok=pcall(function()
    local g,panelW,panelH,x,y=beginFrame(520);U.active=true
    g.setColor(0.90,0.86,0.65,1);g.print("COLOSSEUM SOURCE CACHE",x+28,y+24)
    g.setColor(0.94,0.92,0.78,1);g.print("EXISTING GENERATED CACHE FOUND",x+28,y+58)
    g.setColor(0.72,0.75,0.70,1)
    if panelH<390 then
      printWrapped(g,"Choose before any compatibility repair or rebuild writes. WIPE ALL is destructive to this mod's generated caches only; your imported GC6E01 source is always kept.",x+28,y+86,panelW-56)
    else
      printWrapped(g,"Choose how CBE should handle the saved generated runtime before any compatibility repair or rebuild writes occur.",x+28,y+90,panelW-56)
      g.setColor(0.62,0.66,0.61,1)
      printWrapped(g,"USE EXISTING keeps compatible payloads.  REBUILD refreshes needed payloads while preserving replaced bytes.  WIPE ALL removes every Colosseum Overhaul cache iteration, including legacy preservation copies; the imported Colosseum source and other mods are untouched.",x+28,y+130,panelW-56)
    end
    local rows=cacheChoiceButtons()
    local function button(r,label,warning)
      g.setColor(warning and 0.20 or 0.13,warning and 0.11 or 0.15,warning and 0.10 or 0.13,1);g.rectangle("fill",r.x,r.y,r.w,r.h,5,5)
      g.setColor(warning and 0.94 or 0.84,warning and 0.75 or 0.84,warning and 0.68 or 0.75,1);g.print(label,r.x+12,r.y+10)
    end
    button(rows.reuse,"USE EXISTING CACHE   [ENTER]",false)
    button(rows.rebuild,"REBUILD CACHE / PRESERVE OLD BYTES   [R]",false)
    button(rows.delete,"WIPE ALL CBE CACHES (DESTRUCTIVE)   [D]",true)
    endFrame(g)
  end)
  if not ok then U.disabled=true return false end
  return true
end

local function failureButtonsForDimensions(w,h)
  w,h=tonumber(w) or 640,tonumber(h) or 480
  local panelW=math.max(280,math.min(w-48,760));local panelH=math.max(260,math.min(h-48,520))
  local x=(w-panelW)/2;local y=(h-panelH)/2;local bx=x+28;local bw=panelW-56
  local bh=math.max(28,math.min(36,math.floor(panelH*.075)));local gap=6
  local total=bh*4+gap*3;local first=y+panelH-14-total
  return {
    retry={x=bx,y=first,w=bw,h=bh},
    delete_rebuild={x=bx,y=first+bh+gap,w=bw,h=bh},
    continue={x=bx,y=first+(bh+gap)*2,w=bw,h=bh},
    exit={x=bx,y=first+(bh+gap)*3,w=bw,h=bh},
  }
end
local function failureButtons()
  if not (love and love.graphics and type(love.graphics.getDimensions)=="function") then return nil end
  local w,h=love.graphics.getDimensions();return failureButtonsForDimensions(w,h)
end
local function failureActionAtDimensions(x,y,w,h)
  x,y=tonumber(x),tonumber(y);if not x or not y then return nil end
  local rows=failureButtonsForDimensions(w,h)
  for action,r in pairs(rows) do if x>=r.x and x<=r.x+r.w and y>=r.y and y<=r.y+r.h then return action end end
  return nil
end
local function actionAt(x,y)
  x,y=tonumber(x),tonumber(y);if not x or not y then return nil end
  local rows=failureButtons();if not rows then return nil end
  for action,r in pairs(rows) do if x>=r.x and x<=r.x+r.w and y>=r.y and y<=r.y+r.h then return action end end
  return nil
end

local function failureFrame(state,message,trainerFirst,trainerSource)
  if not graphicsReady() then return false end
  local ok=pcall(function()
    local g,panelW,panelH,x,y=beginFrame(520)
    g.setColor(0.90,0.86,0.65,1);g.print("COLOSSEUM SOURCE CACHE",x+28,y+24)
    g.setColor(0.86,0.70,0.64,1);g.print("GENERATED RUNTIME IS NOT READY",x+28,y+58)
    g.setColor(0.94,0.92,0.78,1);g.print(tostring(state or "CACHE BUILD FAILED"),x+28,y+104)
    g.setColor(0.72,0.75,0.70,1);printWrapped(g,message or "The generated runtime did not complete.",x+28,y+136,panelW-56)
    if trainerFirst and trainerFirst~="" then
      g.setColor(0.86,0.82,0.68,1);g.print("TRAINER TARGET",x+28,y+204)
      g.setColor(0.68,0.71,0.66,1);printWrapped(g,short(trainerFirst,170),x+166,y+204,panelW-194)
    end
    if trainerSource and trainerSource~="" then
      g.setColor(0.86,0.82,0.68,1);g.print("SOURCE DETAIL",x+28,y+236)
      g.setColor(0.68,0.71,0.66,1);printWrapped(g,short(trainerSource,210),x+166,y+236,panelW-194)
    end
    local rows=failureButtons()
    local noteY=math.max(y+266,rows.retry.y-50)
    g.setColor(0.58,0.62,0.57,1)
    if panelH<390 then
      printWrapped(g,"CBE will not initialize an incomplete runtime. DELETE + REBUILD keeps the imported GC6E01 source.",x+28,noteY,panelW-56)
    else
      printWrapped(g,"CBE will not initialize an incomplete generated runtime. DELETE + REBUILD clears the failed generated CBE cache scope and rebuilds it from the retained GC6E01 source; the imported source is not deleted.",x+28,noteY,panelW-56)
    end
    local function button(r,label,warning)
      g.setColor(warning and 0.20 or 0.13,warning and 0.11 or 0.15,warning and 0.10 or 0.13,1);g.rectangle("fill",r.x,r.y,r.w,r.h,5,5)
      g.setColor(warning and 0.94 or 0.84,warning and 0.75 or 0.84,warning and 0.68 or 0.75,1);g.print(label,r.x+12,r.y+math.max(6,(r.h-16)/2))
    end
    button(rows.retry,"RETRY CACHE BUILD   [R]",false)
    button(rows.delete_rebuild,"DELETE GENERATED CACHE + REBUILD   [D]",true)
    button(rows.continue,"CONTINUE WITHOUT CBE   [ENTER]",false)
    button(rows.exit,"EXIT GAME   [ESC]",false)
    endFrame(g)
  end)
  if not ok then U.disabled=true return false end
  return true
end

local function isDown(key)
  if not (love and love.keyboard and type(love.keyboard.isDown)=="function") then return false end
  local ok,v=pcall(love.keyboard.isDown,key);return ok and v==true
end

function U.update(label,current,total)
  draw(label,current,total,false,nil)
end

function U.finish(state,message)
  if not U.active then return end
  local label=tostring(state or "CACHE BUILD COMPLETE")
  draw(label,7,7,true,message or state)
end

-- Existing caches are never mutated until this gate returns. There is no
-- preselected destructive action; callers may use a conservative reuse fallback
-- only when graphics are genuinely unavailable (for example a headless test).
function U.cacheChoiceGate()
  if not cacheChoiceFrame() then return nil,"graphics unavailable" end
  local prevEnter,prevR,prevD,prevPointer=true,true,true,true
  local armedAt=((love.timer and love.timer.getTime and love.timer.getTime()) or os.clock())+0.20
  while true do
    local now=(love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
    if love.event and love.event.pump then pcall(love.event.pump) end
    if love.event and type(love.event.poll)=="function" then
      local ok,iter=pcall(love.event.poll)
      if ok and iter then
        for name,a,b,c in iter do
          if name=="quit" then return "exit" end
          if name=="mousepressed" and tonumber(c or 1)==1 then
            local action=cacheChoiceActionAt(a,b);if action and now>=armedAt then return action end
          elseif name=="touchpressed" then
            local action=cacheChoiceActionAt(b,c);if action and now>=armedAt then return action end
          elseif name=="keypressed" and now>=armedAt then
            if a=="return" or a=="kpenter" then return "reuse"
            elseif a=="r" then return "rebuild"
            elseif a=="d" then return "delete" end
          end
        end
      end
    end
    local ent=isDown("return") or isDown("kpenter")
    local r=isDown("r");local d=isDown("d")
    local pointerAction=nil;local pointerDown=false
    if now>=armedAt and love.touch and type(love.touch.getTouches)=="function" and type(love.touch.getPosition)=="function" then
      local ok,ids=pcall(love.touch.getTouches)
      if ok and type(ids)=="table" then
        for _,id in ipairs(ids) do pointerDown=true;local okp,x,y=pcall(love.touch.getPosition,id);if okp then pointerAction=cacheChoiceActionAt(x,y);if pointerAction then break end end end
      end
    end
    if not pointerAction and now>=armedAt and love.mouse and type(love.mouse.isDown)=="function" and type(love.mouse.getPosition)=="function" then
      local okd,down=pcall(love.mouse.isDown,1)
      if okd and down then pointerDown=true;local okp,x,y=pcall(love.mouse.getPosition);if okp then pointerAction=cacheChoiceActionAt(x,y) end end
    end
    if now>=armedAt then
      if pointerAction and not prevPointer then return pointerAction end
      if ent and not prevEnter then return "reuse" end
      if r and not prevR then return "rebuild" end
      if d and not prevD then return "delete" end
    end
    prevEnter,prevR,prevD,prevPointer=ent,r,d,pointerDown
    cacheChoiceFrame()
    if love.timer and love.timer.sleep then love.timer.sleep(0.05) end
  end
end

-- Startup is synchronous, so a failed first-run build needs its own tiny event
-- loop. This prevents an incomplete CBE runtime from silently falling through
-- into gameplay while still allowing an explicit vanilla-game escape hatch.
function U.failureGate(state,message,trainerFirst,trainerSource)
  if not failureFrame(state,message,trainerFirst,trainerSource) then return "continue" end
  local prevR,prevD,prevEnter,prevEsc=true,true,true,true
  local armedAt=((love.timer and love.timer.getTime and love.timer.getTime()) or os.clock())+0.20
  while true do
    local now=(love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
    if love.event and love.event.pump then pcall(love.event.pump) end
    if love.event and type(love.event.poll)=="function" then
      local ok,iter=pcall(love.event.poll)
      if ok and iter then
        for name,a,b,c in iter do
          if name=="quit" then return "exit" end
          if now==nil then now=(love.timer and love.timer.getTime and love.timer.getTime()) or os.clock() end
          if name=="mousepressed" and tonumber(c or 1)==1 then
            local action=actionAt(a,b);if action and now>=armedAt then return action end
          elseif name=="touchpressed" then
            local action=actionAt(b,c);if action and now>=armedAt then return action end
          elseif name=="keypressed" and now>=armedAt then
            if a=="r" then return "retry"
            elseif a=="d" then return "delete_rebuild"
            elseif a=="return" or a=="kpenter" then return "continue"
            elseif a=="escape" then
              if love.event and love.event.quit then pcall(love.event.quit) end
              return "exit"
            end
          end
        end
      end
    end
    local r=isDown("r")
    local d=isDown("d")
    local ent=isDown("return") or isDown("kpenter")
    local esc=isDown("escape")
    local pointerAction=nil
    if now>=armedAt and love.touch and type(love.touch.getTouches)=="function" and type(love.touch.getPosition)=="function" then
      local ok,ids=pcall(love.touch.getTouches)
      if ok and type(ids)=="table" then
        for _,id in ipairs(ids) do local okp,x,y=pcall(love.touch.getPosition,id);if okp then pointerAction=actionAt(x,y);if pointerAction then break end end end
      end
    end
    if not pointerAction and now>=armedAt and love.mouse and type(love.mouse.isDown)=="function" and type(love.mouse.getPosition)=="function" then
      local okd,down=pcall(love.mouse.isDown,1)
      if okd and down then local okp,x,y=pcall(love.mouse.getPosition);if okp then pointerAction=actionAt(x,y) end end
    end
    if now>=armedAt then
      if pointerAction then return pointerAction end
      if r and not prevR then return "retry" end
      if d and not prevD then return "delete_rebuild" end
      if ent and not prevEnter then return "continue" end
      if esc and not prevEsc then
        if love.event and love.event.quit then pcall(love.event.quit) end
        return "exit"
      end
    end
    prevR,prevD,prevEnter,prevEsc=r,d,ent,esc
    failureFrame(state,message,trainerFirst,trainerSource)
    if love.timer and love.timer.sleep then love.timer.sleep(0.05) end
  end
end

U._test={cacheChoiceButtonsForDimensions=cacheChoiceButtonsForDimensions,cacheChoiceActionAtDimensions=cacheChoiceActionAtDimensions,
  failureButtonsForDimensions=failureButtonsForDimensions,failureActionAtDimensions=failureActionAtDimensions}

return U
