local V=...
local Assets=V.GeneratedAssets
local Persist,mod=V.PayloadPreserver,V.mod
local R={version=2}
local luaMemo={}
local luaMemoHits=0
local luaMemoLoads=0
local unpackArgs=table.unpack or unpack

function R.packSupported()
  return (love and love.data and type(love.data.pack)=="function")
    or type(string.pack)=="function"
end
function R.supported()
  return R.packSupported() and love and love.data and type(love.data.newByteData)=="function"
    and love.graphics and type(love.graphics.newMesh)=="function"
end

local function finite(n)
  n=tonumber(n) or 0
  if n~=n or n==math.huge or n==-math.huge then return 0 end
  return n
end

-- Rows are packed in batches rather than one love.data.pack call (plus one
-- scratch table and one intermediate string) per vertex. A single arena or
-- Pokemon body is tens of thousands of rows, so this removes the dominant
-- allocation cost of writing a runtime sidecar. Output bytes are unchanged.
local PACK_BATCH=64
-- Lua/LuaJIT builds do not all expose the same practical vararg/result ceiling.
-- A Waza morph vertex has 44 floats; PACK_BATCH=64 used to expand that to 2,816
-- scalar call arguments, and unpack() is evaluated *before* pcall(love.data.pack,
-- ...), so a mobile stack-limit failure escaped the pack error guard entirely.
-- Keep batching, but cap scalar arguments well below the common 255-register
-- boundary. This changes only call granularity; emitted f32 bytes are identical.
local PACK_SCALAR_LIMIT=192

function R.packRows(rows,stride,checkpoint)
  stride=math.max(1,math.floor(tonumber(stride) or 0))
  if stride<=0 or not R.packSupported() then return nil,"runtime binary pack API unavailable" end
  rows=rows or {}
  local count=#rows
  if count==0 then return nil,"no vertex rows" end
  local rowFmt=string.rep("f",stride)
  local rowsPerBatch=math.max(1,math.min(PACK_BATCH,math.floor(PACK_SCALAR_LIMIT/stride)))
  local batchFmt=string.rep(rowFmt,rowsPerBatch)
  local buf={}
  local chunks,chunkCount={},0
  local i=1
  while i<=count do
    local take=count-i+1;if take>rowsPerBatch then take=rowsPerBatch end
    local k=0
    for r=i,i+take-1 do
      local row=rows[r]
      if type(row)~="table" then return nil,"vertex row missing" end
      for j=1,stride do
        local v=tonumber(row[j]) or 0
        if v~=v or v==math.huge or v==-math.huge then v=0 end
        k=k+1;buf[k]=v
      end
    end
    local fmt=take==rowsPerBatch and batchFmt or string.rep(rowFmt,take)
    local ok,bytes
    if love and love.data and type(love.data.pack)=="function" then
      ok,bytes=pcall(love.data.pack,"string",fmt,unpackArgs(buf,1,k))
    end
    if (not ok or type(bytes)~="string") and type(string.pack)=="function" then
      ok,bytes=pcall(string.pack,"<"..fmt,unpackArgs(buf,1,k))
    end
    if not ok or type(bytes)~="string" then return nil,tostring(bytes or "float32 pack failed") end
    chunkCount=chunkCount+1;chunks[chunkCount]=bytes
    i=i+take
    if checkpoint then checkpoint() end
  end
  return table.concat(chunks,"",1,chunkCount)
end

function R.writeRows(path,rows,stride,checkpoint,preserveExisting)
  if not (Assets and Assets.write) then return false,"generated cache writer unavailable" end
  local bytes,err=R.packRows(rows,stride,checkpoint);if not bytes then return false,err end
  if preserveExisting and Persist then
    local _,why=Persist.preserve(mod,"runtime_mesh",path,bytes)
    if why then return false,why end
  end
  local ok,why=Assets.write(path,bytes)
  return ok~=false and ok~=nil,why,#bytes
end

function R.meshFromBytes(format,bytes,stride,usage)
  if not (R.supported() and type(bytes)=="string") then return nil,"runtime binary mesh unavailable" end
  stride=math.max(1,math.floor(tonumber(stride) or 0))
  local bytesPerVertex=stride*4
  if bytesPerVertex<=0 or #bytes<bytesPerVertex or (#bytes%bytesPerVertex)~=0 then
    return nil,"runtime binary mesh byte count/stride mismatch"
  end
  local count=math.floor(#bytes/bytesPerVertex)
  local okMesh,mesh=pcall(love.graphics.newMesh,format,count,"triangles",usage or "static")
  if not okMesh or not mesh then return nil,tostring(mesh or "newMesh failed") end
  local okData,data=pcall(love.data.newByteData,bytes)
  if not okData or not data then pcall(function() if mesh.release then mesh:release() end end);return nil,tostring(data or "newByteData failed") end
  local okSet,setErr=pcall(mesh.setVertices,mesh,data,1,count)
  -- setVertices copies the upload; the staging buffer is not a resident asset.
  if data.release then pcall(data.release,data) end
  if not okSet then pcall(function() if mesh.release then mesh:release() end end);return nil,tostring(setErr) end
  return mesh,nil,count
end

function R.meshFromPath(format,path,stride,usage)
  if not (Assets and Assets.read) then return nil,"generated cache reader unavailable" end
  local bytes,err=Assets.read(path);if type(bytes)~="string" then return nil,err end
  return R.meshFromBytes(format,bytes,stride,usage)
end

local function keySort(a,b)
  local ta,tb=type(a),type(b)
  if ta==tb then return tostring(a)<tostring(b) end
  return ta<tb
end
local function serialize(v,seen,depth)
  local t=type(v)
  if t=="nil" then return "nil" end
  if t=="boolean" then return v and "true" or "false" end
  if t=="number" then return string.format("%.17g",finite(v)) end
  if t=="string" then return string.format("%q",v) end
  if t~="table" then return "nil" end
  depth=(depth or 0)+1;if depth>24 then return "nil" end
  seen=seen or {};if seen[v] then return "nil" end;seen[v]=true
  local keys={};for k in pairs(v) do if type(k)=="string" or type(k)=="number" then keys[#keys+1]=k end end
  table.sort(keys,keySort)
  local out={"{"}
  for _,k in ipairs(keys) do
    local ks=type(k)=="number" and ("["..string.format("%.17g",k).."]") or ("["..string.format("%q",k).."]")
    out[#out+1]=ks.."="..serialize(v[k],seen,depth).."," 
  end
  out[#out+1]="}";seen[v]=nil
  return table.concat(out)
end
function R.writeLua(path,value,preserveExisting)
  if not (Assets and Assets.write) then return false,"generated cache writer unavailable" end
  path=tostring(path or "")
  local bytes="return "..serialize(value).."\n"
  if preserveExisting and Persist then
    local _,why=Persist.preserve(mod,"runtime_mesh",path,bytes)
    if why then return false,why end
  end
  local ok,err=Assets.write(path,bytes)
  if ok~=false and ok~=nil then luaMemo[path]=value end
  return ok~=false and ok~=nil,err
end
function R.readLua(path)
  if not (Assets and Assets.read) then return nil,"generated cache reader unavailable" end
  path=tostring(path or "")
  local memo=luaMemo[path]
  if memo~=nil then luaMemoHits=luaMemoHits+1;return memo end
  local src,err=Assets.read(path);if type(src)~="string" then return nil,err end
  local f,e=load(src,"@generated/"..path);if not f then return nil,e end
  local ok,v=pcall(f);if not ok then return nil,v end
  luaMemo[path]=v;luaMemoLoads=luaMemoLoads+1
  return v
end
function R.invalidateLua(path)
  if path==nil then luaMemo={} else luaMemo[tostring(path)]=nil end
  return true
end
function R.memoStatus()
  local n=0;for _ in pairs(luaMemo) do n=n+1 end
  return {entries=n,hits=luaMemoHits,loads=luaMemoLoads}
end
function R.read(path)
  return Assets and Assets.read and Assets.read(path) or nil
end
function R.exists(path)
  return Assets and Assets.exists and Assets.exists(path) or false
end
return R
