local Layout = {}

Layout.US_MD5 = "1561c75d11cedf356a8ddb1a4a5f9d5d"
Layout.US_TITLE = "POKEMON STADIUM 2"
Layout.ROM_SIZE = 0x4000000
Layout.ASSET_START = 0x437610
Layout.FRAGMENT26_ROM_START = 0x15E8B0
Layout.FRAGMENT26_ROM_END = 0x165C50
Layout.FRAGMENT26_VRAM = 0x81000000
Layout.FRAGMENT26_TABLE_START = 0x81000020
Layout.FRAGMENT26_TABLE_END = 0x81000180
Layout.FRAGMENT26_CODE_START = 0x81000180
Layout.MODEL_TABLE_START = 0x27ED000
Layout.MODEL_TABLE_END = 0x2D7D000
Layout.MODEL_TABLE_RECORDS = 282
Layout.POSE_TABLE_START = 0x2D7D000
Layout.POSE_TABLE_END = 0x3FD5000
Layout.POSE_TABLE_RECORDS = 282
Layout.POST_POSE_TABLE_START = 0x3FD5000
Layout.POST_POSE_TABLE_END = 0x3FED000
Layout.SPECIES_META_START = 0x3FED000
Layout.ROM_END = 0x4000000
Layout.SPECIES_META_RECORD_SIZE = 0x10
Layout.HISTORICAL_SPECIES_META_RECORDS = 253
-- Model-table file indices the 251 cache does not keep. Decoder already
-- understands substitute + Unown B-Z; egg / extra Pikachu are guesses
-- from the debug model viewer (jrra / TCRF) until a dump confirms them.
Layout.MODEL_RECORD_SUBSTITUTE = 253
Layout.MODEL_RECORD_UNOWN_B = 254
Layout.MODEL_RECORD_UNOWN_Z = 278
Layout.CURRENT_DECOMP_COMMIT = "c0e10f23d90cc4f335b654711f13e53c2c07323b"
Layout.CURRENT_DECOMP_REPOSITORY = "pret/pokestadiumgs"
Layout.HISTORICAL_REPOSITORY = "pret/pokestadium"
Layout.HISTORICAL_LAYOUT_PATH = "oldnotes/stadiumgs/main.s"
Layout.HISTORICAL_ARCHIVE_TOOL_PATH = "oldnotes/utils/cattbl.c"
Layout.PERSSZP_TOOL_PATH = "tools/decompress_persszp.py"

return Layout