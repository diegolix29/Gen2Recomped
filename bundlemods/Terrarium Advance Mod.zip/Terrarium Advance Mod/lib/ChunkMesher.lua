-- Voxel world mode: turn a map's tile layer into one static 3D mesh.
--
-- The scene description comes from Structures.lua, which -- 3dSen-style --
-- detects each connected drawn thing on the map and picks its model:
--
--   flat      ground / water / void: a single quad.
--   top art   ledges, roofs (profile-authored): a box with the art on its
--             TOP face; partial side bands crop the art (a 6px ledge face
--             is the bottom of the lip drawing).
--   volume    walls, buildings, tree lines: each column rises to the
--             structure's REAL drawn height (Structures measures it,
--             repeat-aware and region-consistent -- a 6-row house is 48px,
--             a 40-row border forest is rows of 16px trees). The south
--             face folds the full artwork upright, 8px band by band, band
--             k sampling the map row k tiles north; the top wears the
--             structure's top rows.
--   object    small props with a silhouette (plants, signs, lone trees):
--             per-pixel voxel prisms prebuilt by Structures, standing on
--             synthesized ground -- this mesher just emits their quads.
--             Round trees arrive as STAMPS (a shared hull template plus a
--             cell offset) and expand here, straight into the vertex
--             stream, so no map retains per-cell copies of its forests.
--
-- Side faces are never stretched: all sides are 8px bands with the art
-- tiled per band and cropped at partial bands.
--
-- Texturing samples the TILESET ATLAS, not a rendered copy of the map. The
-- atlas is 128x48; a map-space canvas covering the biggest routes would be
-- ~5 MB each with up to five live at once (connected maps), which is real
-- memory on the mobile targets. Sampling the atlas costs 24 KB, and costs
-- nothing in fidelity because TerrainAtlas hands back the same atlas
-- TileRenderer draws with -- including the fully recolored one RED++
-- bakes -- so terrain color comes through untouched.
--
-- BUILDS ARE ASYNCHRONOUS. A frame never blocks on meshing: VoxelScene
-- requests what it wants to draw, request() queues a build job, and
-- pump() -- called once a frame from the pipeline's update -- advances
-- the queue inside a few-millisecond budget (BuildBudget suspends the
-- job's coroutine mid-loop when the slice is spent). Until a mesh lands
-- the scene simply draws without it: the engine's flat path while the
-- current map has nothing, the body-only variant while the full one (the
-- border ring) is still cooking, neighbours popping in as they finish.
-- The synchronous get() remains for probes and tests.
--
-- Meshes are cached per map id and EVICTED down to the live set (current
-- map + connected neighbours) whenever that set changes -- setLive()
-- releases far maps' GPU meshes and their Structures analysis, which is
-- what used to grow the heap by gigabytes over a cross-region trek.

-- the mod namespace (see main.lua): V.require loads a sibling module
local V = ...

local Assets = require("src.render.Assets")
local Structures = V.require("Structures")
local TileShape = V.require("TileShape")
local Voxel3D = V.require("Voxel3D")
local Budget = V.require("BuildBudget")

local ffi = nil
do
  local ok, mod = pcall(require, "ffi")
  if ok then ffi = mod end
end

local ChunkMesher = {}

-- Ring of border blocks meshed around the body, matching the width
-- TileRenderer draws so the two modes end at the same place.
local RING = 3

-- A sliver of a texel, to keep a quad's sampling inside its own tile.
-- Without any inset the perspective rasteriser lands on a NEIGHBOURING
-- tile's texel along the shared edge and stitches bright seams across the
-- whole map.
--
-- It has to be a sliver and not, as it first was, half a texel. A tile is
-- 8 texels of art across 8 world pixels -- one texel per pixel exactly --
-- and insetting the uv by half a texel at each end squeezes that art into
-- a 7-texel sample range while the quad still covers 8 world pixels. The
-- art then advances 7/8 of a texel per pixel: boundaries drift off the
-- pixel grid, one art pixel gets sampled twice and another never at all.
-- Nothing showed it until the voxel wireframe drew the grid those pixels
-- were supposed to be sitting on. Interpolation error is nowhere near a
-- fiftieth of a texel, so this is as safe against bleed and costs 0.25% of
-- a pixel of drift across a whole tile.
local INSET = 0.02

-- The south face of a volume is the artwork itself, so it draws at full
-- brightness; its top face darkens a touch so the plateau behind a
-- standing drawing reads as depth rather than repeating the same art at
-- the same energy.
local VOLUME_TOP_SHADE = 0.85

local cache = {}     -- map id -> { full = mesh|false, body = ..., grass = ... }
local gen = {}       -- map id -> generation, bumped by invalidate/evict

-- Horizontal neighbours: tile step, face direction id (see Voxel3D).
local SIDES = {
  { 1, 0, 1 },    -- +X east
  { -1, 0, 2 },   -- -X west
  { 0, 1, 5 },    -- +Z south
  { 0, -1, 6 },   -- -Z north
}

local function keyOf(tx, ty)
  return (ty + 64) * 4096 + (tx + 64)
end

-- ------------------------------------------------------------ vertex sinks

-- A sink accepts quads (4 corners, 4 uv pairs, flat or per-corner shade)
-- and finishes into a drawable mesh. The TABLE sink reproduces the
-- historical pure-Lua output -- geometry() returns its arrays for the
-- headless suite. The FFI sink packs the same six floats per vertex
-- straight into one growing native buffer, unindexed (v1 v2 v3 v1 v3 v4),
-- skipping ~a million short-lived Lua tables per route and LOVE's slow
-- table-by-table vertex upload.

-- ------------------------------------------------------- which way is up
--
-- -1 on a quad whose face points at the SKY, +1 on every other one, and the
-- sinks multiply the shade by it: the scene shader splits the magnitude back
-- out for brightness and reads the sign as the face normal (see vUp in
-- Voxel3D's SHADER). A sign costs nothing -- no fourth attribute, no extra
-- float on the twenty megabytes a route uploads -- and a shade is a product
-- of positive factors with a floor well above zero, so there is no value it
-- can collide with.
--
-- It has to be the QUAD's own geometry rather than a flag the callers pass,
-- because the callers are the problem. A shade is also how bright a face
-- draws, and both meshers have good reasons to hand a sideways face the same
-- number an up-facing one gets -- a building's south face IS the artwork, so
-- it is emitted at full energy, and a house's roof is emitted DARKER than
-- its walls so the plateau behind a standing drawing reads as depth. Anything
-- downstream that guessed "up" from that number got a snowed town of white
-- walls under grey roofs.
--
-- The test is whether the face is VERTICAL, and the world's own geometry is
-- what makes that the right question rather than a lazy one. This is a voxel
-- world: every quad in it is either an axis-aligned upright face -- a wall, a
-- facade, a flank, a standing slab -- or a surface with some rise on it. The
-- normal's Y is exactly zero on the first kind and never zero on the second,
-- so there is no threshold to tune and nothing sitting near a boundary.
--
-- A 45-degree cone was the first cut and it was wrong for the case that
-- matters most: `gableH` puts a house's roof at `rise` over half its extent,
-- and a small building with a steep roof clears 45 degrees easily -- so the
-- one surface snow most obviously belongs on would have been called a wall on
-- exactly the buildings whose roofs read most as roofs. A gable segment's n.y
-- is a constant 64 whatever its pitch, which is the answer this wants.
--
-- The SIGN of the normal is not consulted, and that is on purpose rather than
-- laziness: nothing sets a mesh cull mode, so winding is unenforced here and
-- the emitters do not agree on it -- topQuad walks its corners north to south
-- and the gable segment walks them south to north. A test that read the sign
-- would call one of those two a wall. What it costs is that a DOWN-facing
-- plane reads as up as well, which is a hull's underside and a prop's
-- footprint: surfaces a camera looking down between 50 and 75 degrees never
-- sees. The epsilon is against float noise alone -- every coordinate here is
-- a world pixel or a half of one, so a genuine zero is a genuine zero.
-- `sky` overrides it, and there is exactly one caller who may: Structures'
-- round hulls. A hull's front face is a flat plane in the mesh and a CURVED
-- surface in the drawing, so the geometry genuinely does not know -- it reads
-- the whole front of a tree as upright, and a snowfall that buried the ground
-- and the roofs left every canopy standing green. Nothing else gets to claim
-- it: a builder that wants a bright sideways face still has to be told apart
-- from a roof by its shape, which is the entire point of this function.
local function faceSign(c, sky)
  if sky ~= nil then return sky and -1 or 1 end
  local a, b, d = c[1], c[2], c[3]
  local dx, dz = b[1] - a[1], b[3] - a[3]
  local ex, ez = d[1] - a[1], d[3] - a[3]
  local ny = dz * ex - dx * ez
  return (ny > 1e-6 or ny < -1e-6) and -1 or 1
end

local function newTableSink()
  local verts, indices, quads = {}, {}, 0
  return {
    push = function(c, uv, shade, sky)
      local flat = type(shade) ~= "table"
      local s = faceSign(c, sky)
      for i = 1, 4 do
        local cc, t = c[i], uv[i]
        verts[#verts + 1] = { cc[1], cc[2], cc[3], t[1], t[2],
                              s * (flat and shade or shade[i]) }
      end
      Voxel3D.pushQuad(indices, quads)
      quads = quads + 1
    end,
    results = function()
      return verts, indices, quads
    end,
    finish = function()
      return Voxel3D.newMesh(verts, indices)
    end,
  }
end

-- Indexed, 0-based: quad corners 1,2,3,4 (Voxel3D.FACE_CORNERS order)
-- become two triangles (0,1,2) and (0,2,3) off the SAME four stored
-- vertices -- the table-sink/quadsMesh path (Voxel3D.pushQuad) has done
-- this for grass/flowers/figures since before this file's chunking existed;
-- this is that same fan, just 0-based for the raw index Data LOVE's
-- Mesh:setVertexMap(datatype, data, ...) overload expects (the Lua-table
-- overload does the 1-based-to-0-based subtraction itself; the raw-Data one
-- does not).
--
-- This only removes each quad's OWN duplicate corners (corners 1 and 3,
-- which TRI_ORDER above used to repeat into the unindexed stream) -- it
-- does not weld a quad to its neighbours, which still get their own
-- independent 4 corners. The water surface's watertightness (see Voxel3D's
-- SHADER note on vWater) depends on adjacent quads NOT sharing a vertex so
-- their displacement -- a pure function of world XZ -- agrees at the seam
-- either way; nothing here changes that.
local QUAD_IDX = { 0, 1, 2, 0, 2, 3 }

local function newFfiSink(cap0)
  local capQuads = cap0 or 4096
  local buf = ffi.new("float[?]", capQuads * 4 * 6)      -- 4 verts/quad
  local ibuf = ffi.new("uint32_t[?]", capQuads * 6)      -- 6 indices/quad
  local nQuads = 0
  local sink
  sink = {
    push = function(c, uv, shade, sky)
      if nQuads + 1 > capQuads then
        local grownV = ffi.new("float[?]", capQuads * 2 * 4 * 6)
        ffi.copy(grownV, buf, nQuads * 4 * 6 * 4)
        local grownI = ffi.new("uint32_t[?]", capQuads * 2 * 6)
        ffi.copy(grownI, ibuf, nQuads * 6 * 4)
        buf, ibuf, capQuads = grownV, grownI, capQuads * 2
      end
      local flat = type(shade) ~= "table"
      local s = faceSign(c, sky)
      local base = nQuads * 4 * 6
      for i = 1, 4 do
        local cc, t = c[i], uv[i]
        buf[base] = cc[1]
        buf[base + 1] = cc[2]
        buf[base + 2] = cc[3]
        buf[base + 3] = t[1]
        buf[base + 4] = t[2]
        buf[base + 5] = s * (flat and shade or shade[i])
        base = base + 6
      end
      local ibase, vbase = nQuads * 6, nQuads * 4
      for k = 1, 6 do
        ibuf[ibase + k - 1] = vbase + QUAD_IDX[k]
      end
      nQuads = nQuads + 1
    end,
    finish = function()
      if nQuads == 0 then return nil end
      local n = nQuads * 4          -- vertex count
      -- upload in slices with budget ticks between: a route-sized mesh
      -- is ~10-20MB and one atomic setVertices was the last remaining
      -- frame spike. The mesh is not cached (so never drawn) until the
      -- whole upload lands, and LuaJIT yields fine across pcall.
      local ok, mesh = pcall(function()
        local m = love.graphics.newMesh(Voxel3D.FORMAT, n,
                                        "triangles", "static")
        local CHUNK = 65536              -- vertices per slice (~1.5MB)
        local i = 0
        while i < n do
          local count = math.min(CHUNK, n - i)
          local bytes = count * 6 * 4
          local data = love.data.newByteData(bytes)
          ffi.copy(data:getFFIPointer(), buf + i * 6, bytes)
          m:setVertices(data, i + 1)
          data:release()
          i = i + count
          Budget.check()
        end
        -- the index buffer: LOVE auto-picks uint16 vs uint32 by vertex
        -- count when setVertexMap gets a Lua table, but the raw-Data
        -- overload (used here to avoid building a several-hundred-
        -- thousand-entry Lua table) takes the width explicitly, so this
        -- mirrors that same rule (vertex::getIndexDataTypeFromMax in
        -- LOVE's own source) by hand.
        local nIdx = nQuads * 6
        Budget.check()
        if n <= 65535 then
          local u16 = ffi.new("uint16_t[?]", nIdx)
          for k = 0, nIdx - 1 do
            u16[k] = ibuf[k]
            if k % 16384 == 0 then Budget.tick() end
          end
          local bytes = nIdx * 2
          local data = love.data.newByteData(bytes)
          ffi.copy(data:getFFIPointer(), u16, bytes)
          m:setVertexMap(data, "uint16", nIdx)
          data:release()
        else
          local bytes = nIdx * 4
          local data = love.data.newByteData(bytes)
          ffi.copy(data:getFFIPointer(), ibuf, bytes)
          m:setVertexMap(data, "uint32", nIdx)
          data:release()
        end
        return m
      end)
      return ok and mesh or nil
    end,
  }
  return sink
end

local function newSink(cap0)
  if ffi and love and love.data and love.data.newByteData
     and love.graphics and love.graphics.newMesh then
    return newFfiSink(cap0)
  end
  return newTableSink()
end

-- ------------------------------------------------------- spatial chunking
--
-- The module has been called ChunkMesher since the first cut, but until now
-- there were no chunks: a map's terrain was ONE mesh, and every frame
-- submitted all of it -- plus all of every connected neighbour's -- whether
-- or not any of it was on screen, and then again from the sun. The mesher's
-- own note puts a route-sized mesh at 10 to 20 MB of vertices. A house is
-- a few hundred kilobytes, which is why indoors was always fine and a route
-- never was: the cost is not the camera, it is the map.
--
-- So the geometry walk now feeds a sink per spatial bucket instead of one
-- for the map, and a draw submits only the buckets whose bounds meet the
-- camera's. Nothing in runGeometry knows about it -- a quad is routed by
-- where its first corner landed, which is the one thing every quad in this
-- mesher has in common.
--
-- The cells are WIDE AND SHALLOW on purpose, and that is not arbitrary:
-- Gen 1 overworld maps are narrow and tall (a route is ten blocks across
-- and twenty down), while the view is the other way round -- wide, and
-- shallow in the direction the camera looks. So almost all of the culling
-- that is there to be had is along Z, and paying for fine cells along X
-- would buy nothing but draw calls.
local CHUNK_X = 256          -- world pixels: eight blocks across
local CHUNK_Z = 64           -- two blocks deep

-- Slack on a cell's bounds, in world pixels. A quad is filed by its first
-- corner, and a few of the things this mesher emits -- a stamped tree
-- hull, a prop's prism -- reach past the cell that corner landed in. This
-- is bigger than any of them; over-generous bounds cost a little culling
-- and nothing else, while short ones would clip geometry out of a frame it
-- belongs in.
local CHUNK_MARGIN = 96

-- A finished map's terrain: the list of chunk meshes and their bounds.
--
-- It carries a `release` of its own, which is what lets every existing
-- caller keep treating a map's terrain as one opaque thing -- the cache's
-- swapSlot and releaseEntry call `mesh.release` and neither has to learn
-- that there is now more than one mesh under it.
local Group = {}
Group.__index = Group

function Group:release()
  for _, ch in ipairs(self.chunks) do
    if ch.mesh and ch.mesh.release then pcall(ch.mesh.release, ch.mesh) end
  end
  self.chunks = {}
end

local function newChunkedSink()
  local buckets, order = {}, {}

  local function bucketFor(x, z)
    local bx = math.floor(x / CHUNK_X)
    local bz = math.floor(z / CHUNK_Z)
    local k = bz * 8192 + bx
    local b = buckets[k]
    if not b then
      -- a small starting buffer, unlike the single-sink case: there are
      -- tens of these alive at once during a build and the FFI sink grows
      -- by doubling anyway
      b = { sink = newSink(512), ymax = 0,
            x0 = bx * CHUNK_X - CHUNK_MARGIN,
            z0 = bz * CHUNK_Z - CHUNK_MARGIN,
            x1 = (bx + 1) * CHUNK_X + CHUNK_MARGIN,
            z1 = (bz + 1) * CHUNK_Z + CHUNK_MARGIN }
      buckets[k] = b
      order[#order + 1] = b
    end
    return b
  end

  return {
    push = function(c, uv, shade, sky)
      local corner = c[1]
      local b = bucketFor(corner[1], corner[3])
      -- How TALL this cell gets, which is the other half of culling it.
      --
      -- The camera looks north and down, so a cell is not out of frame just
      -- because its GROUND is past where the camera can still see ground: a
      -- building standing there projects upward, into the sky above the
      -- horizon, and is plainly visible. Height therefore reads as extra
      -- northward reach at the draw (see drawGroup).
      --
      -- Tracked per cell rather than assumed for all of them, because the
      -- assumption has to be the WORST case -- a 160px gabled roof -- and
      -- applying that to open grass would push the cull line most of a
      -- route further out than flat ground needs. Most cells are flat.
      local y = c[1][2]
      if c[2][2] > y then y = c[2][2] end
      if c[3][2] > y then y = c[3][2] end
      if c[4][2] > y then y = c[4][2] end
      if y > b.ymax then b.ymax = y end
      b.sink.push(c, uv, shade, sky)
    end,
    finish = function()
      local chunks = {}
      for _, b in ipairs(order) do
        -- finish() is where the upload happens, and it yields to the build
        -- budget partway through a big one -- so this loop is already a
        -- sliced operation and needs no ticking of its own
        local mesh = b.sink.finish()
        if mesh then
          chunks[#chunks + 1] = { mesh = mesh, x0 = b.x0, z0 = b.z0,
                                  x1 = b.x1, z1 = b.z1, ymax = b.ymax }
        end
      end
      if #chunks == 0 then return nil end
      return setmetatable({ chunks = chunks }, Group)
    end,
  }
end

-- -------------------------------------------------------------- geometry

-- Emit the raw geometry for `map` into `sink`. `bodyOnly` skips the
-- border ring -- the shape the 2D path's drawMapOnly has always had: a
-- neighbour map contributes its body, and only the CURRENT map supplies
-- the ring around the view.
--
-- `masks` (full variant only) lists rectangles, in this map's world
-- pixels, where connected neighbour BODIES sit: ring geometry inside them
-- is suppressed. The 2D renderer never needed this because it painted
-- neighbour bodies OVER the ring; with a depth buffer the ring's standing
-- trees would rise straight through the neighbour's flat ground -- cross
-- into Route 1 and a wall of border trees sprouts over Pallet.
--
-- Kept free of any GPU call so it can be exercised headless -- the
-- geometry is the part with the interesting invariants, and a suite that
-- needed a real GL context to check them would never run in CI.
local function runGeometry(map, bodyOnly, masks, sink)
  local push = sink.push
  local tileset = map.tileset
  local S = Structures.forMap(map)
  local perRow = tileset.tilesPerRow or 16
  local atlasW = tileset.imageWidth or (perRow * 8)
  local atlasH = tileset.imageHeight or 48

  local function heightAt(tx, ty)
    local k = keyOf(tx, ty)
    if S.skip[k] then return 0 end
    local run = S.runs[k]
    if run then return run.h end
    local s = S.shapeAt[k]
    return s and s.h or 0
  end

  -- one atlas-rect UV, optionally cropped to art rows [vTop, vBot] of 8
  local function uvRect(tile, vTop, vBot)
    local ax = (tile % perRow) * 8
    local ay = math.floor(tile / perRow) * 8
    local vi = math.min(INSET, (vBot - vTop) / 4)
    return (ax + INSET) / atlasW, (ax + 8 - INSET) / atlasW,
           (ay + vTop + vi) / atlasH, (ay + vBot - vi) / atlasH
  end

  -- ------------------------------------------------------ ambient occlusion
  --
  -- Ambient light is what reaches a surface from the sky at large, so it is
  -- blocked by how much geometry crowds a point rather than by where the
  -- sun happens to be -- which makes it the exact complement of the shadow
  -- pass, and the reason both are worth having. The shadow map draws the
  -- long directional shadow a building throws; this draws the dark seam in
  -- every corner the sky cannot see into, at every scale finer than a
  -- shadow map texel.
  --
  -- Baked per vertex, the classic voxel way: each corner counts the
  -- neighbours that crowd it and steps down once per neighbour, and the
  -- rasteriser interpolates the steps into a smooth falloff. Costs exactly
  -- nothing at draw time, and it is resolution-independent -- a screen
  -- space pass would blur across the pixel grid this whole mode is built
  -- to keep crisp.
  --
  -- (What was here before was a one-directional contact shadow keyed to a
  -- sun in the northwest: two neighbours, one corner, top faces only.)

  -- Intensity. Both terms below are DARKENING amounts rather than
  -- multipliers, so this one number scales the whole effect: 1.0 is the
  -- barely-there first cut, and everything is expressed against it.
  local AO_STRENGTH = 2.4
  local AO_STEP = 0.09 * AO_STRENGTH      -- per crowding neighbour, max 3
  local AO_EDGE = 1 - 0.14 * AO_STRENGTH  -- creases / corners on a face
  local AO_GROUND = 0.12 * AO_STRENGTH    -- a prop's contact with the floor
  local AO_RISE = 6                       -- px over which the floor lets go
  local AO_FLOOR = 0.25                   -- never let a vertex reach black

  -- Both sinks copy a per-corner shade straight out into the vertex stream
  -- and keep no reference, so these two scratch rows are reused for every
  -- quad on the map rather than allocating a table per face -- a route
  -- builds a few hundred thousand of them.
  local aoTop = { 0, 0, 0, 0 }
  local aoSide = { 0, 0, 0, 0 }

  -- A top face's four corners, each occluded by the three cells that touch
  -- it: two edge neighbours and the diagonal between them.
  local function aoShades(tx, ty, h, shade)
    local n = heightAt(tx, ty - 1) > h
    local s = heightAt(tx, ty + 1) > h
    local e = heightAt(tx + 1, ty) > h
    local w = heightAt(tx - 1, ty) > h
    local nw = heightAt(tx - 1, ty - 1) > h
    local ne = heightAt(tx + 1, ty - 1) > h
    local sw = heightAt(tx - 1, ty + 1) > h
    local se = heightAt(tx + 1, ty + 1) > h
    if not (n or s or e or w or nw or ne or sw or se) then return shade end
    local function corner(a, b, d)
      local k = 0
      if a then k = k + 1 end
      if b then k = k + 1 end
      -- a diagonal wedged behind both of its edges adds nothing: the
      -- corner is already as enclosed as it can get, and counting it
      -- again is what turns an ordinary inside corner black
      if d and not (a and b) then k = k + 1 end
      -- floored, so cranking AO_STRENGTH deepens the seams instead of
      -- punching holes of pure black through the world
      return shade * math.max(AO_FLOOR, 1 - AO_STEP * k)
    end
    -- corners in topQuad order: NW, NE, SE, SW
    aoTop[1], aoTop[2] = corner(n, w, nw), corner(n, e, ne)
    aoTop[3], aoTop[4] = corner(s, e, se), corner(s, w, sw)
    return aoTop
  end

  -- The same idea on an upright face, where the crowding is of two kinds:
  -- the CREASE it rises out of (the band sitting on the ground, or on
  -- whatever lower neighbour exposed the face) and the INSIDE CORNERS
  -- where the columns flanking it stand proud of the band. `hl`/`hr` are
  -- those flanking heights in FACE order -- left then right as seen from
  -- outside, per LATERAL below -- so the shades line up with sideQuad's
  -- corners without the caller thinking about compass directions.
  local LATERAL = {
    [1] = { 0, 1, 0, -1 },    -- east face:  left south, right north
    [2] = { 0, -1, 0, 1 },    -- west face:  left north, right south
    [5] = { -1, 0, 1, 0 },    -- south face: left west,  right east
    [6] = { 1, 0, -1, 0 },    -- north face: left east,  right west
  }
  -- Ground contact for the prebuilt prop quads -- the per-pixel plants,
  -- signs and lone trees, and the round-tree stamps. Those arrive from
  -- Structures already finished, so the neighbour counting above has no
  -- columns to count. What it CAN say is that the ground plane itself
  -- blocks half the sky, so the closer a voxel sits to it the less ambient
  -- light reaches it -- which is what plants a prop on the floor instead
  -- of leaving it looking pasted over the top.
  local aoProp = { 0, 0, 0, 0 }
  local function groundShades(c, shade)
    if type(shade) == "table" then return shade end
    local y1, y2, y3, y4 = c[1][2], c[2][2], c[3][2], c[4][2]
    if math.min(y1, y2, y3, y4) >= AO_RISE then return shade end
    for i = 1, 4 do
      local t = c[i][2] / AO_RISE
      aoProp[i] = shade * (t >= 1 and 1 or (1 - AO_GROUND * (1 - t)))
    end
    return aoProp
  end

  local AO_CORNER = math.max(AO_FLOOR, AO_EDGE * AO_EDGE)  -- crease AND flank
  local function sideShades(hl, hr, y0, y1, crease, shade)
    if not (crease or hl > y0 or hr > y0) then return shade end
    -- corners run bottom-left, bottom-right, top-right, top-left
    local base = crease and AO_EDGE or 1
    aoSide[1] = shade * (hl > y0 and (crease and AO_CORNER or AO_EDGE) or base)
    aoSide[2] = shade * (hr > y0 and (crease and AO_CORNER or AO_EDGE) or base)
    aoSide[3] = shade * (hr > y1 and AO_EDGE or 1)
    aoSide[4] = shade * (hl > y1 and AO_EDGE or 1)
    return aoSide
  end

  local function topQuad(x0, z0, h, tile, shade)
    local u0, u1, v0, v1 = uvRect(tile, 0, 8)
    push({ { x0, h, z0 }, { x0 + 8, h, z0 },
           { x0 + 8, h, z0 + 8 }, { x0, h, z0 + 8 } },
         { { u0, v0 }, { u1, v0 }, { u1, v1 }, { u0, v1 } },
         aoShades(x0 / 8, z0 / 8, h, shade))
  end

  -- vertical quad for face direction `d` of the tile column at (x0, z0),
  -- spanning heights [y0, y1] and showing art rows [vTop, vBot] of `tile`.
  -- Corners run bottom-left, bottom-right, top-right, top-left as seen
  -- from outside; u follows +X on the north/south faces so a door or sign
  -- never draws mirrored.
  local function sideQuad(d, x0, z0, y0, y1, tile, vTop, vBot, shade)
    local x1, z1 = x0 + 8, z0 + 8
    local c
    if d == 5 then                                       -- south, at z1
      c = { { x0, y0, z1 }, { x1, y0, z1 }, { x1, y1, z1 }, { x0, y1, z1 } }
    elseif d == 6 then                                   -- north, at z0
      c = { { x1, y0, z0 }, { x0, y0, z0 }, { x0, y1, z0 }, { x1, y1, z0 } }
    elseif d == 1 then                                   -- east, at x1
      c = { { x1, y0, z1 }, { x1, y0, z0 }, { x1, y1, z0 }, { x1, y1, z1 } }
    else                                                 -- west, at x0
      c = { { x0, y0, z0 }, { x0, y0, z1 }, { x0, y1, z1 }, { x0, y1, z0 } }
    end
    local u0, u1, v0, v1 = uvRect(tile, vTop, vBot)
    push(c, { { u0, v1 }, { u1, v1 }, { u1, v0 }, { u0, v0 } }, shade)
  end

  local def = map.def
  local tw, th = def.width * 4, def.height * 4         -- map size in tiles
  local r = bodyOnly and 0 or RING * 4

  -- true when the (ring) position lies under a connected neighbour's body
  local function masked(px0, pz0, px1, pz1)
    if not masks then return false end
    for _, mk in ipairs(masks) do
      if px1 > mk[1] and px0 < mk[3] and pz1 > mk[2] and pz0 < mk[4] then
        return true
      end
    end
    return false
  end

  -- The inclusive variant for OBJECT quads: a quad TOUCHING a neighbour
  -- body counts as under it. The old test took the quad's center with
  -- strict bounds, and a quad whose center sat exactly on the body's
  -- edge line escaped the mask -- stringing stray pixel fragments of
  -- otherwise-dropped border trees along every map seam.
  local function maskedClosed(px0, pz0, px1, pz1)
    if not masks then return false end
    for _, mk in ipairs(masks) do
      if px1 >= mk[1] and px0 <= mk[3] and pz1 >= mk[2] and pz0 <= mk[4] then
        return true
      end
    end
    return false
  end

  for ty = -r, th + r - 1 do
    for tx = -r, tw + r - 1 do
      Budget.tick()
      local k = keyOf(tx, ty)
      local s, tile = S.shapeAt[k], S.tileAt[k]
      local inBody = tx >= 0 and ty >= 0 and tx < tw and ty < th
      if not inBody and masked(tx * 8, ty * 8, tx * 8 + 8, ty * 8 + 8) then
        s = nil
      end

      -- Under the TREES fill the border wall is MODELLED or it is not there
      -- (see Structures' hullRingOnly): a ring cell nothing claimed would
      -- be a flat-topped box standing beside carved trunks, which reads as
      -- a painted-on plateau rather than forest. Structures already stops
      -- the ring at the carve distance; this catches the odd cell inside it
      -- that the 2x2 grouping could not take -- a canopy whose partners
      -- fall outside the shortened ring is left unclaimed, and one strip of
      -- boxes along an edge is the whole artefact this avoids.
      if not inBody and S.hideBareRing and not S.skip[k] then
        s = nil
      end

      if s and S.skip[k] then
        -- an object stands here; paint its synthesized ground and let the
        -- prebuilt prism quads (appended below) carry the art
        local g = S.ground[k]
        if g then
          topQuad(tx * 8, ty * 8, 0, g, 1)
          -- the claimed tile is still ground at height 0, and water next
          -- door still recesses below it: without the same below-ground
          -- side bands ordinary ground emits, the two-pixel shoreline
          -- face is a slit into the sky behind the mesh -- which is
          -- exactly what a building plot or a sign standing at the
          -- waterline showed. Same bands, cut from the synthesized
          -- ground's own art
          for _, side in ipairs(SIDES) do
            local nh = heightAt(tx + side[1], ty + side[2])
            if nh < 0 then
              local d = side[3]
              local lat = LATERAL[d]
              local hl = lat and heightAt(tx + lat[1], ty + lat[2]) or 0
              local hr = lat and heightAt(tx + lat[3], ty + lat[4]) or 0
              for band = math.floor(nh / 8), -1 do
                local y0 = math.max(nh, band * 8)
                local y1 = math.min(0, band * 8 + 8)
                if y1 > y0 then
                  sideQuad(d, tx * 8, ty * 8, y0, y1, g,
                           (band * 8 + 8) - y1, (band * 8 + 8) - y0,
                           sideShades(hl, hr, y0, y1, y0 <= nh,
                                      Voxel3D.FACE_SHADE[d]))
                end
              end
            end
          end
        end
      elseif s then
        local run = S.runs[k]
        local h = run and run.h or s.h
        local x0, z0 = tx * 8, ty * 8

        -- top face. A roofed volume gets a GABLE segment: the roof rises
        -- from the facade top at the south eave to a ridge across the
        -- footprint's middle, then falls back to the facade at the north
        -- edge -- so the far side sits LOW. (The first cut was a shed
        -- plane rising all the way north, which turns a building into a
        -- ramp.) The south slope wears the structure's roof rows (ridge
        -- art at the ridge, eaves art at the eave); the back slope
        -- mirrors them. Exposed east/west flanks hip: their outer edge
        -- drops toward the eave, rounding the drawn corner tiles into 45
        -- degree corners. Flat-topped volumes wear their top rows;
        -- everything else its own art.
        if run and run.rise > 0 then
          local mid = run.extent / 2
          local function gableH(d)     -- d = rows north of the south eave
            local t = d <= mid and d / mid or (run.extent - d) / (run.extent - mid)
            return run.h + run.rise * math.max(0, math.min(1, t))
          end
          local d0 = run.front - ty                -- rows from the south edge
          local hS = gableH(d0)
          local hN = gableH(d0 + 1)
          -- art by proximity to the ridge, mirrored over the back
          local rel = 1 - math.abs(d0 + 0.5 - mid) / math.max(mid, 0.5)
          local idx = math.min(run.roofRows - 1,
                               math.floor((1 - rel) * run.roofRows))
          local roofTile = map:tileAt(tx, run.north + idx)
          local swY, seY, neY, nwY = hS, hS, hN, hN
          if heightAt(tx - 1, ty) < run.h then     -- west flank: hip
            swY = math.max(run.h, hS - 8)
            nwY = math.max(run.h, hN - 8)
          end
          if heightAt(tx + 1, ty) < run.h then     -- east flank: hip
            seY = math.max(run.h, hS - 8)
            neY = math.max(run.h, hN - 8)
          end
          local u0, u1, v0, v1 = uvRect(roofTile, 0, 8)
          push({ { x0, swY, z0 + 8 }, { x0 + 8, seY, z0 + 8 },
                 { x0 + 8, neY, z0 }, { x0, nwY, z0 } },
               { { u0, v1 }, { u1, v1 }, { u1, v0 }, { u0, v0 } }, 0.95)
        elseif run then
          local m = math.min(2, run.extent)
          local topTile = map:tileAt(tx, run.north + ((ty - run.north) % m))
          topQuad(x0, z0, h, topTile, VOLUME_TOP_SHADE)
        else
          local topTile = tile
          if s.art == "upright" and s.authored then
            -- Top art for a pinned box.  A furniture drawing is top-view
            -- rows over floor(h/8) face-on rows the fold stands upright;
            -- a face row's top would repeat its front art lying flat, so
            -- it wears the nearest row above the face block instead --
            -- the drawn tabletop (and whatever sits on it) stays on top,
            -- and a fully-folded structure (wall, desk) tops with its
            -- northmost row.
            local north, front = ty, ty
            while ty - north < 6 do
              local bs = S.shapeAt[keyOf(tx, north - 1)]
              if bs and bs.authored and bs.class == s.class then
                north = north - 1
              else
                break
              end
            end
            while front - ty < 6 do
              local bs = S.shapeAt[keyOf(tx, front + 1)]
              if bs and bs.authored and bs.class == s.class then
                front = front + 1
              else
                break
              end
            end
            local row = math.min(ty, front - math.floor(h / 8))
            if row < north then
              -- the whole run folded onto the face: top with the drawn
              -- row just above it when that row is furniture too (a
              -- bookcase wearing its shelf-top trim), else with the
              -- run's own top row
              local above = S.shapeAt[keyOf(tx, north - 1)]
              row = (above and above.authored and above.art == "upright")
                    and (north - 1) or north
            end
            topTile = S.tileAt[keyOf(tx, row)]
          end
          topQuad(x0, z0, h, topTile,
                  s.art == "upright" and VOLUME_TOP_SHADE or 1)
        end

        -- sides: 8px bands wherever the neighbour is lower. Band k spans
        -- heights [8k, 8k+8) and shows one full tile of art; a partial
        -- band crops the art rows to match, so nothing ever stretches.
        for _, side in ipairs(SIDES) do
          local nh = heightAt(tx + side[1], ty + side[2])
          if nh < h then
            local d = side[3]
            -- the columns flanking this face, for the inside-corner term:
            -- fixed for the whole face, so they are read once rather than
            -- once per 8px band
            local lat = LATERAL[d]
            local hl = lat and heightAt(tx + lat[1], ty + lat[2]) or 0
            local hr = lat and heightAt(tx + lat[3], ty + lat[4]) or 0
            for band = math.floor(nh / 8), math.ceil(h / 8) - 1 do
              local y0 = math.max(nh, band * 8)
              local y1 = math.min(h, band * 8 + 8)
              if y1 > y0 then
                local src, shade = tile, Voxel3D.FACE_SHADE[d]
                if run then
                  -- fold the structure's artwork up this face: band k
                  -- samples the map row k tiles north of the structure's
                  -- front, clamped to its extent. The south face is the
                  -- drawing itself (full brightness); the other sides wear
                  -- the same rows darkened, so a building's flank matches
                  -- its face instead of smearing one tile
                  if d == 6 then
                    src = map:tileAt(tx, math.min(run.front,
                                                  run.north + band))
                  else
                    src = map:tileAt(tx, math.max(run.north,
                                                  run.front - band))
                  end
                  if d == 5 then shade = 1 end
                elseif s.art == "upright" then
                  -- profile-authored upright (a pinned wall or furniture
                  -- box): fold the drawing up the face, band 0 the
                  -- structure's southmost same-class row and higher bands
                  -- the rows north of it, repeating past the top.  The
                  -- south face is the drawing itself (full brightness);
                  -- flanks and back wear the same front stack darkened, so
                  -- a desk's side matches its face instead of smearing a
                  -- different jumble per row.
                  if d == 5 then shade = 1 end
                  local front = ty
                  while front < ty + 6 do
                    local fs2 = S.shapeAt[keyOf(tx, front + 1)]
                    if fs2 and fs2.authored and fs2.class == s.class then
                      front = front + 1
                    else
                      break
                    end
                  end
                  local fk = keyOf(tx, front - band)
                  local fs = S.shapeAt[fk]
                  if fs and fs.authored and fs.class == s.class then
                    src = S.tileAt[fk]
                  end
                end
                sideQuad(d, x0, z0, y0, y1, src,
                         (band * 8 + 8) - y1, (band * 8 + 8) - y0,
                         sideShades(hl, hr, y0, y1, y0 <= nh, shade))
              end
            end
          end
        end
      end
    end
  end

  -- Prebuilt quads from Structures (per-pixel voxel props, lathed
  -- columns) plus the round-tree stamps expanded in place. Keep rules,
  -- by the quad's own extent:
  --   body-only   the quad must overlap the OPEN body interval -- a
  --               neighbour's ring props must not march past its edge
  --               into this map, and a quad lying exactly ON the edge
  --               plane would z-fight the map that owns that plane.
  --   full        anything overlapping the body stays whole (props that
  --               straddle the edge no longer shed their outer half);
  --               pure ring quads drop when they touch a neighbour body
  --               (maskedClosed), which is what strings of seam pixels
  --               were: fragments of dropped border trees whose centers
  --               sat exactly on the boundary line.
  local bw, bh = tw * 8, th * 8
  local function keepQuad(x0, z0, x1, z1)
    local overBody = x1 > 0 and x0 < bw and z1 > 0 and z0 < bh
    if bodyOnly then return overBody end
    return overBody or not maskedClosed(x0, z0, x1, z1)
  end

  -- A face lying EXACTLY on a body boundary plane is ambiguous to the
  -- rect tests above: a body structure's outward facade (a Saffron row
  -- house whose front row is the map's last row, its south wall on the
  -- shared plane with Route 6) and the inward face of a ring scrap
  -- occupy the same degenerate rect, and the strict overBody plus the
  -- closed mask dropped BOTH -- which is why those facades were missing.
  -- The winding tells them apart: a face pointing AWAY from the body
  -- belongs to this map's own edge-row structure and nothing in the
  -- neighbour will ever draw that plane, so it stays; a face pointing
  -- INTO the body is the scrap the mask rules exist to kill, and falls
  -- through to them.
  local function outwardOnEdge(q, x0, z0, x1, z1)
    if z0 == z1 and (z0 == 0 or z0 == bh) and x1 > 0 and x0 < bw then
      local nz = (q[2][1] - q[1][1]) * (q[3][2] - q[1][2])
                 - (q[2][2] - q[1][2]) * (q[3][1] - q[1][1])
      return (z0 == bh and nz > 0) or (z0 == 0 and nz < 0)
    end
    if x0 == x1 and (x0 == 0 or x0 == bw) and z1 > 0 and z0 < bh then
      local nx = (q[2][2] - q[1][2]) * (q[3][3] - q[1][3])
                 - (q[2][3] - q[1][3]) * (q[3][2] - q[1][2])
      return (x0 == bw and nx > 0) or (x0 == 0 and nx < 0)
    end
    return false
  end

  local scUV = { { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } }
  local function quadUV(q)
    if q.uv then return q.uv end
    for i = 1, 4 do
      scUV[i][1], scUV[i][2] = q.u, q.v
    end
    return scUV
  end

  -- q.lod tags small-silhouette props (buildObject's per-source-pixel
  -- prisms -- plants, signs, lone trees). bodyOnly used to DROP them, and
  -- to skip round-tree stamps below, as a memory cut for neighbours.
  -- That was the wrong lever: a neighbour is what you walk INTO, and
  -- stripping its silhouette made the forest "load" when the seam
  -- promoted the map -- trees popping in one frame is worse than the
  -- bytes they cost. bodyOnly means "no border RING", not "less world".
  -- The tag stays on the quads for a future true distance LOD; it is
  -- not consulted here.
  for _, q in ipairs(S.objectQuads) do
    Budget.tick()
    local x0 = math.min(q[1][1], q[2][1], q[3][1], q[4][1])
    local x1 = math.max(q[1][1], q[2][1], q[3][1], q[4][1])
    local z0 = math.min(q[1][3], q[2][3], q[3][3], q[4][3])
    local z1 = math.max(q[1][3], q[2][3], q[3][3], q[4][3])
    -- q.own: a body-anchored structure's own quad (a building placed by
    -- Buildings.build, whose scan never leaves the body). Exempt from
    -- the edge keep-rules entirely: its eave legitimately overhangs the
    -- boundary plane into the neighbour's airspace, and no variant of
    -- the neighbour will ever draw that geometry
    if q.own or outwardOnEdge(q, x0, z0, x1, z1)
       or keepQuad(x0, z0, x1, z1) then
      push({ q[1], q[2], q[3], q[4] }, quadUV(q), groundShades(q, q.shade))
    end
  end

  -- true when the rect sits entirely inside one neighbour-body rect
  local function containedInMask(x0, z0, x1, z1)
    if not masks then return false end
    for _, mk in ipairs(masks) do
      if x0 >= mk[1] and x1 <= mk[3] and z0 >= mk[2] and z1 <= mk[4] then
        return true
      end
    end
    return false
  end

  -- round-tree stamps: the shared hull template translated per cell,
  -- through reusable scratch corners so expansion allocates nothing.
  -- A hull spans at most its own footprint -- one 16px cell unless the
  -- stamp carries a wider radius (the 2x2-cell canopy groups) -- so one
  -- rect test usually answers for the whole stamp: strictly interior
  -- stamps keep every quad, ring stamps buried under a neighbour body
  -- (or, body-only, ring stamps full stop) skip without touching their
  -- quads. Only stamps crossing a boundary walk quad by quad.
  --
  -- bodyOnly used to skip this whole pass (see objectQuads note above).
  -- It no longer does: the keep/skip rules below already drop stamps on
  -- the ring and keep the interior, which is exactly the silhouette a
  -- neighbour must show so a seam crossing does not plant a forest.
  local sc = { { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }
  for _, st in ipairs(S.roundStamps or {}) do
    local mx, mz = st.mx, st.mz
    local sr = st.r or 8
    local sx0, sz0, sx1, sz1 = mx - sr, mz - sr, mx + sr, mz + sr
    local interior = sx0 > 0 and sx1 < bw and sz0 > 0 and sz1 < bh
    local overBody = sx1 > 0 and sx0 < bw and sz1 > 0 and sz0 < bh
    local keepAll, skipAll
    if bodyOnly then
      keepAll = interior
      skipAll = not overBody
    else
      keepAll = interior or not maskedClosed(sx0, sz0, sx1, sz1)
      skipAll = not overBody and containedInMask(sx0, sz0, sx1, sz1)
    end
    if not skipAll then
      for _, q in ipairs(st.quads) do
        Budget.tick()
        for i = 1, 4 do
          local c, s2 = q[i], sc[i]
          s2[1] = c[1] + mx
          s2[2] = c[2]
          s2[3] = c[3] + mz
        end
        local ok = keepAll
        if not ok then
          local x0 = math.min(sc[1][1], sc[2][1], sc[3][1], sc[4][1])
          local x1 = math.max(sc[1][1], sc[2][1], sc[3][1], sc[4][1])
          local z0 = math.min(sc[1][3], sc[2][3], sc[3][3], sc[4][3])
          local z1 = math.max(sc[1][3], sc[2][3], sc[3][3], sc[4][3])
          ok = keepQuad(x0, z0, x1, z1)
        end
        if ok then
          -- q.sky: the hull's own word on whether this row of its shell is
          -- the crown the snow lands on. The corners cannot say -- a canopy's
          -- front is a flat plane standing for a curved one -- so this is the
          -- one quad in the mesher that overrides faceSign.
          push(sc, quadUV(q), groundShades(sc, q.shade), q.sky)
        end
      end
    end
  end
end

-- The raw geometry for `map`: (vertex list, triangle index list, quad
-- count). Synchronous and GPU-free -- the headless suite and the probes
-- exercise the invariants through this.
function ChunkMesher.geometry(map, bodyOnly, masks)
  local sink = newTableSink()
  runGeometry(map, bodyOnly, masks, sink)
  return sink.results()
end

-- Build the mesh for `map` synchronously. Returns nil when there is
-- nothing to draw or meshes are unavailable (headless).
function ChunkMesher.build(map, bodyOnly, masks)
  local sink = newChunkedSink()
  runGeometry(map, bodyOnly, masks, sink)
  return sink.finish()
end

local function quadsMesh(quads)
  if #quads == 0 then return nil end
  local verts, indices, n = {}, {}, 0
  for _, q in ipairs(quads) do
    -- the same up-face sign the sinks apply (see faceSign): this mesh is
    -- drawn in a pass that has the snow on, so a tuft that skipped it would
    -- be the one thing in a white field taking a wall's share of it
    local s = faceSign(q, q.sky)
    for i = 1, 4 do
      local c = q[i]
      local uv = q.uv and q.uv[i] or { q.u, q.v }
      verts[#verts + 1] = { c[1], c[2], c[3], uv[1], uv[2], s * q.shade }
    end
    Voxel3D.pushQuad(indices, n)
    n = n + 1
  end
  return Voxel3D.newMesh(verts, indices)
end

-- The tall-grass rows as their own mesh: VoxelScene draws it AFTER the
-- characters so the southern row of a grass cell still overdraws a
-- walker's feet (characters stamp over terrain, Gen 1 style, so ordinary
-- terrain could never do this).
--
-- When assets/ground/grass/ ships a 3D tuft bake (Grass3D), the mesh is a
-- triangle stamp of that model per grass tile and carries its own texture.
-- Otherwise the classic tileset-slab quads.
local function buildGrassMesh(map)
  local S = Structures.forMap(map)
  if S.grassInstances and #S.grassInstances > 0 then
    local ok, G = pcall(V.require, "Grass3D")
    if ok and G and G.meshFromInstances then
      local mesh = G.meshFromInstances(S.grassInstances)
      if mesh then return mesh end
    end
  end
  return quadsMesh(S.grassQuads)
end

-- Decorative grass mesh (no effects)
local function buildDecorMesh(map)
  local S = Structures.forMap(map)
  if S.decorInstances and #S.decorInstances > 0 then
    local ok, G = pcall(V.require, "Grass3D")
    if ok and G and G.decorMeshFromInstances then
      return G.decorMeshFromInstances(S.decorInstances)
    end
  end
  return nil
end

-- Road mesh using Grass3D with road texture and 0.05 height
local function buildRoadMesh(map)
  local S = Structures.forMap(map)
  if S.roadInstances and #S.roadInstances > 0 then
    local ok, G = pcall(V.require, "Grass3D")
    if ok and G and G.roadMeshFromInstances then
      return G.roadMeshFromInstances(S.roadInstances)
    end
  end
  return nil
end

-- Ground mesh using Grass3D with ground texture and 0.1 height
local function buildGroundMesh(map)
  local S = Structures.forMap(map)
  if S.groundInstances and #S.groundInstances > 0 then
    local ok, G = pcall(V.require, "Grass3D")
    if ok and G and G.groundMeshFromInstances then
      return G.groundMeshFromInstances(S.groundInstances)
    end
  end
  return nil
end

-- The flower billboards as their own mesh, for the same reason as the
-- grass one: it draws AFTER the characters WITH the same camera-ward
-- pull, so a flower south of a walker occludes their feet and one north
-- of them hides behind them. Baked into the terrain mesh they lost that
-- depth fight against the pulled character card whenever the player
-- stood among flowers. Unlike grass this mesh still CASTS shadows (the
-- sun pass draws it): a handful of flowers per meadow, not thousands of
-- tufts.
local function buildFlowerMesh(map)
  return quadsMesh(Structures.forMap(map).flowerQuads)
end

-- Custom surfaces (road and ground) as their own mesh
local function buildCustomSurfaceMesh(map)
  local S = Structures.forMap(map)
  if S.customSurfaceMesh then
    return S.customSurfaceMesh
  end
  return nil
end

-- Authored FIGURES (a person drawn into furniture) as one mesh each, in
-- the card's own local space -- because each one is placed by its own
-- matrix at draw time, leaned back by the camera pitch exactly like a
-- character card (VoxelScene). A figure baked into the terrain mesh could
-- not lean, and a shared mesh could not carry per-figure placement.
--
-- A list, not a mesh: `{ mesh, wx, wz, y }` per figure. Maps have one or
-- none, so the loop that draws them is shorter than the terrain's.
local function buildFigureMeshes(map)
  local out = {}
  for _, f in ipairs(Structures.forMap(map).figures or {}) do
    local mesh = quadsMesh(f.quads)
    if mesh then
      out[#out + 1] = { mesh = mesh, wx = f.wx, wz = f.wz, y = f.y }
    end
  end
  return out
end

-- Figure lists hold their meshes one level down, so the generic slot
-- release cannot reach them.
local function releaseFigures(list)
  for _, f in ipairs(type(list) == "table" and list or {}) do
    if f.mesh and f.mesh.release then pcall(f.mesh.release, f.mesh) end
  end
end

-- Replace a cached slot, releasing whatever mesh it held.
local function swapSlot(c, slot, mesh)
  local old = c[slot]
  if old and old ~= mesh and old.release then pcall(old.release, old) end
  c[slot] = mesh
end

-- ------------------------------------------------------------- the cache

local function entry(id)
  local c = cache[id]
  if not c then
    c = {}
    cache[id] = c
  end
  return c
end

local function releaseEntry(c)
  for _, slot in ipairs({ "full", "body", "grass", "flowers", "custom", "road", "ground", "decor" }) do
    local mesh = c[slot]
    if mesh and mesh.release then pcall(mesh.release, mesh) end
    c[slot] = nil
  end
  releaseFigures(c.figures)
  c.figures = nil
  c.stale = nil
end

-- ---------------------------------------------------------- async builds

local jobs = {}       -- FIFO of pending jobs
local jobIndex = {}   -- "id:slot" -> job

local clock = (love and love.timer and love.timer.getTime) or os.clock

local function jobKey(id, slot)
  return id .. ":" .. slot
end

local function finishJob(job, ok, err)
  jobIndex[jobKey(job.id, job.slot)] = nil
  for i, j in ipairs(jobs) do
    if j == job then
      table.remove(jobs, i)
      break
    end
  end
  if not ok then
    -- name the reason: in a real session a lost build is a black map
    print("[warn] voxel mesh build failed for " .. tostring(job.id)
          .. ": " .. tostring(err))
    if (gen[job.id] or 0) == job.gen then
      entry(job.id)[job.slot] = false
    end
  end
end

-- A build only lands if the map's generation still matches the one the
-- job was queued under -- invalidate/evict bump it to cancel in-flight
-- work whose inputs went stale.
local function runJob(job)
  local map = job.map
  local c = entry(job.id)
  if c.grass == nil or c.flowers == nil or c.figures == nil or c.custom == nil or c.road == nil or c.ground == nil or c.decor == nil
     or (c.stale and c.stale.aux) then
    local okG, grass = pcall(buildGrassMesh, map)
    local okF, flowers = pcall(buildFlowerMesh, map)
    local okX, figures = pcall(buildFigureMeshes, map)
    local okC, custom = pcall(buildCustomSurfaceMesh, map)
    local okR, road = pcall(buildRoadMesh, map)
    local okGnd, ground = pcall(buildGroundMesh, map)
    local okD, decor = pcall(buildDecorMesh, map)
    if (gen[job.id] or 0) ~= job.gen then
      if okG and grass and grass.release then pcall(grass.release, grass) end
      if okF and flowers and flowers.release then
        pcall(flowers.release, flowers)
      end
      if okX then releaseFigures(figures) end
      if okC and custom and custom.release then pcall(custom.release, custom) end
      if okR and road and road.release then pcall(road.release, road) end
      if okGnd and ground and ground.release then pcall(ground.release, ground) end
      if okD and decor and decor.release then pcall(decor.release, decor) end
      return
    end
    swapSlot(c, "grass", (okG and grass) or false)
    swapSlot(c, "flowers", (okF and flowers) or false)
    swapSlot(c, "figures", (okX and figures) or false)
    swapSlot(c, "custom", (okC and custom) or false)
    swapSlot(c, "road", (okR and road) or false)
    swapSlot(c, "ground", (okGnd and ground) or false)
    swapSlot(c, "decor", (okD and decor) or false)
    releaseFigures(c.figures)
    c.figures = (okX and figures) or false
    if c.stale then c.stale.aux = nil end
  end
  local sink = newChunkedSink()
  runGeometry(map, job.slot == "body", job.masks, sink)
  local mesh = sink.finish()
  if (gen[job.id] or 0) ~= job.gen then
    if mesh and mesh.release then pcall(mesh.release, mesh) end
    return
  end
  swapSlot(c, job.slot, mesh or false)
  if c.stale then
    c.stale[job.slot] = nil
    if not (c.stale.full or c.stale.body or c.stale.aux) then
      c.stale = nil
    end
  end
end

-- How badly a queued build is wanted, highest first.
--
--   CURRENT  the map being stood on. Without it there is no 3D frame at
--            all: VoxelScene.render returns nil and the engine draws the
--            flat 2D path instead.
--   HOLE     a neighbour holding NEITHER variant. Nothing is drawn at its
--            offset and the scene's full-screen sky clear shows through,
--            so this is a gap in the world rather than a pending
--            improvement to one.
--   IDLE     everything else -- which by definition is already drawing
--            something. A neighbour holding the other variant still
--            covers its own ground while the one it wants is built, so it
--            has no business competing with a map showing sky.
ChunkMesher.CURRENT = 2
ChunkMesher.HOLE    = 1
ChunkMesher.IDLE    = 0

-- `urgent` stays a boolean for every caller that only ever had two answers
-- (true = the current map); the tier between them is passed as the number.
local function prioOf(urgent)
  if urgent == true then return ChunkMesher.CURRENT end
  if type(urgent) == "number" then return urgent end
  return ChunkMesher.IDLE
end

-- Queue a build unless the slot is already cached or queued. Returns the
-- cached mesh when there is one (false-cached misses return nil).
-- `urgent` says which tier above it belongs to: pump() runs the highest
-- one first and gives it the bigger slice. A slot refresh() marked
-- stale queues its rebuild AND keeps handing back the old mesh, so a
-- one-block edit never drops the scene to the flat 2D path while the
-- replacement cooks.
--
-- A job already queued may only be PROMOTED, never demoted. The frame
-- that wanted it most is the one that decides -- otherwise a neighbour
-- that filled in for a single frame, or drifted out of the list and back,
-- would surrender the priority the frame before it earned and start over
-- at the back.
function ChunkMesher.request(map, bodyOnly, masks, urgent)
  local slot = bodyOnly and "body" or "full"
  local c = cache[map.id]
  local stale = c and c.stale and (c.stale[slot] or c.stale.aux)
  if c and c[slot] ~= nil and not stale then return c[slot] or nil end
  local key = jobKey(map.id, slot)
  local job = jobIndex[key]
  local prio = prioOf(urgent)
  if not job then
    job = { id = map.id, map = map, slot = slot, masks = masks,
            prio = prio, gen = gen[map.id] or 0 }
    jobIndex[key] = job
    jobs[#jobs + 1] = job
  elseif prio > job.prio then
    job.prio = prio
  end
  return (c and c[slot]) or nil
end

function ChunkMesher.pending()
  return #jobs
end

-- Advance queued builds inside a per-frame time budget. Urgent jobs (the
-- current map) come first and get the larger slice -- the first voxel
-- frame after a toggle is worth more milliseconds than a neighbour
-- popping in one frame later. `covered` says the world pass is hidden
-- this frame (a warp's fade, a menu): nothing visible can hitch, so the
-- slice opens up and a door fade swallows most of a destination build.
-- These were picked against a desktop frame, where 12ms of Lua is most of
-- a 60Hz budget but the rest of the frame costs almost nothing. On a phone
-- the rest of the frame is already the whole budget, so a 12ms slice does
-- not fit INSIDE a frame -- it IS the frame, and every one of them is a
-- dropped one. Halved and more: the terrain streams in over more frames
-- and none of those frames is a visible hitch, which is the trade the
-- asynchronous mesher exists to make in the first place.
--
-- COVERED is the exception and stays large. Those are the frames a warp's
-- fade is drawn over, where nothing of the world is on screen to hitch --
-- spending them is how stepping out of a door lands on real terrain
-- instead of on a flat flash. Trimmed a little all the same, because the
-- fade itself is still an animation somebody is watching.
local URGENT_SLICE = 0.005
-- A gap in the world is the world missing, which is the same class of
-- problem as having no world at all -- so it is worth the same slice. What
-- keeps it from stealing anything is the ORDER: the current map is a whole
-- tier above and always runs first. Named separately from URGENT so that
-- if a phone ever wants these to differ, there is somewhere to say so.
local HOLE_SLICE = 0.005
local IDLE_SLICE = 0.002
local COVERED_SLICE = 0.020

-- The most-wanted job, first-queued winning a tie -- which is the order
-- the old two-level pick already had.
local function nextJob()
  local pick, best = nil, -1
  for _, j in ipairs(jobs) do
    if j.prio > best then pick, best = j, j.prio end
  end
  return pick
end

function ChunkMesher.pump(covered)
  if #jobs == 0 then return end
  local pick = nextJob()
  local slice = covered and COVERED_SLICE
                or (pick.prio == ChunkMesher.CURRENT and URGENT_SLICE)
                or (pick.prio == ChunkMesher.HOLE and HOLE_SLICE)
                or IDLE_SLICE
  local deadline = clock() + slice
  while pick do
    if not pick.co then
      pick.co = coroutine.create(runJob)
    end
    Budget.begin(pick.co, deadline - clock())
    local ok, err = coroutine.resume(pick.co, pick)
    Budget.finish()
    if not ok then
      finishJob(pick, false, err)
    elseif coroutine.status(pick.co) == "dead" then
      finishJob(pick, true)
    else
      return   -- slice spent mid-build; resume next frame
    end
    if clock() >= deadline or #jobs == 0 then return end
    pick = nextJob()
  end
end

-- Meshes for `map`, built SYNCHRONOUSLY on first use -- the historical
-- contract, kept for probes and any direct caller. `false` is cached for
-- a map whose mesh could not be built so a headless run does not retry
-- every frame. `masks` (the full variant's neighbour-body rects) is
-- static per map id -- a map's connections never change -- so it caches
-- like everything else.
function ChunkMesher.get(map, bodyOnly, masks)
  local slot = bodyOnly and "body" or "full"
  local c = entry(map.id)
  if c.grass == nil or c.flowers == nil or c.custom == nil or c.road == nil or c.ground == nil or c.decor == nil or (c.stale and c.stale.aux) then
    local okG, grass = pcall(buildGrassMesh, map)
    local okF, flowers = pcall(buildFlowerMesh, map)
    local okC, custom = pcall(buildCustomSurfaceMesh, map)
    local okR, road = pcall(buildRoadMesh, map)
    local okGnd, ground = pcall(buildGroundMesh, map)
    local okD, decor = pcall(buildDecorMesh, map)
    swapSlot(c, "grass", (okG and grass) or false)
    swapSlot(c, "flowers", (okF and flowers) or false)
    swapSlot(c, "custom", (okC and custom) or false)
    swapSlot(c, "road", (okR and road) or false)
    swapSlot(c, "ground", (okGnd and ground) or false)
    swapSlot(c, "decor", (okD and decor) or false)
    if c.stale then c.stale.aux = nil end
  end
  if c[slot] == nil or (c.stale and c.stale[slot]) then
    local ok, mesh = pcall(ChunkMesher.build, map, bodyOnly, masks)
    if not ok then
      print("[warn] voxel mesh build failed for " .. tostring(map.id)
            .. ": " .. tostring(mesh))
    end
    swapSlot(c, slot, (ok and mesh) or false)
    if c.stale then
      c.stale[slot] = nil
      if not (c.stale.full or c.stale.body or c.stale.aux) then
        c.stale = nil
      end
    end
    local key = jobKey(map.id, slot)
    local job = jobIndex[key]
    if job then finishJob(job, true) end
  end
  return c[slot] or nil
end

-- The cached mesh, or nil -- never builds. The async path's read side.
function ChunkMesher.peek(map, bodyOnly)
  local c = cache[map.id]
  local mesh = c and c[bodyOnly and "body" or "full"]
  return mesh or nil
end

function ChunkMesher.grass(map)
  local c = cache[map.id]
  return c and c.grass or nil
end

function ChunkMesher.flowers(map)
  local c = cache[map.id]
  return c and c.flowers or nil
end

function ChunkMesher.custom(map)
  local c = cache[map.id]
  return c and c.custom or nil
end

function ChunkMesher.road(map)
  local c = cache[map.id]
  return c and c.road or nil
end

function ChunkMesher.ground(map)
  local c = cache[map.id]
  return c and c.ground or nil
end

function ChunkMesher.decor(map)
  local c = cache[map.id]
  return c and c.decor or nil
end

-- Authored figures as `{ mesh, wx, wz, y }` records -- each placed by its
-- own leaning matrix at draw time, so they cannot share one mesh.
function ChunkMesher.figures(map)
  local c = cache[map.id]
  local list = c and c.figures
  return (type(list) == "table") and list or nil
end

-- Rebuild a map's meshes IN PLACE: the stale meshes keep drawing while
-- replacements cook, and each slot swaps as its build lands. This is
-- the block-edit path (a cut tree, a door stamp) -- invalidate() drops
-- the mesh outright, and until the async rebuild landed the scene fell
-- to the flat 2D path, a whole-world blink for a one-block edit.
function ChunkMesher.refresh(mapId)
  if not mapId then return ChunkMesher.invalidate() end
  local c = cache[mapId]
  -- nothing drawable cached: the plain drop costs nothing visible
  if not (c and (c.full or c.body)) then
    return ChunkMesher.invalidate(mapId)
  end
  Structures.invalidate(mapId)
  gen[mapId] = (gen[mapId] or 0) + 1
  for i = #jobs, 1, -1 do
    local job = jobs[i]
    if job.id == mapId then
      jobIndex[jobKey(job.id, job.slot)] = nil
      table.remove(jobs, i)
    end
  end
  -- false-cached slots count as stale too: a retry after a failed build
  -- is exactly a rebuild
  c.stale = { aux = true,
              full = (c.full ~= nil) or nil,
              body = (c.body ~= nil) or nil }
end

-- Evict everything outside `live` (a set of map ids): far maps' meshes
-- are released -- GPU buffer and LOVE's CPU copy both -- and their
-- Structures analysis dropped. The live set is the current map plus its
-- rendered neighbours, so memory stays bounded by what is on or near the
-- screen instead of growing with every area ever visited.
--
-- The PREVIOUS live set is retained too: warping into a building
-- collapses the set to one small interior, and evicting the town at the
-- door means rebuilding the whole neighbourhood on the way out -- a
-- flat-world flash after every house. One set of history makes the
-- round trip free while staying bounded at two neighbourhoods.
local prevLive = {}

function ChunkMesher.setLive(live)
  for id, c in pairs(cache) do
    if not live[id] and not prevLive[id] then
      releaseEntry(c)
      cache[id] = nil
      gen[id] = (gen[id] or 0) + 1
      Structures.invalidate(id)
    end
  end
  for i = #jobs, 1, -1 do
    local job = jobs[i]
    if not live[job.id] and not prevLive[job.id] then
      jobIndex[jobKey(job.id, job.slot)] = nil
      table.remove(jobs, i)
    end
  end
  prevLive = live
end

-- Drop one map's mesh (Cut swapped a block) or all of them (hot reload).
-- Structures' analysis is derived from the same block layer, so it drops
-- in the same breath; in-flight builds of the map are cancelled through
-- the generation counter.
function ChunkMesher.invalidate(mapId)
  Structures.invalidate(mapId)
  if mapId then
    local c = cache[mapId]
    if c then releaseEntry(c) end
    cache[mapId] = nil
    gen[mapId] = (gen[mapId] or 0) + 1
  else
    for _, c in pairs(cache) do releaseEntry(c) end
    cache = {}
    for id in pairs(gen) do gen[id] = gen[id] + 1 end
  end
  for i = #jobs, 1, -1 do
    local job = jobs[i]
    if mapId == nil or job.id == mapId then
      jobIndex[jobKey(job.id, job.slot)] = nil
      table.remove(jobs, i)
    end
  end
end

Assets.register(function() ChunkMesher.invalidate() end)

return ChunkMesher
