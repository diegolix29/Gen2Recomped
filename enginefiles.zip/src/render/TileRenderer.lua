-- Copyright (c) 2026 Cedric. All rights reserved.
-- Source-available under the Gen2Recomped License (see LICENSE.md): you may
-- read, build and privately modify this file; you may not redistribute it or
-- use it commercially. Cartridge-derived data is excluded and is not the
-- copyright holder's to license.

-- Draws a map's tile layer: one texture atlas per tileset, 8x8 quads,
-- a single static SpriteBatch covering the map plus a border-block ring
-- (the ring plays the role of the GB border blocks around small maps).

local Assets = require("src.render.Assets")
local Logger = require("src.core.Logger")
local Probe = require("src.core.Probe")
local PaletteFX = require("src.render.PaletteFX")

local TileRenderer = {}
TileRenderer.__index = TileRenderer

local BORDER_BLOCKS = 3 -- ring width; > half a screen (2.5 blocks)

-- OVERWORLD maps fill beyond-edge space from save.options.voidFill:
--   trees (default) -- solid tree wall $0F (Viridian/Cerulean/Celadon)
--   water           -- solid water $43 (Cinnabar/Route 19 border block)
--   black           -- solid black (no tiled metatile)
-- Other tilesets keep their designated border (interiors stay black/void).
local TREE_WALL_BLOCK = 0x0F
local WATER_BORDER_BLOCK = 0x43
TileRenderer.VOID_FILLS = { "trees", "water", "black" }
TileRenderer.voidFill = "trees"

local function borderBlockFor(map)
  if map.def.tileset == "OVERWORLD" then
    local mode = TileRenderer.voidFill or "trees"
    if mode == "water" then return WATER_BORDER_BLOCK end
    if mode == "black" then return false end
    return TREE_WALL_BLOCK
  end
  return map.def.borderBlock
end
TileRenderer.borderBlockFor = borderBlockFor

function TileRenderer.setVoidFill(mode)
  local ok = false
  for _, m in ipairs(TileRenderer.VOID_FILLS) do
    if m == mode then ok = true; break end
  end
  TileRenderer.voidFill = ok and mode or "trees"
end

function TileRenderer.cycleVoidFill()
  local cur = TileRenderer.voidFill or "trees"
  local idx = 1
  for i, m in ipairs(TileRenderer.VOID_FILLS) do
    if m == cur then idx = i; break end
  end
  TileRenderer.setVoidFill(
    TileRenderer.VOID_FILLS[idx % #TileRenderer.VOID_FILLS + 1])
  return TileRenderer.voidFill
end

-- field.gen2TileAnim, handed over when a map's renderer is built (MapLoader
-- has the dataset; this module does not).  Nil on Gen 1 and on any cache
-- older than the one that started extracting TilesetTowerAnim.
function TileRenderer.setTileAnim(spec)
  if type(spec) == "table" and spec.tiles and spec.image then
    TileRenderer.TILE_ANIM = spec
  end
end

function TileRenderer.applyOptions(opts)
  TileRenderer.setVoidFill(opts and opts.voidFill or "trees")
end

function TileRenderer.voidFillLabel(mode)
  mode = mode or TileRenderer.voidFill or "trees"
  if mode == "water" then return "WATER" end
  if mode == "black" then return "BLACK" end
  return "TREES"
end

local imageCache = {}

local function getImage(path)
  if not imageCache[path] then
    imageCache[path] = Assets.image(path)
  end
  return imageCache[path]
end

-- The 8x8 atlas a tileset draws from, or nil when it HAS none.
--
-- A Gen 1 or Gen 2 tileset is a sheet on disk. A Gen 3 one is not, and that is
-- not a gap: its art is two half-banks of tiles that only become a picture once
-- the map's primary and secondary tilesets are composited (gen3SheetsFor). The
-- nil path used to go straight into the image cache as a table key, which is
-- "table index is nil" on the first Hoenn map anyone walked into -- so the
-- question is asked here, once, where it can also be tested.
function TileRenderer.atlasImage(tilesetDef)
  local path = tilesetDef and tilesetDef.image
  if type(path) ~= "string" or path == "" then return nil end
  return getImage(path)
end

-- ------------------------------------------------------------------
-- Tile animation (home/vcopy.asm): tilesets with TILEANIM_WATER[_FLOWER]
-- rotate water tile $14 one pixel every 20 frames (4 steps right, 4
-- left) and cycle flower tile $03 through 3 frames.
-- Those two cycles are the *defaults* a vanilla tileset record derives
-- from its `animation` string; a tileset that carries `animatedTiles`
-- declares its own set instead and animates with no engine change.
-- ------------------------------------------------------------------

local WATER_TILE, FLOWER_TILE = 0x14, 0x03
-- cumulative pixel offset per animation step (the rrca/rlca sequence)
local WATER_OFFSETS = { 1, 2, 3, 2, 1, 0, 7, 0 }
-- flower frame per step (wMovingBGTilesCounter2 & 3: <2 -> 1, 2, 3)
local FLOWER_FRAMES = { 1, 2, 3, 1, 1, 2, 3, 1 }
local ANIM_PERIOD = 20
local FLOWER_IMAGES = {
  "assets/generated/tilesets/flower1.png",
  "assets/generated/tilesets/flower2.png",
  "assets/generated/tilesets/flower3.png",
}
local SPINNER_STRIP = "assets/generated/tilesets/spinners.png"

local animFrame = 0
local animAccum = 0
local ANIM_STEP = 1 / 60 -- Game Boy logic rate (matches FixedStep.STEP)

-- Advance water/flower/spinner tile animation.  Called from the overworld
-- draw path so it keeps running under dialogs (overworld update does not),
-- but consumes wall-clock dt into 60Hz steps so high/low display refresh
-- no longer speeds up or slows the cycle (issue #4).
-- tick() / tick(nil) with no love.timer.getDelta (headless tests) still
-- advances exactly one frame per call.
function TileRenderer.tick(dt)
  if dt == nil and love and love.timer and love.timer.getDelta then
    dt = love.timer.getDelta()
  end
  if dt == nil then
    animFrame = animFrame + 1
    return
  end
  -- Cap catch-up so a long stall cannot jump many water/flower periods
  animAccum = math.min(animAccum + dt, 0.25)
  while animAccum >= ANIM_STEP do
    animAccum = animAccum - ANIM_STEP
    animFrame = animFrame + 1
  end
end

-- The animation clock itself, read-only.  It has always been a plain local in
-- this file, which left everything downstream -- the voxel mod's terrain
-- atlas, and now the Gen 3 overlay below -- either re-deriving a counter of
-- its own (which free-runs against this one, so toggling a display mode
-- restarts the sea) or reaching in through debug.getupvalue.  Same number,
-- named.
function TileRenderer.animFrame()
  return animFrame
end

-- ------------------------------------------------------------------
-- Spinner arrow tiles (engine/overworld/spinners.asm LoadSpinnerArrowTiles):
-- a wholly separate, contextually-triggered VRAM patch layered on top of
-- the ambient water/flower cycle above -- while wMovementFlags.BIT_SPINNING
-- is set (Gym/Rocket Hideout spinner puzzles), each forced-movement step
-- farcalls LoadSpinnerArrowTiles, which flips 4 fixed destination tile IDs
-- per tileset between the shared 'blur' graphic (gfx/overworld/spinners.2bpp,
-- SpinnerArrowAnimTiles) and the tileset's own static graphic (restore).
-- Only 2 distinct frames exist -- no continuous multi-frame cycle.
-- ------------------------------------------------------------------

-- data/tilesets/spinner_tiles.asm: dest tile IDs patched per tileset
TileRenderer.SPINNER_ARROW_TILES = {
  GYM = { 0x3c, 0x3d, 0x4c, 0x4d },
  FACILITY = { 0x20, 0x21, 0x30, 0x31 },
}

-- dest tile id -> offset (in 8x8 tiles) into the SpinnerArrowAnimTiles strip,
-- taken verbatim from the `spinner SpinnerArrowAnimTiles, <offset>, <dest>`
-- rows of data/tilesets/spinner_tiles.asm
local SPINNER_STRIP_OFFSET = {
  GYM = { [0x3c] = 1, [0x3d] = 3, [0x4c] = 0, [0x4d] = 2 },
  FACILITY = { [0x20] = 0, [0x21] = 1, [0x30] = 2, [0x31] = 3 },
}

local spinning = false
function TileRenderer.setSpinning(active)
  spinning = active
end

-- true while the spinner arrow tiles should show the 'blur' graphic; false
-- means draw nothing extra (the static window tile shows through,
-- matching the asm's restore-to-original behavior). The 8-tick
-- half-period approximates one GB movement step (2px/frame); this is a
-- deliberate approximation of wSimulatedJoypadStatesIndex bit-0 parity, not
-- a cycle-accurate replication -- the port's tweened scriptMove has no
-- direct equivalent discrete step counter.
function TileRenderer.spinBlurActive()
  return spinning and (math.floor(animFrame / 8) % 2 == 0)
end

-- ------------------------------------------------------------------
-- animatedTiles: the per-kind resource builders.  Each returns the
-- texture list a step indexes into, or false when the pixels are
-- unreachable (headless, or a missing frame file) -- false disables that
-- one entry and leaves the static batch showing through, which is what
-- the water/flower branches did before they were data.
-- ------------------------------------------------------------------

-- shade 0-3 -> one of `colors`' 4 entries (same cutoffs PaletteFX's shader
-- uses), alpha passed through unchanged; nil colors leaves r,g,b as-is.
-- Shared by the whole-atlas bake (getGbcAtlas) and the animated-tile
-- variants below, so water/flowers/spinners match the static tiles around
-- them under RED++ instead of showing their un-recolored grayscale.
local function recolorSample(r, g, b, a, colors)
  if not (colors and a > 0) then return r, g, b, a end
  local col = r > 0.83 and colors[1] or r > 0.5 and colors[2]
              or r > 0.17 and colors[3] or colors[4]
  return col[1] / 255, col[2] / 255, col[3] / 255, a
end

-- exported: a render pipeline bakes a map's palette into its own texture
-- atlas the same way, and has to land on the identical colors as the 2D
-- tiles it is standing in for
TileRenderer.recolorSample = recolorSample

-- the 8 shifted variants of one tile (built once per sheet + tile id [+
-- gbcKey, when `colors` recolors it for RED++ -- see buildAnim])
local shiftVariants = {}
local function getShiftVariants(tilesetImagePath, perRow, tile, colors, gbcKey)
  local key = tilesetImagePath .. "#" .. tile .. (gbcKey or "")
  if shiftVariants[key] ~= nil then return shiftVariants[key] end
  if not (love.image and love.image.newImageData) then
    shiftVariants[key] = false
    return false
  end
  local id = Assets.imageData(tilesetImagePath)
  local sx = (tile % perRow) * 8
  local sy = math.floor(tile / perRow) * 8
  local out = {}
  for o = 0, 7 do
    local v = love.image.newImageData(8, 8)
    for y = 0, 7 do
      for x = 0, 7 do
        local r, g, b, a = id:getPixel(sx + x, sy + y)
        r, g, b, a = recolorSample(r, g, b, a, colors)
        v:setPixel((x + o) % 8, y, r, g, b, a)
      end
    end
    out[o + 1] = love.graphics.newImage(v)
  end
  shiftVariants[key] = out
  return out
end

local frameImages = {}
local function getFrameImages(paths, colors, gbcKey)
  local key = table.concat(paths, "|") .. (gbcKey or "")
  if frameImages[key] ~= nil then return frameImages[key] end
  local out = {}
  for i, path in ipairs(paths) do
    local ok, img = pcall(function()
      if not (colors and love.image and love.image.newImageData) then
        return getImage(path)
      end
      local id = Assets.imageData(path)
      local w, h = id:getDimensions()
      local out2 = love.image.newImageData(w, h)
      for y = 0, h - 1 do
        for x = 0, w - 1 do
          local r, g, b, a = id:getPixel(x, y)
          r, g, b, a = recolorSample(r, g, b, a, colors)
          out2:setPixel(x, y, r, g, b, a)
        end
      end
      return love.graphics.newImage(out2)
    end)
    if not ok then
      frameImages[key] = false
      return false
    end
    out[i] = img
  end
  frameImages[key] = out
  return out
end

-- the tileset's own atlas ImageData with the patched tile slots blitted
-- over with a shared strip (vanilla: assets/generated/tilesets/spinners.png,
-- extracted from gfx/overworld/spinners.png); cached per tileset + strip
local toggleImages = {}
local stripData = {}
local function getToggleImage(spec, tilesetImagePath, perRow)
  local key = tilesetImagePath .. "#" .. tostring(spec.image)
  if toggleImages[key] ~= nil then return toggleImages[key] end
  local offsets = spec.stripOffsets
  if not (love.image and love.image.newImageData) or not offsets then
    toggleImages[key] = false
    return false
  end
  if stripData[spec.image] == nil then
    local ok, id = pcall(Assets.imageData, spec.image)
    stripData[spec.image] = ok and id or false
  end
  local strip = stripData[spec.image]
  if not strip then
    toggleImages[key] = false
    return false
  end
  local atlas = Assets.imageData(tilesetImagePath)
  local clone = love.image.newImageData(atlas:getWidth(), atlas:getHeight())
  clone:paste(atlas, 0, 0, 0, 0, atlas:getWidth(), atlas:getHeight())
  for id, offset in pairs(offsets) do
    local sx = offset * 8
    local dx = (id % perRow) * 8
    local dy = math.floor(id / perRow) * 8
    for y = 0, 7 do
      for x = 0, 7 do
        local r, g, b, a = strip:getPixel(sx + x, y)
        clone:setPixel(dx + x, dy + y, r, g, b, a)
      end
    end
  end
  local img = love.graphics.newImage(clone)
  toggleImages[key] = img
  return img
end

-- One atlas-SIZED texture per animation FRAME, transparent everywhere except
-- the animated tiles, which are pasted in from a strip at their atlas cells.
-- This is the toggle builder's trick applied to a sequence instead of a gate:
-- because every frame keeps the atlas layout, the batch's existing per-tile
-- quads stay valid and the draw path only has to swap the texture -- which is
-- exactly what it already does for water.  Leaving the rest transparent (as
-- opposed to cloning the atlas) means the overdraw can never repaint a
-- neighboring tile, and it stays correct under the GBC atlas bake, where the
-- static window is drawn from a recolored atlas this builder cannot see.
--
-- SPROUT TOWER's pillar needs this and the single-tile `frames` kind cannot
-- give it: AnimateTowerPillarTile rewrites TEN different tiles in step, so a
-- frame is ten tiles, not one.
local atlasFrames = {}

local function getAtlasFrames(spec, tilesetImagePath, perRow, colors, gbcKey,
                              colorsFor)
  local key = tilesetImagePath .. "#af#" .. tostring(spec.image) .. (gbcKey or "")
  if atlasFrames[key] ~= nil then return atlasFrames[key] or nil end
  local tiles, count = spec.tiles, spec.frames or 0
  if not (love.image and love.image.newImageData) or not tiles or count < 1 then
    atlasFrames[key] = false
    return nil
  end
  local okStrip, strip = pcall(Assets.imageData, spec.image)
  local okAtlas, atlas = pcall(Assets.imageData, tilesetImagePath)
  if not (okStrip and strip and okAtlas and atlas) then
    atlasFrames[key] = false
    return nil
  end
  local aw, ah = atlas:getWidth(), atlas:getHeight()
  local out = {}
  for frame = 0, count - 1 do
    local page = love.image.newImageData(aw, ah)
    for column, id in ipairs(tiles) do
      local sx, sy = (column - 1) * 8, frame * 8
      local dx, dy = (id % perRow) * 8, math.floor(id / perRow) * 8
      -- Gen2's palette byte is per TILE, and the pillar's ten tiles need not
      -- share one, so ask per tile and only fall back to the entry's palette
      local tint = colors
      if colorsFor then tint = colorsFor(id) or colors end
      if sx + 8 <= strip:getWidth() and sy + 8 <= strip:getHeight()
         and dx + 8 <= aw and dy + 8 <= ah then
        for y = 0, 7 do
          for x = 0, 7 do
            local r, g, b, a = strip:getPixel(sx + x, sy + y)
            r, g, b, a = recolorSample(r, g, b, a, tint)
            page:setPixel(dx + x, dy + y, r, g, b, a)
          end
        end
      end
    end
    out[frame + 1] = love.graphics.newImage(page)
  end
  atlasFrames[key] = out
  return out
end

-- a toggle entry names the predicate that decides whether its patch shows
-- this frame; an unknown name (or none) is always on
TileRenderer.GATES = {
  spinning = function() return TileRenderer.spinBlurActive() end,
}

function TileRenderer.registerGate(name, predicate)
  TileRenderer.GATES[name] = predicate
end

local function gateOpen(name)
  local predicate = TileRenderer.GATES[name]
  if not predicate then return true end
  return predicate() and true or false
end

-- The vanilla animation set as data: what the importer would write onto a
-- tileset record derived from its `animation` string and its spinner-tile
-- row.  Consulted only when the record declares no animatedTiles of its
-- own, so the vanilla frame is byte-for-byte what it always was.
function TileRenderer.defaultAnimatedTiles(tileset)
  local out = {}
  local anim = tileset.animation
  if anim == "TILEANIM_WATER" or anim == "TILEANIM_WATER_FLOWER" then
    -- WHICH TILE THE SHIMMER LANDS ON IS THE CARTRIDGE'S BUSINESS.
    -- $14 on Gold, Silver, Crystal and Prism, and on most of Polished
    -- Crystal -- but its Faraway/Shamouti/Valencia sets animate 20 AND 21,
    -- and Snowtop Mountain animates 10, 11 and 12.  The importer reads the
    -- list off the tileset's own animation script and leaves it nil when it
    -- is this default, so every existing dataset keeps the single entry.
    local tiles = tileset.animWaterTiles
    if type(tiles) ~= "table" or #tiles == 0 then tiles = { WATER_TILE } end
    for _, tile in ipairs(tiles) do
      out[#out + 1] = { tile = tile, kind = "hshift",
                        period = ANIM_PERIOD, offsets = WATER_OFFSETS }
    end
  end
  if anim == "TILEANIM_WATER_FLOWER" then
    out[#out + 1] = { tile = FLOWER_TILE, kind = "frames",
                      period = ANIM_PERIOD, images = FLOWER_IMAGES,
                      sequence = FLOWER_FRAMES }
  end
  -- field.gen2TileAnim: the Sprout / Tin Tower pillar, read off
  -- TilesetTowerAnim.  Named by tileset so it only claims the tower set.
  local pillar = TileRenderer.TILE_ANIM
  if pillar and pillar.tileset and pillar.tiles
     and (tileset.id == pillar.tileset or tileset.name == pillar.tileset) then
    out[#out + 1] = { tiles = pillar.tiles, kind = "atlasframes",
                      period = pillar.period or ANIM_PERIOD,
                      image = pillar.image, frames = pillar.frames,
                      sequence = pillar.sequence }
  end
  local spinners = TileRenderer.SPINNER_ARROW_TILES[tileset.id]
  if spinners then
    out[#out + 1] = { tiles = spinners, kind = "toggle", image = SPINNER_STRIP,
                      stripOffsets = SPINNER_STRIP_OFFSET[tileset.id],
                      gate = "spinning" }
  end
  return out
end

-- one entry's runtime form: the tile ids it claims, the textures a step
-- picks from, and either a step sequence (hshift/frames) or a gate
-- (toggle).  nil when the entry's pixels could not be built.
--
-- gbc, when present (RED++ with a baked atlas -- see getGbcAtlas), recolors
-- hshift/frames entries (water/flowers) the same way the atlas bakes their
-- static tile, so they match their surroundings instead of showing raw
-- grayscale over an otherwise fully-colored map. The "toggle" kind
-- (spinner puzzle blur, gfx/overworld/spinners.png) is a whole-atlas clone
-- built from the ORIGINAL grayscale atlas, not worth recoloring for a rare,
-- gameplay-gated blur -- it is skipped under gbc, same as the buildAnim
-- caller already does for a texture-build failure (the static, correctly-
-- colored tile shows through unanimated).
-- A tileset with no sheet has no stride, and every helper below divides by
-- one.  Refusing here means "this tileset animates nothing", which is the
-- truth for a Gen 3 pair (its animation is driven by cartridge callbacks, not
-- by a declared tile list) and a great deal better than faulting three frames
-- later inside a cache miss.
local function buildAnim(spec, tilesetImagePath, perRow, quads, gbc)
  if not tilesetImagePath or not perRow or perRow < 1 then return nil end
  local tiles = spec.tiles
  if not tiles then
    if spec.tile == nil then return nil end
    tiles = { spec.tile }
  end
  local period = spec.period or ANIM_PERIOD
  local colors
  if gbc then
    if gbc.colorsFor then
      -- Gen2: the palette comes from the tileset's own palMap/palColors
      -- (LoadTilesetPalette's tile->palette byte), not from RED++'s eight
      -- world groups.  Without this the surf shimmer overdrew the baked
      -- atlas with raw grayscale every frame -- i.e. grey water.
      colors = gbc.colorsFor(tiles[1])
    else
      local group = PaletteFX.worldGroupAt(gbc.tilesetId, gbc.mapId, tiles[1])
      colors = group and gbc.groupColors[group + 1]
    end
  end
  if spec.kind == "hshift" then
    local offsets = spec.offsets
    if not offsets or #offsets == 0 then return nil end
    local textures = getShiftVariants(tilesetImagePath, perRow, tiles[1],
                                      colors, gbc and gbc.key)
    if not textures then return nil end
    local sequence = {}
    for i, offset in ipairs(offsets) do sequence[i] = offset + 1 end
    return { tiles = tiles, textures = textures, sequence = sequence,
             period = period }
  elseif spec.kind == "frames" then
    local sequence = spec.sequence
    if not (spec.images and sequence and #sequence > 0) then return nil end
    local textures = getFrameImages(spec.images, colors, gbc and gbc.key)
    if not textures then return nil end
    return { tiles = tiles, textures = textures, sequence = sequence,
             period = period }
  elseif spec.kind == "atlasframes" then
    local sequence = spec.sequence
    if not (sequence and #sequence > 0) then return nil end
    local textures = getAtlasFrames(spec, tilesetImagePath, perRow, colors,
                                    gbc and gbc.key, gbc and gbc.colorsFor)
    if not textures then return nil end
    -- each frame texture is atlas-sized, so a cell needs the quad of the tile
    -- it stands in rather than a single-tile image (same as `toggle`); unlike
    -- `toggle` it steps through a sequence rather than being gated
    return { tiles = tiles, textures = textures, sequence = sequence,
             period = period,
             quadFor = function(tile) return quads[tile] end }
  elseif spec.kind == "toggle" then
    if gbc and gbc.groupColors then return nil end
    local image = getToggleImage(spec, tilesetImagePath, perRow)
    if not image then return nil end
    -- the patch texture is a whole-atlas clone, so each cell needs the
    -- quad of the tile it stands in rather than a single-tile image
    return { tiles = tiles, textures = { image }, gate = spec.gate,
             quadFor = function(tile) return quads[tile] end }
  end
  return nil
end

-- True GBC overworld coloring (COLORS=RED++): recolor the WHOLE tileset
-- atlas once, per (tileset image, map), rather than trying to retrofit the
-- SGB zone/shade-remap-shader post-process (built for a handful of coarse
-- screen regions) into per-tile precision -- pokered-gbc's real model is
-- "one of 8 four-color BG palettes baked per tile GRAPHIC"
-- (color/loadpalettes.asm LoadTilesetPalette), which is exactly a
-- recolored atlas, not a shader pass. Every existing draw path (batches,
-- quads, border fill) then just works unmodified, with no shader at
-- draw time; OverworldState.sgbWorldZones skips the shade-remap zone pass
-- entirely when this is active (re-running it over already-true-color
-- pixels would corrupt them), and SpriteRenderer's own OBP bake composites
-- on top with ordinary alpha blending -- no trueColor exemption needed,
-- because there is no shader left for it to be exempted from.
--
-- Only the ROOF group (index 6, OVERWORLD/PLATEAU only) varies by town
-- (LoadTownPalette); Route 6's mid-map Saffron-roof y<2 split is not
-- reproduced (it would need a rebuild on crossing the boundary for two
-- tile-rows of one route -- not worth the complexity), so it bakes with
-- the route's own default roof (Vermilion's) throughout.
local gbcAtlasCache = {}

-- Gen2 GBC palette atlas: bakes pre-colored tiles using the palMap (tile→palette)
-- and palColors (7 palettes × 4 RGB colors) stored in the tileset def.
--
-- exported because the ANIMATED tiles have to land on the same palette: the
-- surf shimmer overdraws the baked atlas every frame, so a shimmer built from
-- the raw grayscale sheet turns the whole sea grey (only the un-animated wave
-- crests kept their blue).
function TileRenderer.gen2TileColors(palMap, palColors, tile)
  if not (palMap and palColors and #palColors > 0) then return nil end
  local raw = palMap[tile + 1] or 0
  return palColors[math.min(raw, #palColors - 1) + 1]
end

-- Which of the tileset's four time-of-day palette rows is live.  The ROM picks
-- these per map (LoadMapPals: EnvironmentColorsPointers[environment] then the
-- GetTimeOfDay row), and a PALETTE_DARK map takes the DARKNESS row outright --
-- which is the same flag the RED++ bake already keys on.
--
-- palColorsByTod is what the Gen2 importer now writes; palColors alone is the
-- older single-row shape, kept working so a dataset extracted before this
-- change still renders instead of falling back to grey.
local function gen2PalColors(tileset)
  local byTod = tileset.palColorsByTod
  if type(byTod) ~= "table" then return tileset.palColors end
  if PaletteFX.darkWorld() then return byTod.DARK or tileset.palColors end
  return byTod[PaletteFX.gen2Tod()] or byTod.DAY or tileset.palColors
end

-- One atlas per (tileset image, COLORS mode, time of day).  Leaving the mode
-- out of this key is why switching COLORS did nothing out in the Gen2
-- overworld: the first bake won and every later mode kept being handed it.
local function gen2AtlasKey(imagePath, roof, special)
  return imagePath .. "#gen2pal:" .. tostring(PaletteFX.mode) .. ":"
    .. (PaletteFX.darkWorld() and "DARK" or tostring(PaletteFX.gen2Tod()))
    -- TWO MAPS ON ONE TILESET ARE TWO DIFFERENT PICTURES once the roof is in
    -- it.  Violet and Azalea share TilesetJohto1 and wear different roofs, so
    -- leaving the roof out of the key would hand the second town the first
    -- one's bake -- the same failure the COLORS mode had before it was keyed.
    .. (roof and roof.key or "")
    .. (special or "")
end

-- THE SEVEN PALETTES A MAP OVERRIDES ITS TILESET WITH, or nil for a map that
-- overrides nothing.
--
-- LoadMapPals asks LoadSpecialMapPalette FIRST and, when it answers, never
-- reaches the environment row at all -- so this is a replacement for
-- gen2PalColors, not a tweak to it.  The rules are in the cartridge's own
-- table order and the FIRST MATCH WINS, including the case where it matches
-- and its set is missing: falling through to the next rule would colour a
-- Pokemon Center like whatever happened to be listed after it.
--
-- Skipped outright while the world is dark, which keeps the ROM's ordering:
-- the darkness row is the first row in that table and beats every other.
local function gen2SpecialPalette(map, data)
  if PaletteFX.darkWorld() then return nil end
  local special = data and data.field and data.field.gen2MapPalettes
  if type(special) ~= "table" or type(special.rules) ~= "table" then return nil end
  local def = data.maps and map.id and data.maps[map.id]
  if type(def) ~= "table" then return nil end
  local tileset = map.tileset and map.tileset.id
  for _, rule in ipairs(special.rules) do
    local hit
    if rule.kind == "map" then
      hit = rule.group == def.group and rule.number == def.number
    elseif rule.kind == "landmark" then
      hit = rule.landmark == def.landmark
    elseif rule.kind == "tileset" then
      hit = rule.tileset == tileset
    end
    -- RegionCheck, as PokeCenterSpecialCase applies it
    if hit and rule.landmarkMin then
      hit = type(def.landmark) == "number" and def.landmark >= rule.landmarkMin
    end
    if hit and rule.landmarkEq then hit = def.landmark == rule.landmarkEq end
    if hit then
      local set = special.sets and special.sets[rule.set]
      local rows = set and (set.ALL
        or set[PaletteFX.gen2Tod()] or set.DAY)
      if rows and #rows > 0 then return "#pal:" .. tostring(rule.set), rows end
      return nil
    end
  end
  return nil
end

-- THE ROOF A MAP WEARS, or nil when it wears none.
--
-- Nine tiles of an outdoor tileset belong to the MAP GROUP rather than to the
-- tileset (see RomExtractorGen2:gen2Roofs for the cartridge routines).  The
-- art is a nine-tile strip on disk and the colour is a PAIR -- colours 1 and 2
-- of the roof palette row, which is all LoadMapPals ever writes.
local function gen2RoofFor(map, data)
  local roofs = data and data.field and data.field.gen2Roofs
  if type(roofs) ~= "table" then return nil end
  local tileset = map and map.tileset
  if not (tileset and type(roofs.tilesets) == "table"
          and roofs.tilesets[tileset.id]) then
    return nil
  end
  local def = data.maps and map.id and data.maps[map.id]
  local group = (def and def.group) or map.group
  local id = group ~= nil and type(roofs.byGroup) == "table"
    and roofs.byGroup[group] or nil
  if id == nil then return nil end
  local image = type(roofs.images) == "table" and roofs.images[id] or nil
  if not image then return nil end
  local byTod = type(roofs.colors) == "table" and roofs.colors[group] or nil
  local pair = byTod and (PaletteFX.darkWorld() and byTod.DARK
    or byTod[PaletteFX.gen2Tod()] or byTod.DAY) or nil
  return {
    image = image,
    pair = pair,
    slot = roofs.slot or 10,
    count = roofs.count or 9,
    palIndex = roofs.palIndex or 6,
    key = "#roof:" .. tostring(id) .. "." .. tostring(group),
  }
end

local gen2AtlasCache = {}
-- The tile index where a tileset's COPIED art begins, or nil when it has none.
--
-- `_borrowSrcH` is the atlas height before any borrowing, stamped by
-- MapEdits.extendAtlas. Every palette bake needs the same boundary, and each
-- one deriving it separately is three chances to derive it differently.
function TileRenderer.borrowStart(tileset)
  if type(tileset) ~= "table" then return nil end
  if not (tileset._borrowSrcH and tileset.imageWidth) then return nil end
  return math.floor(tileset.imageWidth / 8) * math.floor(tileset._borrowSrcH / 8)
end

local function getGen2Atlas(key, imagePath, perRow, palMap, palColors,
                            borrowStartOf, roof)
  if not (love.image and love.image.newImageData) then return nil end
  if gen2AtlasCache[key] ~= nil then return gen2AtlasCache[key] or nil end
  local img = false
  local ok, src = pcall(Assets.imageData, imagePath)
  if ok and src then
    local iw, ih = src:getDimensions()
    local total = (iw / 8) * (ih / 8)
    local borrowFrom = borrowStartOf
    -- SAY IT WHEN THE PALETTE MAP IS SHORTER THAN THE ATLAS.
    --
    -- `gen2TileColors` reads `palMap[tile + 1] or 0`, so a tile past the end
    -- of the map does not fail -- it takes row zero, or, when the row list is
    -- shorter still, nothing at all, and the tile is drawn in the raw 2bpp
    -- greys it was extracted as. That is a tile in black and white inside a
    -- coloured map, and every symptom of it points at the ART rather than at
    -- the palette, which is where several rounds of looking went.
    --
    -- The editor extends both when it copies art between tilesets. If they
    -- ever disagree, this is the line that says so, with both numbers.
    if type(palMap) == "table" and #palMap > 0 and #palMap < total then
      require("src.core.Logger").warn(
        "gen2 atlas %s: %d tiles but palMap has %d - tiles %d..%d will draw "
        .. "in raw greys", tostring(imagePath), total, #palMap, #palMap,
        total - 1)
    end
    local out = love.image.newImageData(iw, ih)
    for t = 0, total - 1 do
      local colors = TileRenderer.gen2TileColors(palMap, palColors, t)
      -- THE SAME LAST RESORT THE RED++ BAKE HAS. If a copied tile somehow has
      -- no row of its own here -- a palMap that did not grow with the atlas,
      -- a colour list that did not -- it must not fall through to row 0, which
      -- is this tileset's text grey and is what "a black-and-white object in a
      -- coloured town" looks like. Row 0 is a real answer for a real tile and
      -- a wrong one for a borrowed one.
      if colors == nil and borrowFrom and t >= borrowFrom
         and type(palColors) == "table" and #palColors > 0 then
        colors = palColors[#palColors]
      end
      local ox, oy = (t % perRow) * 8, math.floor(t / perRow) * 8
      for py = 0, 7 do
        for px = 0, 7 do
          local r, g, b, a = src:getPixel(ox + px, oy + py)
          r, g, b, a = recolorSample(r, g, b, a, colors)
          out:setPixel(ox + px, oy + py, r, g, b, a)
        end
      end
    end
    -- ...and then the map group's roof over the nine tiles the tileset never
    -- held.  AFTER the loop, not inside it: those slots carry whatever the
    -- GFX blob happened to leave there, and on Polished Crystal the cartridge
    -- does not even copy them out of the blob.  The palette is the one the
    -- tileset's own palMap gives the slot -- the caller has already swapped
    -- the roof row's two middle colours for this group's pair, exactly as
    -- LoadMapPals does -- so the strip recolors through the same path every
    -- other tile took.
    if roof then
      local okRoof, sheet = pcall(Assets.imageData, roof.image)
      if okRoof and sheet then
        local sw, sh = sheet:getDimensions()
        for n = 0, roof.count - 1 do
          local tile = roof.slot + n
          if tile < total and (n + 1) * 8 <= sw and sh >= 8 then
            local colors = TileRenderer.gen2TileColors(palMap, palColors, tile)
            local ox, oy = (tile % perRow) * 8, math.floor(tile / perRow) * 8
            for py = 0, 7 do
              for px = 0, 7 do
                local r, g, b, a = sheet:getPixel(n * 8 + px, py)
                r, g, b, a = recolorSample(r, g, b, a, colors)
                out:setPixel(ox + px, oy + py, r, g, b, a)
              end
            end
          end
        end
      end
    end
    img = love.graphics.newImage(out)
  end
  gen2AtlasCache[key] = img
  return img or nil
end

-- THE SAME BAKE, FOR A TILESET WITHOUT A MAP.
--
-- The map editor's tile palette drew straight from `Assets.image(ts.image)`,
-- which is the raw 2bpp sheet -- so every swatch in it was grey while the
-- viewport beside it was in colour, and picking a block meant matching a grey
-- drawing against a coloured world.  The colour is not the map's: Gen 2's
-- palette byte is per TILE GRAPHIC and lives on the TILESET (palMap into
-- palColors), so a tileset is all the bake needs and every map drawn with it
-- lands on the same picture.
--
-- Gated exactly as the renderer's own bake is, and returning nil when the gate
-- is shut or the extraction carries no palette -- the caller falls back to the
-- raw sheet, which is what it was already showing.
function TileRenderer.gen2AtlasFor(tileset)
  if type(tileset) ~= "table" or not tileset.image then return nil end
  if not (tileset.palMap and #tileset.palMap > 0) then return nil end
  if not PaletteFX.usesGen2BgPal() then return nil end
  local colors = gen2PalColors(tileset)
  if not (colors and #colors > 0) then return nil end
  local perRow = tileset.tilesPerRow
  if not perRow or perRow < 1 then return nil end
  -- No roof here on purpose: the editor's swatch strip is a TILESET, and the
  -- roof belongs to a map group.  It draws the tileset's own nine tiles.
  local key = gen2AtlasKey(tileset.image)
  return getGen2Atlas(key, tileset.image, perRow, tileset.palMap, colors,
                      TileRenderer.borrowStart(tileset))
end

-- Cache suffix for a map's RED++ bake.  A dark cave folds FadePal2 into the
-- palette worldGroupColors hands the bake (#383), so the lit and dark bakes of
-- one map are different images and must not share a key.
local function gbcKeyFor(mapId)
  return "#gbc:" .. mapId .. PaletteFX.darkKey()
end

local function getGbcAtlas(imagePath, tilesetId, mapId, perRow, data)
  local key = imagePath .. gbcKeyFor(mapId)
  if gbcAtlasCache[key] ~= nil then return gbcAtlasCache[key] or nil end
  local img = false
  if love.image and love.image.newImageData then
    local groupColors = PaletteFX.worldGroupColors(data, tilesetId, mapId, nil)
    if groupColors then
      local src = Assets.imageData(imagePath)
      local iw, ih = src:getDimensions()
      local total = (iw / 8) * (ih / 8)
      local out = love.image.newImageData(iw, ih)
      -- A TILE THE CARTRIDGE NEVER HAD HAS NO PALETTE GROUP, and `false` is
      -- not a colour -- it is "leave the pixels as they are", which for a 2bpp
      -- sheet is raw grey.
      --
      -- The RED++ bake colours by PALETTE GROUP: `worldGroupAt` maps a tile id
      -- to one of the map's groups, and that table was built from the ROM, so
      -- it stops at the last tile the cartridge shipped. The editor can now
      -- copy art between tilesets, and a borrowed tile lands past that end --
      -- so it fell through to `false` and drew in greys inside a fully
      -- coloured town. Nothing about it looked like a palette problem, because
      -- every other tile on screen was correct.
      --
      -- The borrowed tile brings its own palette with it (see
      -- MapEdits.extendAtlas: the source tileset's row is appended to this
      -- tileset's `palColors` and pointed at by `palMap`). So that is the
      -- fallback -- not a guess, the colours the art was drawn in.
      local borrowedTs = data and data.tilesets and data.tilesets[tilesetId]
      local borrowedMap = borrowedTs and borrowedTs.palMap
      local borrowedRows = borrowedTs and gen2PalColors(borrowedTs)
      -- WHERE THE CARTRIDGE'S OWN ART STOPS AND THE COPIED ART BEGINS.
      --
      -- `worldGroupAt` does NOT return nil for a tile it has never heard of --
      -- it returns group 7, the TEXT palette, which is the menu grey:
      --
      --     return groups[tileId] or 7  -- tile ids past the tileset's 96
      --
      -- That is right for the menu tiles it was written for and wrong for
      -- borrowed art, and it is why the "no group" fallback below could never
      -- fire: `colors` was always a valid row, and the row was grey. A tree
      -- copied out of TilesetForest was not falling through a gap, it was
      -- being deliberately assigned the text palette.
      --
      -- `_borrowSrcH` is the atlas height before any borrowing (stamped by
      -- MapEdits.extendAtlas), so this is the exact tile index where the
      -- copied art starts. Below it nothing changes; at or above it the tile
      -- carries its own palette and that is the one to use.
      local borrowFrom = TileRenderer.borrowStart(borrowedTs)
      local tileColors = {}
      for t = 0, total - 1 do
        local colors = tileColors[t]
        if colors == nil then
          -- BORROWED ART ANSWERS FOR ITSELF, and is asked FIRST: the group
          -- table has an answer for this tile and the answer is wrong.
          if borrowFrom and t >= borrowFrom and borrowedMap and borrowedRows then
            colors = TileRenderer.gen2TileColors(borrowedMap, borrowedRows, t)
              or false
          end
          if not colors then
            local group = PaletteFX.worldGroupAt(tilesetId, mapId, t)
            colors = (group and groupColors[group + 1]) or false
          end
          tileColors[t] = colors
        end
        local ox, oy = (t % perRow) * 8, math.floor(t / perRow) * 8
        for py = 0, 7 do
          for px = 0, 7 do
            local sx, sy = ox + px, oy + py
            local r, g, b, a = src:getPixel(sx, sy)
            r, g, b, a = recolorSample(r, g, b, a, colors)
            out:setPixel(sx, sy, r, g, b, a)
          end
        end
      end
      -- duplicate-tile aliases: bake a copy of a shared tile graphic into
      -- a spare slot under a different palette group, so block cells that
      -- draw the alias can color apart from cells sharing the raw tile
      for _, al in ipairs(PaletteFX.TILE_ALIASES and PaletteFX.TILE_ALIASES[mapId] or {}) do
        if al.alias < total then
          local colors = groupColors[al.group + 1]
          local sxo = (al.tile % perRow) * 8
          local syo = math.floor(al.tile / perRow) * 8
          local dxo = (al.alias % perRow) * 8
          local dyo = math.floor(al.alias / perRow) * 8
          for py = 0, 7 do
            for px = 0, 7 do
              local r, g, b, a = src:getPixel(sxo + px, syo + py)
              r, g, b, a = recolorSample(r, g, b, a, colors)
              out:setPixel(dxo + px, dyo + py, r, g, b, a)
            end
          end
        end
      end
      img = love.graphics.newImage(out)
    end
  end
  gbcAtlasCache[key] = img
  return img or nil
end

-- THE GEN 1 BAKE, FOR AN EDITOR THAT HAS A MAP BUT NO RENDERER.
--
-- Gen 1 colour is not per tile GRAPHIC the way Gen 2's is -- there is no
-- palette byte on the tileset. It is per palette GROUP, resolved per MAP
-- (`PaletteFX.worldGroupAt`), which is why this one needs a map id where
-- `gen2AtlasFor` needs only a tileset: the same tile is grass on one route and
-- a roof on another.
--
-- The map editor's tile palette drew the raw 2bpp sheet for these, so every
-- Gen 1 tileset came out grey beside a coloured viewport. Exported rather than
-- reimplemented for the reason everything else in this project is: a second
-- copy of a colour rule drifts, and a palette that drifts is a palette that is
-- wrong in a way nobody can see.
--
-- Returns nil when the mode is not one that colours this way, which is the
-- caller's cue to fall back -- the DMG-flavoured modes are meant to be grey.
function TileRenderer.gbcAtlasFor(tileset, mapId, data)
  if type(tileset) ~= "table" or not tileset.image then return nil end
  if not PaletteFX.usesGbcPack() then return nil end
  local perRow = tileset.tilesPerRow
  if not perRow or perRow < 1 then return nil end
  if not mapId then return nil end
  return getGbcAtlas(tileset.image, tileset.id, mapId, perRow, data)
end

-- data: Game.data (threaded through explicitly, not required lazily, so
-- headless tests that build a map from a plain local table still work)
-- ---------------------------------------------------------------------------
-- Gen 3 metatile sheets
--
-- A Gen 1/Gen 2 tileset bakes to ONE atlas of 8x8 tiles and every block is
-- four rows of four indices into it.  A Gen 3 metatile cannot be expressed
-- that way: its eight tile entries each carry their own palette and their own
-- flips, and they come out of two tilesets at once.  So the pair is composited
-- once into two 16x16-per-metatile sheets -- bottom layer and top -- and the
-- window batches blit one quad per cell out of each.
--
-- TWO sheets, not one flattened image, because the player walks between them.
-- Flattening would put a character on top of the treetop they should vanish
-- behind, which is the single most visible thing this file can get wrong.
--
-- Cached by pair id: 441 layouts share 76 pairs, and baking is the expensive
-- part (about 336,000 pixels for a 656-metatile pair).
local gen3Sheets = {}
local gen3Used, gen3Clock = {}, 0

-- ONE LINE THAT SAYS WHETHER THE WATER IS ACTUALLY MOVING.
--
-- Reported three times as "the water is static", with everything checkable
-- from outside the running game coming back RIGHT: the cache carries the
-- animations, the pair bakes eight frames, and every one of Route 104's 1550
-- ocean cells sits on a metatile that moves.  The one link that cannot be
-- checked offline is the CLOCK -- whether TileRenderer.tick is running while
-- the field is on screen -- so the renderer measures it itself.
--
-- Two seconds after the first animated pair is drawn it says, once: how far
-- the tick count moved, what frame that maps to, and how many times the
-- window refilled because the frame changed.  `ticks=0 refills=0` is a clock
-- that never started; `ticks=120 refills=7` is a clock that works and a
-- problem further down.  Either way the next report arrives with the
-- measurement attached instead of needing another round of questions.
local gen3Clock0, gen3Refills, gen3Timed = nil, 0, false
local GEN3_CLOCK_PROBE = 120           -- ticks to watch before saying anything

-- one line per pair, however many frames it draws: a warning that repeats
-- every time a map loads is a warning nobody reads to the end of
local gen3Said = {}
local function warnOnce(fmt, key)
  if gen3Said[key] then return end
  gen3Said[key] = true
  Logger.warn(fmt, key)
  -- ...and to the probe file as well, because Logger's buffer means a warning
  -- raised once while walking into a map is still sitting in RAM when the
  -- game is closed, and the next boot truncates it away.
  Probe.say("tileanim", fmt, key)
end

-- HOW MANY PAIRS ARE KEPT.
--
-- Hoenn has 76, and the cache never let one go: a long session that walked
-- through all of them held every sheet it had ever baked. That was already
-- ninety-odd megabytes of texture before the animation frames made each pair
-- two and a half times bigger, so the cache is bounded now and the oldest
-- pair is dropped. Twelve is comfortably more than a town, its interiors and
-- the routes either side of it, which is the working set walking produces.
TileRenderer.GEN3_SHEET_CACHE = 12

local function gen3Evict()
  local count = 0
  for _, v in pairs(gen3Sheets) do
    if v then count = count + 1 end
  end
  while count > TileRenderer.GEN3_SHEET_CACHE do
    local oldest, oldestAt = nil, nil
    for k, v in pairs(gen3Sheets) do
      -- NEVER THE TWO NEWEST.  During a map transition two renderers are
      -- alive at once -- the map being left and the map being entered -- and
      -- releasing the images out from under either draws a freed texture,
      -- which is a crash rather than a missing tile.
      if v and gen3Clock - (gen3Used[k] or 0) >= 2
         and (not oldestAt or (gen3Used[k] or 0) < oldestAt) then
        oldest, oldestAt = k, gen3Used[k] or 0
      end
    end
    if not oldest then return end
    local record = gen3Sheets[oldest]
    for _, image in ipairs({ record.bottom, record.top }) do
      if image and image.release then pcall(image.release, image) end
    end
    gen3Sheets[oldest] = nil
    gen3Used[oldest] = nil
    count = count - 1
  end
end

-- KEEP A PAIR ALIVE WHILE IT IS ON SCREEN.  The cache is bounded and evicts
-- the oldest, and "oldest" was last measured when a renderer was BUILT -- so
-- a player who stands still while something else bakes has a live sheet age
-- out from under them.  The window fill says the pair is still in use.
function TileRenderer.touchGen3(key)
  if key and gen3Sheets[key] then
    gen3Clock = gen3Clock + 1
    gen3Used[key] = gen3Clock
  end
end

-- THE HALF OF A METATILE THAT HAS TO COVER A REFLECTION.
--
-- See Gen3Tiles:reflectionCoverLayer for the rule and where it was read off
-- the cartridge.  Only the COVERED case needs a sheet of its own: a NORMAL
-- metatile's covering half is its layer 1, which is already exactly what the
-- bottom sheet holds at that slot, and a SPLIT metatile is covered by the top
-- layer that drawAbove draws anyway.
--
-- It stays small because most COVERED metatiles have NOTHING in layer 2 --
-- open water, a field of grass -- and an empty slot is dropped rather than
-- reserved.  A dry run counts first so the sheet is allocated at the size it
-- actually needs.
-- HOW A BAKED SHEET IS WRITTEN, and this is where the hitch was.
--
-- Reported from play: "the game Sometimes Freezes when I enter towns please
-- go through and optimize emerald to run as well as possible."
--
-- A Hoenn pair bakes into two sheets of 256 by up to about 1700 pixels, and
-- both of them were filled a pixel at a time with ImageData:setPixel -- close
-- to a million calls across the two layers, each one crossing into C, dividing
-- three channels by 255 and bounds-checking itself.  That is most of a second
-- of frozen game, and a town entry pays it more than once: the town's own pair
-- and every neighbouring route's, all inside the one frame that loads the map.
-- It only happens when the pair is not already cached, which is exactly why
-- the freeze was "sometimes".
--
-- So the pixels go into a plain Lua buffer and become an ImageData in ONE
-- call.  Two things make that nearly free: the buffer holds interned
-- four-byte strings rather than numbers, and a tileset has at most 256
-- colours in it, so the string for a colour is built once and reused for
-- every pixel of that colour after.  What is left per pixel is a table store.
--
-- The slow path is kept for a runtime whose newImageData will not take a
-- data string, because a missing tileset is a worse outcome than a stall.
local function pixelCanvas(w, h)
  local char, floor = string.char, math.floor
  local blank = "\0\0\0\0"
  local buf, memo = {}, {}
  for i = 1, w * h do buf[i] = blank end
  local function plot(x, y, r, g, b)
    if x >= 0 and y >= 0 and x < w and y < h then
      local key = r * 65536 + g * 256 + b
      local px = memo[key]
      if not px then
        px = char(floor(r), floor(g), floor(b), 255)
        memo[key] = px
      end
      buf[y * w + x + 1] = px
    end
  end
  local function finish()
    local ok, surface = pcall(love.image.newImageData, w, h, "rgba8",
                              table.concat(buf))
    if ok and surface then return surface end
    surface = love.image.newImageData(w, h)
    for i = 1, w * h do
      local px = buf[i]
      if px ~= blank then
        local x, y = (i - 1) % w, floor((i - 1) / w)
        surface:setPixel(x, y, px:byte(1) / 255, px:byte(2) / 255,
                         px:byte(3) / 255, 1)
      end
    end
    return surface
  end
  return plot, finish
end

local function buildReflectionCover(record, tiles, statics, frames)
  if not (love.image and love.image.newImageData) then return end
  frames = math.max(1, frames or 1)
  local ids = {}
  for id = 0, statics - 1 do
    if tiles:reflectionCoverLayer(id) == 2 then
      local any = false
      tiles:drawLayer(id, 2, 0, 0, function() any = true end)
      if any then ids[#ids + 1] = id end
    end
  end
  if #ids == 0 then return end

  local cols = require("src.render.Gen3Tiles").SHEET_COLS
  local w = cols * 16
  local h = math.ceil(#ids * frames / cols) * 16
  local plot, finish = pixelCanvas(w, h)
  local quads = {}
  for f = 0, frames - 1 do
    tiles:setAnimFrame(f)
    for i, id in ipairs(ids) do
      local slot = (i - 1) * frames + f
      local ox, oy = (slot % cols) * 16, math.floor(slot / cols) * 16
      tiles:drawLayer(id, 2, ox, oy, plot)
      quads[id] = quads[id] or {}
      quads[id][f + 1] = love.graphics.newQuad(ox, oy, 16, 16, w, h)
    end
  end
  tiles:setAnimFrame(0)
  record.cover = love.graphics.newImage(finish())
  record.coverQuads = quads
  record.coverFrames = frames
end

function TileRenderer.gen3SheetsFor(tilesetDef, data, layout)
  if not (tilesetDef and tilesetDef.blockTiles == 2) then return nil end
  local key = tilesetDef.id
  gen3Clock = gen3Clock + 1
  gen3Used[key] = gen3Clock
  local hit = gen3Sheets[key]
  if hit ~= nil then return hit or nil end
  gen3Sheets[key] = false            -- do not retry a failed bake every frame

  local store = data and data.map_tilesets
  local primary = store and store[tilesetDef.primaryKey]
  if not primary then
    Logger.warn("gen3 tiles: %s names primary %s, which is not in "
                .. "map_tilesets", tostring(key), tostring(tilesetDef.primaryKey))
    return nil
  end
  if not (love.image and love.image.newImageData) then return nil end

  local Gen3Tiles = require("src.render.Gen3Tiles")
  local tiles = Gen3Tiles.new({
    primary = primary,
    secondary = tilesetDef.secondaryKey and store[tilesetDef.secondaryKey] or nil,
  }, layout)

  -- ---- WHAT MOVES, AND WHERE ITS OTHER PICTURES GO ------------------------
  --
  -- The cartridge animates by replacing tiles in VRAM; this port cannot,
  -- because a pair is composited into two flat sheets once and blitted as
  -- 16x16 quads.  Re-baking the sheet four times a second is not an option
  -- -- it is 336,000 pixels.
  --
  -- So the sheet gets LONGER instead.  Only the metatiles that actually
  -- contain an animated tile are baked again, once per frame, into slots past
  -- the end of the static grid; drawing then picks a different QUAD for those
  -- cells and costs nothing per frame.  For Hoenn's outdoor pair that is
  -- eight pictures of about a hundred metatiles -- water, shoreline,
  -- waterfall, flowers -- rather than eight of all 656.
  local movers = tiles:animatedMetatiles()
  local frames = (#movers > 0) and tiles:animFrameCount() or 1
  local statics = tiles:metatileCount()
  local slots = statics + #movers * (frames - 1)
  local cols = require("src.render.Gen3Tiles").SHEET_COLS
  local w = cols * 16
  local h = math.ceil(slots / cols) * 16
  if w <= 0 or h <= 0 then return nil end

  -- slotOf[metatile][frame] -- frame 1 is the static sheet's own slot, so a
  -- pair with one frame builds no extra rows and nothing below changes
  local slotOf, nextSlot = {}, statics
  for _, id in ipairs(movers) do
    slotOf[id] = { [1] = id }
    for f = 2, frames do
      slotOf[id][f] = nextSlot
      nextSlot = nextSlot + 1
    end
  end

  local built = {}
  for layer = 1, 2 do
    local plot, finish = pixelCanvas(w, h)
    -- the static sheet holds FRAME ZERO, not the tileset's shipped bytes: the
    -- cartridge copies frame zero in before the first field frame is drawn,
    -- so the shipped tile is never the one anybody sees
    tiles:setAnimFrame(0)
    tiles:bakeLayer(layer, plot)
    for f = 2, frames do
      tiles:setAnimFrame(f - 1)
      for _, id in ipairs(movers) do
        tiles:bakeMetatileInto(id, layer, slotOf[id][f], plot)
      end
    end
    built[layer] = love.graphics.newImage(finish())
  end
  tiles:setAnimFrame(0)

  local record = { bottom = built[1], top = built[2], width = w, height = h,
                   tiles = tiles, metatiles = statics, slots = slots,
                   animSlots = (frames > 1) and slotOf or nil,
                   animFrames = frames, animStep = tiles:animStep() }
  buildReflectionCover(record, tiles, statics, frames)
  gen3Sheets[key] = record
  gen3Evict()
  Probe.say("tilebake", "%s: movers=%d frames=%d step=%s primaryAnims=%s "
            .. "secondaryAnims=%s",
            tostring(key), #movers, frames, tostring(record.animStep),
            tostring(type(primary) == "table" and primary.animations ~= nil),
            tostring(tilesetDef.secondaryKey ~= nil
                     and type(store[tilesetDef.secondaryKey]) == "table"
                     and store[tilesetDef.secondaryKey].animations ~= nil))
  Logger.info("gen3 tiles: baked %s -- %d metatiles into two %dx%d sheets%s",
              tostring(key), record.metatiles, w, h,
              frames > 1
                and (", %d of them animated over %d frames"):format(#movers,
                                                                    frames)
                or "")
  -- A PAIR THAT ANIMATES NOTHING SAYS WHY, ONCE.
  --
  -- Reported from play twice, the second time as "the water type in route 104
  -- still isn't animated".  Both halves of this are data that has to be IN
  -- THE CACHE: extractTilesetAnimations hangs `animations` on each tileset
  -- record, and a cache written before that stage existed simply has no such
  -- key -- so this bakes a perfectly correct static pair and there is nothing
  -- on screen to say that anything is missing.  Sixteen of Hoenn's tilesets
  -- carry animations and every outdoor pair is one of them, so a pair whose
  -- halves BOTH lack the key at all is a stale cache rather than a tileset
  -- that happens to hold still.
  if frames <= 1 then
    local function carries(record_)
      return type(record_) == "table" and record_.animations ~= nil
    end
    if not (carries(primary) or carries(tilesetDef.secondaryKey
                                        and store[tilesetDef.secondaryKey])) then
      warnOnce("gen3 tiles: %s carries no tileset animations at all -- this "
               .. "cache predates the stage that reads them, so no water, "
               .. "waterfall or flower bed will move until the ROM is "
               .. "imported again", tostring(key))
    end
  end
  return record
end

-- a re-import replaces the data the sheets were baked from
function TileRenderer.releaseGen3Sheets()
  gen3Sheets = {}
  gen3Used, gen3Clock = {}, 0
end

function TileRenderer.new(map, data)
  local self = setmetatable({}, TileRenderer)
  self.map = map
  self.data = data
  -- A GEN 3 TILESET HAS NO SHEET ON DISK, and that is not a gap: its art is
  -- two half-banks of 8x8 tiles that only become a picture once the primary
  -- and secondary tilesets are composited together, which happens below in
  -- gen3SheetsFor.  Asking Assets for a nil path raised on the very first
  -- Hoenn map anybody actually walked into.
  self.image = TileRenderer.atlasImage(map.tileset)
  local gbcCtx
  if data and PaletteFX.usesGbcPack() and PaletteFX.hasWorldTileset(map.tileset.id) then
    local gbc = getGbcAtlas(map.tileset.image, map.tileset.id, map.id,
                            map.tileset.tilesPerRow, data)
    if gbc then
      self.image = gbc
      self.gbcAtlas = true
      -- also recolors the animated water/flower entries below, so they
      -- match the atlas's static tiles instead of showing raw grayscale
      gbcCtx = { tilesetId = map.tileset.id, mapId = map.id, key = gbcKeyFor(map.id),
                groupColors = PaletteFX.worldGroupColors(data, map.tileset.id, map.id, nil) }
      -- ...and feeds the color-0-keyed single tiles the feet overdraw needs
      -- (see getKeyedTile): same source image and palette groups, so keep the
      -- context rather than re-deriving it per draw.
      gbcCtx.imagePath = map.tileset.image
      gbcCtx.perRow = map.tileset.tilesPerRow
      self.gbcCtx = gbcCtx
      self.gbcAtlasKey = map.tileset.image .. gbcCtx.key
      self.gbcKeyed = {}
    end
  end
  -- a full-color atlas colors everything it paints, ring and border fill
  -- included, so every draw entry point claims its rect out of the pass
  self.trueColor = map.tileset.trueColor or nil

  -- Gen2: if the tileset has palMap/palColors from ROM extraction, bake a
  -- pre-colored atlas so tiles render with correct GBC palette colors.
  --
  -- Gated on the COLORS setting for the same reason SpriteRenderer's OBJ bake
  -- is: this IS the hardware colour, so it belongs to the modes that mean
  -- "show me the hardware", and the DMG/SGB-flavoured modes have to fall
  -- through to the raw sheet and their own shade treatment.  Unconditional, it
  -- made COLORS a no-op for every Gen2 tile on screen.
  local gen2Colors = PaletteFX.usesGen2BgPal() and gen2PalColors(map.tileset)
  -- ...and this map's own seven, where the cartridge gives it seven of its
  -- own.  Before the roof swap below, because the ROM does it in that order:
  -- LoadMapPals picks the palettes, special or environment, and only then
  -- writes the map group's roof pair into whichever set it ended up with.
  local specialKey
  if gen2Colors then
    local key, rows = gen2SpecialPalette(map, data)
    if rows then gen2Colors, specialKey = rows, key end
  end
  if not self.gbcAtlas and map.tileset.palMap and #map.tileset.palMap > 0
      and gen2Colors and #gen2Colors > 0 then
    -- THE ROOF ROW IS THE MAP GROUP'S, AND ONLY ITS TWO MIDDLE COLOURS ARE.
    -- LoadMapPals copies FOUR bytes to wBGPals + roofPal * 8 + 2 -- colours 1
    -- and 2 -- and leaves 0 and 3 as the tileset's own, so a copy of the row
    -- list with just that pair replaced is the whole of it.  A copy, because
    -- `gen2Colors` is the tileset def's own table and two groups sharing a
    -- tileset would otherwise overwrite each other's roof.
    local roof = gen2RoofFor(map, data)
    if roof and roof.pair then
      local swapped = {}
      for i = 1, #gen2Colors do swapped[i] = gen2Colors[i] end
      local row = swapped[roof.palIndex + 1]
      if row then
        swapped[roof.palIndex + 1] =
          { row[1], roof.pair[1], roof.pair[2], row[4] }
      end
      gen2Colors = swapped
    end
    local key = gen2AtlasKey(map.tileset.image, roof, specialKey)
    local gen2img = getGen2Atlas(key, map.tileset.image, map.tileset.tilesPerRow,
                                 map.tileset.palMap, gen2Colors,
                                 TileRenderer.borrowStart(map.tileset), roof)
    if gen2img then
      self.image = gen2img
      self.trueColor = true
      -- ...and hand the same tile->palette lookup to buildAnim, so the
      -- animated water/flower tiles that overdraw this atlas are baked with
      -- the palette their static neighbours got (see buildAnim's colorsFor)
      local palMap, palColors = map.tileset.palMap, gen2Colors
      gbcCtx = {
        -- the variant key, not just the tileset id: the derived shimmer
        -- textures cache alongside the atlas and must not survive a mode or
        -- time-of-day change either
        key = key,
        colorsFor = function(tile)
          return TileRenderer.gen2TileColors(palMap, palColors, tile)
        end,
      }
    end
  end

  -- the 8x8 atlas quads, which only a sheet-backed tileset has
  --
  -- `perRow` IS DECLARED HERE, not inside the `if`, because buildAnim below
  -- takes it as an argument.  Scoped to the block it was invisible down there
  -- and the call passed the GLOBAL `perRow`, which is nil -- so every animated
  -- tile in the game was built with a nil stride.
  --
  -- It did not crash every time, which is what hid it: getShiftVariants keys
  -- its cache on (sheet path, tile, gbcKey) and returns before touching the
  -- stride on a hit, so the water shimmer only reached the arithmetic the
  -- FIRST time a given sheet/tile pair was ever asked for. Walking out of a
  -- cave onto a tileset whose water had not been built yet is exactly that
  -- first time: `attempt to perform arithmetic on local 'perRow' (a nil
  -- value)` at getShiftVariants, on a map that had been fine all session.
  self.quads = {}
  local perRow = map.tileset.tilesPerRow
  if self.image and perRow then
    local iw, ih = self.image:getDimensions()
    for t = 0, (iw / 8) * (ih / 8) - 1 do
      self.quads[t] = love.graphics.newQuad((t % perRow) * 8,
                                            math.floor(t / perRow) * 8, 8, 8, iw, ih)
    end
  end

  local def = map.def
  -- The map body measured in 8px tiles (each block is 4x4 tiles).  The tile
  -- layer is drawn windowed to the camera (see :ensureWindow) instead of
  -- baked into a whole-map SpriteBatch, so a map becoming visible -- a warp,
  -- a connection seam -- costs nothing to "build": there is no per-map batch
  -- construction that scales with map size, which is what stuttered.
  -- Tiles per block edge: 4 for a Gen 1/Gen 2 block (32px), 2 for a Gen 3
  -- metatile (16px).  Taken from the map object, which took it from the
  -- tileset -- the same number Map:tileAt divides by, so the renderer's window
  -- and the collision lookup cannot drift apart.
  self.blockTiles = map.blockTiles or 4
  self.bodyTilesW = def.width * self.blockTiles
  self.bodyTilesH = def.height * self.blockTiles

  -- Gen 3: one quad per 16x16 metatile out of two composited sheets, instead
  -- of one quad per 8x8 tile out of a single atlas.  When the bake is not
  -- available the renderer falls through to the tile path and the map draws
  -- as whatever its `blocks` table holds, which is blank rather than wrong.
  self.gen3 = TileRenderer.gen3SheetsFor(map.tileset, data,
                                         data and data.constants
                                         and data.constants.gen3Layout)
  self.gen3Key = map.tileset and map.tileset.id
  if self.gen3 then
    local cols = require("src.render.Gen3Tiles").SHEET_COLS
    self.gen3Quads = {}
    -- every SLOT, which is the metatiles plus the extra pictures the animated
    -- ones were baked into
    for id = 0, (self.gen3.slots or self.gen3.metatiles) - 1 do
      self.gen3Quads[id] = love.graphics.newQuad(
        (id % cols) * 16, math.floor(id / cols) * 16, 16, 16,
        self.gen3.width, self.gen3.height)
    end
  end
  -- Animated tiles overdraw the static window each frame.  Only the per-entry
  -- render spec (textures/sequence/gate) is kept here; the animated cells are
  -- gathered per camera window in :ensureWindow, so nothing here scales with
  -- map size either.  Entry order decides which entry claims a tile listed
  -- twice (the vanilla water-then-flower-then-spinner precedence).
  local anims, claimedBy = {}, {}
  local declared = map.tileset.animatedTiles
                   or TileRenderer.defaultAnimatedTiles(map.tileset)
  for _, spec in ipairs(declared) do
    local anim = buildAnim(spec, map.tileset.image, perRow, self.quads, gbcCtx)
    if anim then
      anims[#anims + 1] = anim
      for _, tile in ipairs(anim.tiles) do
        if claimedBy[tile] == nil then claimedBy[tile] = anim end
      end
    end
  end

  -- duplicate-tile alias remap (RED++ atlas only): [blockId][0-based cell]
  -- -> alias tile id (see PaletteFX.TILE_ALIASES / getGbcAtlas's bake)
  local aliasMap
  if gbcCtx then
    for _, al in ipairs(PaletteFX.TILE_ALIASES and PaletteFX.TILE_ALIASES[map.id] or {}) do
      aliasMap = aliasMap or {}
      local cells = aliasMap[al.block] or {}
      for ci in pairs(al.cells) do cells[ci] = al.alias end
      aliasMap[al.block] = cells
    end
  end
  self.aliasMap = aliasMap
  self.anims = anims
  self.claimedBy = claimedBy

  -- border-fill image is built lazily in :ensureBorderFill so a VOID FILL
  -- option change can swap trees/water/black without reloading the map
  self.borderFillMode = nil
  self.borderFill = nil

  return self
end

-- Bake a static repeating 32x32 of `block` into self.borderFill.
local function bakeBorderFill(self, block)
  local border = self.map.tileset.blocks[block + 1]
  if not border then return end
  -- 32x32 real pixels: a DPI-scaled canvas would bake the border block at a
  -- fractional texel size and the repeat-wrapped image would then tile at
  -- non-square pixels (#208, see src/render/PixelCanvas.lua)
  local canvas = require("src.render.PixelCanvas").new(32, 32)
  love.graphics.push("all")
  love.graphics.setCanvas(canvas)
  love.graphics.clear(1, 1, 1, 1)
  for ty = 0, 3 do
    for tx = 0, 3 do
      local quad = self.quads[border[ty * 4 + tx + 1]]
      if quad then love.graphics.draw(self.image, quad, tx * 8, ty * 8) end
    end
  end
  love.graphics.setCanvas()
  love.graphics.pop()
  local img = love.graphics.newImage(canvas:newImageData())
  img:setWrap("repeat", "repeat")
  img:setFilter("nearest", "nearest")
  self.borderFill = img
end

-- THE VOID AROUND A GEN 3 MAP.
--
-- A Game Boy map fills the space beyond its edge by repeating one BORDER
-- BLOCK out of the tileset, and `bakeBorderFill` above bakes that block into
-- a 32x32 tile.  A Gen 3 tileset has no `blocks` array to take one from --
-- its metatiles only become pictures once the primary and secondary banks are
-- composited -- so that bake returned immediately and the void was left
-- unpainted.  White, on every map in Hoenn, indoors and out.
--
-- The cartridge does not repeat one block either: each map carries its own
-- 2x2 BORDER PATCH, which is four metatiles and exactly 32x32 pixels -- the
-- same tile size the fill wants.  Outdoors it is the treeline around
-- Littleroot and the routes; indoors it is the black the room sits in.  One
-- read covers both, which is why there is no indoor special case here.
local function bakeGen3BorderFill(self)
  if not (self.gen3 and self.gen3Quads) then return end
  local border = self.map.def and self.map.def.border
  if type(border) ~= "string" or #border < 8 then return end
  local canvas = require("src.render.PixelCanvas").new(32, 32)
  love.graphics.push("all")
  love.graphics.setCanvas(canvas)
  -- black, not white: a patch with a transparent metatile in it is a hole
  -- onto whatever is behind, and on this cartridge that is black
  love.graphics.clear(0, 0, 0, 1)
  love.graphics.setColor(1, 1, 1, 1)
  for i = 0, 3 do
    local entry = border:byte(i * 2 + 1) + border:byte(i * 2 + 2) * 256
    local quad = self.gen3Quads[entry % 1024]
    if quad then
      local x, y = (i % 2) * 16, math.floor(i / 2) * 16
      -- both layers, in the order the map itself draws them
      love.graphics.draw(self.gen3.bottom, quad, x, y)
      love.graphics.draw(self.gen3.top, quad, x, y)
    end
  end
  love.graphics.setCanvas()
  love.graphics.pop()
  local img = love.graphics.newImage(canvas:newImageData())
  img:setWrap("repeat", "repeat")
  img:setFilter("nearest", "nearest")
  self.borderFill = img
end

-- WATER void fill: the eight hshift frames of tile $14 (same cycle as map
-- water), wrap-tiled so the void scrolls in lockstep with on-map water.
local function ensureWaterBorderFill(self)
  if self.borderWaterTextures then return true end
  local map = self.map
  local perRow = map.tileset.tilesPerRow
  local colors, gbcKey
  if self.gbcAtlas and self.data then
    local group = PaletteFX.worldGroupAt(map.tileset.id, map.id, WATER_TILE)
    local groupColors = PaletteFX.worldGroupColors(
      self.data, map.tileset.id, map.id, nil)
    colors = group and groupColors and groupColors[group + 1] or nil
    gbcKey = gbcKeyFor(map.id)
  end
  local textures = getShiftVariants(map.tileset.image, perRow, WATER_TILE,
                                    colors, gbcKey)
  if not textures then return false end
  for _, img in ipairs(textures) do
    img:setWrap("repeat", "repeat")
    img:setFilter("nearest", "nearest")
  end
  self.borderWaterTextures = textures
  return true
end

-- (re)build the repeating border image when the VOID FILL mode or tileset
-- choice changes.  OVERWORLD "black" leaves borderFill nil and draws a
-- solid clear; "water" keeps the live hshift textures instead of a bake.
function TileRenderer:ensureBorderFill()
  local block = borderBlockFor(self.map)
  -- a Gen 3 map paints its void from its OWN border patch, so it is always
  -- "map" -- the VOID FILL option picks between three Gen 1 tileset blocks
  -- that a Hoenn tileset does not have
  local mode = self.gen3 and "map"
              or (block == false and "black")
              or ((self.map.def.tileset == "OVERWORLD")
                  and (TileRenderer.voidFill or "trees")
                  or "map")
  local ready = (mode == "black")
                or (mode == "water" and self.borderWaterTextures)
                or (mode ~= "water" and mode ~= "black" and self.borderFill)
  if self.borderFillMode == mode and ready then return end
  if self.borderFill and self.borderFill.release then
    pcall(self.borderFill.release, self.borderFill)
  end
  self.borderFill = nil
  -- shared shift-variant cache: drop the reference only, never release
  self.borderWaterTextures = nil
  self.borderFillMode = mode
  if not self.gen3 and (mode == "black" or block == false or block == nil) then
    return
  end
  if mode == "water" then
    if ensureWaterBorderFill(self) then return end
    -- headless / missing pixels: fall back to the static water block bake
  end
  if self.gen3 then
    pcall(bakeGen3BorderFill, self)
    return
  end
  pcall(bakeBorderFill, self, block)
end

-- tile the border block across the whole view (world-aligned so it
-- meshes seamlessly with the ring batch)
function TileRenderer:drawBorderFill(camX, camY, vw, vh)
  self:ensureBorderFill()
  if self.borderFillMode == "black" then
    love.graphics.setColor(0, 0, 0, 1)
    love.graphics.rectangle("fill", 0, 0, vw, vh)
    love.graphics.setColor(1, 1, 1, 1)
    return
  end
  if self.trueColor then PaletteFX.markTrueColor(0, 0, vw, vh) end
  local x, y = math.floor(camX), math.floor(camY)
  -- one reused Quad per renderer, mutated in place: this runs every
  -- overworld frame, so allocating a fresh Quad here churned the GC
  local q = self.borderQuad
  if self.borderFillMode == "water" and self.borderWaterTextures then
    local step = math.floor(animFrame / ANIM_PERIOD) % #WATER_OFFSETS + 1
    local tex = self.borderWaterTextures[WATER_OFFSETS[step] + 1]
    if not tex then return end
    if q then
      q:setViewport(x, y, vw, vh, 8, 8)
    else
      q = love.graphics.newQuad(x, y, vw, vh, 8, 8)
      self.borderQuad = q
    end
    love.graphics.draw(tex, q, 0, 0)
    return
  end
  if not self.borderFill then return end
  if q then
    q:setViewport(x, y, vw, vh, 32, 32)
  else
    q = love.graphics.newQuad(x, y, vw, vh, 32, 32)
    self.borderQuad = q
  end
  love.graphics.draw(self.borderFill, q, 0, 0)
end

-- GB OBJ-to-BG priority: sprites show through BG color 0 and hide under
-- colors 1-3.  Tall-grass overdraw needs the same rule, otherwise the
-- tile's white gaps paint opaque boxes over the sprite's feet.
local color0KeyShader -- false = unavailable
local function getColor0KeyShader()
  if color0KeyShader ~= nil then return color0KeyShader or nil end
  local ok, sh = pcall(love.graphics.newShader, [[
    vec4 effect(vec4 color, Image tex, vec2 tc, vec2 sc) {
      vec4 p = Texel(tex, tc) * color;
      // same shade-0 cutoff PaletteFX uses (DMG white / lightest gray)
      if (p.r > 0.83 && p.g > 0.83 && p.b > 0.83) p.a = 0.0;
      return p;
    }
  ]])
  color0KeyShader = ok and sh or false
  return color0KeyShader or nil
end

-- RED++ (COLORS=ADVANCED): the color-0 key, BAKED instead of tested for.
local function getKeyedTile(self, tile)
  local ctx = self.gbcCtx
  local cached = self.gbcKeyed[tile]
  if cached ~= nil then return cached or nil end
  local img = false
  if ctx.groupColors and love.image and love.image.newImageData then
    local group = PaletteFX.worldGroupAt(ctx.tilesetId, ctx.mapId, tile)
    local colors = group and ctx.groupColors[group + 1]
    local src = Assets.imageData(ctx.imagePath)
    local ox = (tile % ctx.perRow) * 8
    local oy = math.floor(tile / ctx.perRow) * 8
    local out = love.image.newImageData(8, 8)
    for py = 0, 7 do
      for px = 0, 7 do
        local r, g, b, a = src:getPixel(ox + px, oy + py)
        -- read shade 0 off the RAW sheet, on recolorSample's own cutoff, so
        -- the keyed pixels are exactly the ones the shader path keys
        local shade0 = r > 0.83
        r, g, b, a = recolorSample(r, g, b, a, colors)
        out:setPixel(px, py, r, g, b, shade0 and 0 or a)
      end
    end
    img = love.graphics.newImage(out)
  end
  self.gbcKeyed[tile] = img
  return img or nil
end

function TileRenderer:drawCellBottomRaw(cx, cy, camX, camY)
  local ty = cy * 2 + 1
  for i = 0, 1 do
    local tx = cx * 2 + i
    local tile = self.map:tileAt(tx, ty)
    local keyed = tile and self.gbcCtx and getKeyedTile(self, tile)
    if keyed then
      love.graphics.draw(keyed, tx * 8 - camX, ty * 8 - camY)
    else
      local quad = self.quads[tile]
      if quad then
        love.graphics.draw(self.image, quad, tx * 8 - camX, ty * 8 - camY)
      end
    end
  end
end

-- redraw a cell's bottom tile row (tall grass hides the lower half of
-- sprites standing in it, like the GB sprite-priority trick)
function TileRenderer:drawCellBottom(cx, cy, camX, camY)
  -- the RED++ path is pre-keyed; the white test would be a no-op there at
  -- best, and a false hit on some other group's near-white color 0 at worst
  local shader = not self.gbcCtx and getColor0KeyShader() or nil
  if shader then love.graphics.setShader(shader) end
  self:drawCellBottomRaw(cx, cy, camX, camY)
  if shader then love.graphics.setShader() end
end

-- queue the same bottom tile row for the post-zone sprite-redraw pass
-- (GBC mode: OBP-baked sprites replay after the zone shader, so the
-- grass patch that hides their feet must replay over them, colorized
-- with the map's palette and color-0 keyed)
function TileRenderer:markCellBottomRedraw(cx, cy, camX, camY, colors)
  local ty = cy * 2 + 1
  for i = 0, 1 do
    local tx = cx * 2 + i
    local quad = self.quads[self.map:tileAt(tx, ty)]
    if quad then
      PaletteFX.markSpriteRedraw(self.image, quad, tx * 8 - math.floor(camX),
                                 ty * 8 - math.floor(camY), 1, colors, true)
    end
  end
end

-- Which of the pair's pictures is showing.  One counter for the whole pair:
-- the cartridge advances every animation off the same tick, so an eight-frame
-- water and a four-frame waterfall stay in step with each other by taking the
-- same number modulo their own lengths.
function TileRenderer:gen3AnimFrame()
  local record = self.gen3
  if not (record and record.animSlots and (record.animFrames or 1) > 1) then
    return nil
  end
  return math.floor(animFrame / (record.animStep or 16)) % record.animFrames
end

function TileRenderer:gen3QuadFor(id)
  local quads = self.gen3Quads
  if not quads then return nil end
  local slots = self.gen3.animSlots and self.gen3.animSlots[id]
  local frame = slots and self:gen3AnimFrame()
  if frame then return quads[slots[frame + 1] or id] end
  return quads[id]
end

local WINDOW_MARGIN = 8 -- tiles of slack kept around the view between refills

-- The window bounds, written in place.  A fresh table per fill is one
-- allocation every time the camera leaves the margin, which on a Gen 3 map
-- used to be several times a second.
function TileRenderer:setWin(tx0, ty0, tx1, ty1)
  local win = self.win
  if win then
    win.tx0, win.ty0, win.tx1, win.ty1 = tx0, ty0, tx1, ty1
  else
    self.win = { tx0 = tx0, ty0 = ty0, tx1 = tx1, ty1 = ty1 }
  end
end

function TileRenderer:ensureWindow(camX, camY, vw, vh)
  local W, H = self.bodyTilesW, self.bodyTilesH
  vw = vw or W * 8 -- a nil view (headless draw) means the whole body
  vh = vh or H * 8
  -- visible body-tile range (8px tiles), clamped to the map body
  local tx0 = math.min(W, math.max(0, math.floor(camX / 8)))
  local ty0 = math.min(H, math.max(0, math.floor(camY / 8)))
  local tx1 = math.max(0, math.min(W, math.floor((camX + vw) / 8) + 1))
  local ty1 = math.max(0, math.min(H, math.floor((camY + vh) / 8) + 1))
  local win = self.win
  -- A NEW ANIMATION FRAME IS A NEW FILL.  The window batch holds one quad per
  -- cell and the animated cells' quads have just moved, so a window that is
  -- still geometrically valid is no longer visually valid -- and this is the
  -- only thing that makes Hoenn's water move.  Cells that do not animate are
  -- re-added with the quad they already had.
  --
  -- ...UNLESS NOTHING IN THIS WINDOW MOVES.  The fill below already knows
  -- which cells took an animated slot, and on most of Hoenn -- indoors, and
  -- every route away from water -- the answer for the whole window is NONE.
  -- Rebuilding several hundred cells into two batches four times a second to
  -- redraw an identical picture is the periodic hitch, so a window that drew
  -- no animated cell keeps its fill until the camera leaves it.
  local frame = self:gen3AnimFrame()
  if frame ~= self.gen3Frame then
    self.gen3Frame = frame
    if self.winAnimated ~= false then
      if self.gen3Frame ~= nil then gen3Refills = gen3Refills + 1 end
      win = nil
    end
  end
  -- ...and SAY so, whatever the answer is.  This reported only when `frame`
  -- was non-nil, which made the one outcome that matters -- no animation
  -- record at all, so nothing can ever move -- indistinguishable from the
  -- probe not running.  It also went through Logger, which buffers 64 lines
  -- and truncates on boot, so it never reached the disk even when it did fire
  -- (src/core/Probe.lua says the rest).
  if not gen3Timed then
    gen3Clock0 = gen3Clock0 or animFrame
    if animFrame - gen3Clock0 >= GEN3_CLOCK_PROBE then
      gen3Timed = true
      local g = self.gen3
      Probe.say("tileclock",
                "ticks=%d frame=%s | gen3=%s animSlots=%s animFrames=%s "
                .. "animStep=%s refills=%d quads=%s",
                animFrame - gen3Clock0, tostring(frame), tostring(g ~= nil),
                tostring(g and g.animSlots ~= nil),
                tostring(g and g.animFrames), tostring(g and g.animStep),
                gen3Refills, tostring(self.gen3Quads ~= nil))
    end
  end
  if win and tx0 >= win.tx0 and ty0 >= win.ty0
     and tx1 <= win.tx1 and ty1 <= win.ty1 then
    return -- still inside the last fill
  end
  -- refill with margin so the next few scrolled pixels stay covered
  tx0 = math.max(0, tx0 - WINDOW_MARGIN)
  ty0 = math.max(0, ty0 - WINDOW_MARGIN)
  tx1 = math.min(W, tx1 + WINDOW_MARGIN)
  ty1 = math.min(H, ty1 + WINDOW_MARGIN)
  if self.gen3 then
    TileRenderer.touchGen3(self.gen3Key)
    -- one quad per CELL into each of the two layer batches.  The tile-grid
    -- bounds above are still the right window -- a Gen 3 cell is two tiles
    -- wide, so dividing by blockTiles gives the cell range directly.
    if not self.winBatch then
      self.winBatch = love.graphics.newSpriteBatch(self.gen3.bottom, 1024, "dynamic")
      self.winBatchTop = love.graphics.newSpriteBatch(self.gen3.top, 1024, "dynamic")
    end
    self.winBatch:clear()
    self.winBatchTop:clear()
    local map = self.map
    local n = self.blockTiles
    local cx0, cy0 = math.floor(tx0 / n), math.floor(ty0 / n)
    local cx1, cy1 = math.ceil(tx1 / n), math.ceil(ty1 / n)
    local slots = self.gen3.animSlots
    local moving = false
    for cy = cy0, cy1 - 1 do
      for cx = cx0, cx1 - 1 do
        local id = map:blockAt(cx, cy)
        local quad = id and self:gen3QuadFor(id)
        if quad then
          local wx, wy = cx * 16, cy * 16
          self.winBatch:add(quad, wx, wy)
          self.winBatchTop:add(quad, wx, wy)
          if slots and slots[id] then moving = true end
        end
      end
    end
    -- whether the NEXT animation tick has anything to redraw
    self.winAnimated = moving
    self:setWin(tx0, ty0, tx1, ty1)
    return
  end

  -- Reached only when the Gen 3 bake did not happen, and a Gen 3 tileset has
  -- no sheet to fall back to: draw nothing rather than raise under the
  -- player, and leave the reason in the log (gen3SheetsFor already logged it).
  if not self.image then
    self:setWin(tx0, ty0, tx1, ty1)
    return
  end
  if not self.winBatch then
    self.winBatch = love.graphics.newSpriteBatch(self.image, 1024, "dynamic")
  end
  self.winBatch:clear()
  local anims = self.anims
  for _, anim in ipairs(anims) do
    if not anim.batch then
      anim.batch = love.graphics.newSpriteBatch(anim.textures[1], 256, "dynamic")
    end
    anim.batch:clear()
  end
  local map, quads = self.map, self.quads
  local claimedBy, aliasMap = self.claimedBy, self.aliasMap
  local n = self.blockTiles
  for ty = ty0, ty1 - 1 do
    local by = math.floor(ty / n)
    local tyn = ty % n
    for tx = tx0, tx1 - 1 do
      local blockId = map:blockAt(math.floor(tx / n), by)
      local block = map.tileset.blocks[blockId + 1]
      if block then
        local ci = tyn * n + (tx % n)
        local tile = block[ci + 1]
        local remap = aliasMap and aliasMap[blockId]
        if remap and remap[ci] then tile = remap[ci] end
        local wx, wy = tx * 8, ty * 8
        local quad = quads[tile]
        if quad then self.winBatch:add(quad, wx, wy) end
        local anim = claimedBy[tile]
        if anim then
          if anim.quadFor then
            anim.batch:add(anim.quadFor(tile), wx, wy)
          else
            anim.batch:add(wx, wy)
          end
        end
      end
    end
  end
  self:setWin(tx0, ty0, tx1, ty1)
end

-- draw the static tile window, then its animated overdraw, at the camera offset
function TileRenderer:drawWindow(camX, camY, vw, vh)
  self:ensureWindow(camX, camY, vw, vh)
  if self.winBatch then
    love.graphics.draw(self.winBatch, -math.floor(camX), -math.floor(camY))
  end
  self:drawAnimated(camX, camY)
end

-- animated overdraw at the current step, over the static window batch.  The
-- cells were gathered for the current camera window by :ensureWindow, so this
-- only ever touches on-screen animated tiles.
function TileRenderer:drawAnimated(camX, camY)
  local anims = self.anims
  if not anims then return end
  local x, y = -math.floor(camX), -math.floor(camY)
  for _, anim in ipairs(anims) do
    local batch = anim.batch
    if batch then
      if anim.gate then
        -- a gated entry has only the two frames the asm has (patch /
        -- restore-to-static); when the gate is shut draw nothing so the
        -- already-static window tile shows through unchanged
        if gateOpen(anim.gate) then love.graphics.draw(batch, x, y) end
      else
        local step = math.floor(animFrame / anim.period) % #anim.sequence + 1
        batch:setTexture(anim.textures[anim.sequence[step]])
        love.graphics.draw(batch, x, y)
      end
    end
  end
end

-- Put a water metatile's covering half back over a reflection.
--
-- Called by the field pass for each cell a reflection was painted into, right
-- after the reflections and before the sprites: it restores the bridge plank,
-- the shoreline lip, the jetty -- whatever the cartridge's object priority 3
-- puts a reflection behind (Gen3Tiles:reflectionCoverLayer).  Cells whose
-- metatile has nothing above the bottom layer are not in the sheet and cost a
-- table lookup.
-- What the cover WOULD do here, without doing it: for the probe.
function TileRenderer:reflectionCoverInfo(cx, cy)
  local record = self.gen3
  if not (record and record.tiles and self.map and self.map.blockAt) then
    return nil
  end
  local id = self.map:blockAt(cx, cy)
  if not id then return nil end
  return id, record.tiles:reflectionCoverLayer(id),
         record.coverQuads and record.coverQuads[id] ~= nil,
         record.coverFrames
end

function TileRenderer:drawReflectionCover(cx, cy, camX, camY)
  local record = self.gen3
  if not (record and record.tiles and self.map and self.map.blockAt) then return end
  local id = self.map:blockAt(cx, cy)
  if not id then return end
  local x, y = cx * 16 - math.floor(camX), cy * 16 - math.floor(camY)
  local layer = record.tiles:reflectionCoverLayer(id)
  if layer == 2 then
    -- COVERED: only the metatile's second half is above the reflection --
    -- the pier's planks over the water they are built on, and, on open
    -- water, the wave crests.
    --
    -- ...AND THOSE CRESTS MOVE.  Baked at frame zero this was a still
    -- photograph laid over a reflection, which is why the water's own
    -- distortion never reached it: on the cartridge the crests are the
    -- SAME animated tiles as the water below, so they travel across the
    -- mirrored character and break it up as they pass.  That IS the
    -- distortion -- it is the map's animation seen through the reflection,
    -- not a wobble applied to the sprite.
    local set = record.coverQuads and record.coverQuads[id]
    local frame = set and self:gen3AnimFrame()
    local quad = set and (set[(frame or 0) + 1] or set[1])
    if quad then love.graphics.draw(record.cover, quad, x, y) end
  elseif layer == 1 then
    -- NORMAL: nothing of this metatile is on the bottom layer, so ALL of it
    -- is above the reflection.  Its layer 1 is what the bottom sheet holds at
    -- this slot (layer 2 went to the top sheet), so the static draw is the
    -- overdraw -- and gen3QuadFor keeps it on the right animation frame, so a
    -- reflection that reaches a moving tile does not freeze it.
    local quad = self:gen3QuadFor(id)
    if quad and record.bottom then
      love.graphics.draw(record.bottom, quad, x, y)
    end
  end
  -- SPLIT: drawAbove already covers it.
end

-- the drawn extent of one batch in world-canvas pixels; `blocks` is the
-- ring width the batch reaches past the map body on every side
function TileRenderer:markTrueColor(camX, camY, blocks)
  local def = self.map.def
  PaletteFX.markTrueColor(-math.floor(camX) - blocks * 32,
                          -math.floor(camY) - blocks * 32,
                          (def.width + 2 * blocks) * 32,
                          (def.height + 2 * blocks) * 32)
end

function TileRenderer:draw(camX, camY, vw, vh)
  if self.trueColor then self:markTrueColor(camX, camY, BORDER_BLOCKS) end
  self:drawWindow(camX, camY, vw, vh)
end

-- The Gen 3 TOP layer, drawn AFTER the sprites.
--
-- This is the half of the metatile the player walks behind: treetops, the
-- upper storey of a building, the far rail of a bridge.  The overworld calls
-- it once the entity pass is done; on a Gen 1/Gen 2 map it returns false and
-- does nothing, so the call site needs no generation test.
--
-- Nothing already here can stand in for it.  drawCellBottom redraws ONE
-- cell's lower tile row to hide a sprite's feet in tall grass -- a per-cell
-- exception -- where a Gen 3 top layer applies to every cell on the map.
function TileRenderer:drawAbove(camX, camY, vw, vh)
  if not self.gen3 then return false end
  self:ensureWindow(camX, camY, vw, vh)
  if self.winBatchTop then
    love.graphics.draw(self.winBatchTop, -math.floor(camX), -math.floor(camY))
  end
  return true
end

-- Does this map draw anything above the sprites?  Lets a caller skip the
-- state changes around the call on the generations that do not.
function TileRenderer:hasAboveLayer()
  return self.gen3 ~= nil
end

-- IS THIS MAP'S ART ALREADY IN COLOUR?
--
-- A Gen 1/Gen 2 map is four shades and gets its colour from a screen-space
-- palette pass; a Gen 3 map's metatile sheets are composited straight out of
-- the cartridge in full colour and want no pass at all.  Published because
-- the caller that has to know is the one deciding what colorization zones to
-- hand the renderer, and it has no other way to ask.
function TileRenderer:isTrueColor()
  return self.gen3 ~= nil
end

-- body only, for connected-map strips.  Identical to :draw now that the
-- border ring is served by :drawBorderFill for the current map too -- the
-- only remaining difference is the trueColor mark extent.
function TileRenderer:drawMapOnly(camX, camY, vw, vh)
  if self.trueColor then self:markTrueColor(camX, camY, 0) end
  self:drawWindow(camX, camY, vw, vh)
end

local function safeRelease(o)
  if o and o.release then pcall(o.release, o) end
end

-- Release only the GPU objects this instance built and uniquely owns: the
-- two SpriteBatches, the border-fill image and its quad, the per-tile
-- quads, and the animated-overdraw batches.  Deliberately leaves the
-- tileset atlas (self.image, shared through Assets/imageCache) and the
-- animation textures (shared module caches) alone -- other maps still use
-- them.  Used by :rebuild before it swaps in fresh batches, and by
-- :release on eviction.
function TileRenderer:releaseBatches()
  safeRelease(self.winBatch); self.winBatch = nil
  -- the Gen 3 top-layer batch lives and dies with the bottom one; the two
  -- SHEETS behind them are module-cached per tileset pair and are not
  -- released here, exactly as the animated tile textures are not
  safeRelease(self.winBatchTop); self.winBatchTop = nil
  safeRelease(self.borderFill); self.borderFill = nil
  safeRelease(self.borderQuad); self.borderQuad = nil
  -- shared shift-variant cache; only drop the reference
  self.borderWaterTextures = nil
  self.borderFillMode = nil
  self.win = nil
  if self.quads then
    for _, q in pairs(self.quads) do safeRelease(q) end
    self.quads = nil
  end
  if self.anims then
    for _, a in ipairs(self.anims) do
      safeRelease(a.batch); a.batch = nil
      -- a.textures are shared, module-cached: never released here
    end
  end
end

-- Full teardown for eviction (MapLoader.evict): the owned batches, plus
-- the RED++ per-map recolored atlas, which -- unlike the plain tileset
-- atlas -- is unique to this map (gbcAtlasCache is keyed by map id).
function TileRenderer:release()
  self:releaseBatches()
  if self.gbcKeyed then
    -- baked per instance, shared with nobody (see getKeyedTile)
    for _, img in pairs(self.gbcKeyed) do safeRelease(img) end
    self.gbcKeyed = nil
    self.gbcCtx = nil
  end
  if self.gbcAtlas and self.image then
    local key = self.gbcAtlasKey or (self.map.tileset.image .. gbcKeyFor(self.map.id))
    if gbcAtlasCache[key] == self.image then gbcAtlasCache[key] = nil end
    self.gbcAtlasKey = nil
    safeRelease(self.image)
    self.image = nil
    self.gbcAtlas = nil
  end
  self.anims = nil
end

-- rebuild after a block change (Cut trees, card-key doors).  The tile layer
-- is read live from the map on every window fill, so a block swap only needs
-- the cached window dropped -- the next draw re-reads the changed blocks.  No
-- SpriteBatch is reconstructed; that is the whole point of the windowed draw.
function TileRenderer:rebuild()
  self.win = nil
end

-- drop every atlas and every derived animation texture so the next
-- TileRenderer.new re-resolves through the asset search path.  Live
-- instances keep the batches they already built; MapLoader.invalidateAll
-- is what drops those (14 §cache-invalidation contract).
function TileRenderer.invalidate()
  imageCache = {}
  shiftVariants = {}
  frameImages = {}
  toggleImages = {}
  stripData = {}
  gen2AtlasCache = {}
  -- THE GEN 1 BAKE AND THE ANIMATED PAGES TOO, which this did not drop.
  --
  -- `gbcAtlasCache` is keyed on the image and the MAP -- not on the colour
  -- mode -- so a mode change neither missed the cache nor cleared it, and a
  -- Gen 1 world went on drawing in the palette it was first baked with. It
  -- survived because nothing changed the mode mid-session until the map
  -- editor grew a COLOURS control; the launcher sets it before the game
  -- builds anything.
  gbcAtlasCache = {}
  atlasFrames = {}
end

Assets.register(TileRenderer.invalidate)

return TileRenderer
