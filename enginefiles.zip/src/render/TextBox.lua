-- The lower dialogue box: bordered 20x6-tile window, typewriter effect,
-- two visible text lines, A to advance.
--
-- Text markers (from the extractor): \n = second line, \v = scroll one
-- line up, \f = page break (wait for A, clear).  {PLAYER}/{RIVAL} etc. are
-- substituted before display.  Pushed on the state stack; pops itself when
-- the text is exhausted and A is pressed, then calls onDone.

local Logger = require("src.core.Logger")
local Font = require("src.render.Font")
local Theme = require("src.ui.Theme")
local Timing = require("src.core.Timing")

local TextBox = {}
TextBox.__index = TextBox

-- theme-free fallbacks; geometry resolves against Theme.textBox at
-- construction time, so an unthemed boot stays byte-identical
local BOX_TX, BOX_TY, BOX_TW, BOX_TH = 0, 12, 20, 6
local MAX_COLS = 18

-- opts.choice: when the last page has typed out, a YES/NO ChoiceBox pops
-- up over the still-visible text (YesNoChoicePokeCenter and friends);
-- the box then closes and choice(yes) runs instead of onDone.
-- opts.defaultNo starts the cursor on NO.
-- opts.auto: texts with no `prompt` (a text_asm/text_end tail, like
-- _UsedStrengthText) never wait for a button: once the last page has
-- typed out, auto.sound() runs (returning an audio source blocks like
-- WaitForSoundToFinish; nil headless), then auto.delay frames pass
-- (default 3, Delay3) and the box pops itself + calls onDone.  No
-- blinking cursor, no Press_AB beep.
-- opts.auto.tick, when given, runs once per frame for as long as the box
-- is held open.  It is the only per-frame hook a script has while a box is
-- up: StateStack updates the top state only, so the overworld and its
-- ScriptRunner are frozen underneath (the Pewter JIGGLYPUFF dance drives
-- its spin off it, data/scripts/story5.lua, #249).
-- opts.stay: text that ends in `done` rather than `prompt` returns from
-- PrintText with the box still on screen while the caller keeps running
-- (_ViridianSchoolBlackboardText2, data/text/text_2.asm:646).  Such a box
-- waits for nothing, shows no blinking arrow, and never pops itself --
-- whoever pushed it owns the pop.  stay.onShown fires once, on the frame
-- the last page finishes typing, which is where the caller pushes whatever
-- goes on top of it (#591).
function TextBox.new(game, text, onDone, opts)
  local self = setmetatable({}, TextBox)
  self.game = game
  self.onDone = onDone
  self.choice = opts and opts.choice
  self.defaultNo = opts and opts.defaultNo
  self.choiceNoSound = opts and opts.noSound
  self.auto = opts and opts.auto
  self.stay = opts and opts.stay
  local box = Theme.textBox or {}
  self.boxTx = box.tx or BOX_TX
  self.boxTy = box.ty or BOX_TY
  self.boxTw = box.tw or BOX_TW
  self.boxTh = box.th or BOX_TH
  self.maxCols = box.maxCols or MAX_COLS
  self.textX = (self.boxTx + 1) * 8
  -- WHERE THE TWO LINES SIT, which stopped being a constant when the font
  -- stopped being 8 pixels tall.
  --
  -- A Game Boy character is one tile, so rows two and four of a six-tile
  -- window put an 8-pixel line in the middle of each half and leave a tile of
  -- air under the second.  Emerald's dialogue face is FIFTEEN pixels tall:
  -- the same two rows put its second line at 128..142 inside a window whose
  -- interior ends at 135, and it printed straight through its own bottom
  -- border.
  --
  -- The pitch is not the problem -- both games space their lines two tiles
  -- apart, which is what the cartridge does -- so the pitch is kept and the
  -- PAIR is lifted by however much it overhangs.  A Game Boy font overhangs by
  -- nothing and lands exactly where it always did; a taller one rises until
  -- its descenders clear the frame.
  local pitch = 16
  local glyphH = Font.glyphHeight()
  local interiorBottom = (self.boxTy + self.boxTh - 1) * 8
  local line1 = (self.boxTy + 2) * 8
  local overhang = (line1 + pitch + glyphH) - interiorBottom
  if overhang > 0 then line1 = line1 - overhang end
  -- never above the frame's own inner edge, however tall the face
  line1 = math.max(line1, (self.boxTy + 1) * 8)
  self.line1Y = line1
  self.line2Y = line1 + pitch
  text = TextBox.substitute(game, text)
  self.pages = TextBox.paginate(text, self.maxCols)
  self.pageIndex = 1
  self.lineIndex = 1
  self.charIndex = 0
  self.shown = {} -- visible lines (max 2), each a list of glyph codes
  self.waiting = false
  self.contAdvance = false
  self.done = false
  self.blink = 0
  self:beginLine()
  return self
end

-- The runtime tokens substitute() knows, as handlers the tokens registry
-- serves.  Each is fn(game, arg) -> replacement, or nil to drop the token.
-- RAM keeps pokered's stale-buffer semantics: give_item copies the item
-- name into stringBuffer, like GiveItem -> CopyToStringBuffer
-- (home/give.asm), and it stays set afterwards.
-- The Gen 3 script buffers, as the placeholders below read them.  Slot n on
-- the cartridge is stringBuffers[n + 1] here, which is where Commands.g3_buffer
-- puts it.
local function gen3Buffer(game, n)
  local slots = game and game.stringBuffers
  local value = slots and slots[n]
  return type(value) == "string" and value or ""
end

TextBox.TOKENS = {
  PLAYER = function(game) return game.save.player.name or "RED" end,
  RIVAL = function(game) return game.save.player.rival or "BLUE" end,
  -- GEN 3 PLACEHOLDERS.  A GBA cartridge splices its own set in, and an
  -- unhandled token is left in the line verbatim -- so Birch's very first
  -- question would have read "You're BRENDAN{KUN} who's moving to my
  -- hometown of LITTLEROOT."  {KUN} is the Japanese honorific and is EMPTY
  -- in English, which is exactly what returning "" means here; the two
  -- version names are the cartridge's own.
  KUN = function() return "" end,
  -- ...and the three the SCRIPT fills in.  A Gen 3 line splices a buffered
  -- string with $FD 02/03/04, and the buffer commands that fill them
  -- (bufferitemname, bufferspeciesname, bufferstring and the rest) already
  -- write game.stringBuffers -- there was simply nothing reading it back out,
  -- so every line that used one printed the token instead.  The braces are
  -- not in this cartridge's font, so it reached the screen as "Our VAR1 is
  -- upstairs, I think."
  --
  -- An unfilled slot expands to NOTHING rather than to its own name: a line
  -- whose buffer a script has not written yet is a gap in a sentence, which
  -- reads as an oversight, where the token reads as a bug.
  VAR1 = function(game) return gen3Buffer(game, 1) end,
  VAR2 = function(game) return gen3Buffer(game, 2) end,
  VAR3 = function(game) return gen3Buffer(game, 3) end,
  VERSION = function() return "EMERALD" end,
  AQUA = function() return "AQUA" end,
  MAGMA = function() return "MAGMA" end,
  ARCHIE = function() return "ARCHIE" end,
  MAXIE = function() return "MAXIE" end,
  KYOGRE = function() return "KYOGRE" end,
  GROUDON = function() return "GROUDON" end,
  RAM = function(game, arg)
    -- polished addresses the player through TX_RAM rather than a dedicated
    -- control char, so these two are dialogue-critical: without them the
    -- name token fell through to the shared string buffer, and every NPC
    -- who addressed the player used the last buffered item name instead --
    -- "so, ULTRA BALL!".
    if arg == "wPlayerName" then return game.save.player.name or "RED" end
    if arg == "wRivalName" then return game.save.player.rival or "SILVER" end
    if arg == "wTrendyPhrase" then return game.trendyPhrase or "COOL" end
    if arg == "wStringBuffer" then return game.stringBuffer end
    -- Gen2's text_ram splices wStringBuffer1..5 into the middle of a line,
    -- and the three script-addressable ones carry DIFFERENT things at the
    -- same time: 3 the trainer name, 4 a species, 5 a landmark.  Collapsing
    -- them onto one buffer meant whichever was written last won -- on the
    -- phone that is always the species, so every landmark line read "Come
    -- pick it up on MAGIKARP."
    --
    -- Slots the writers name explicitly win; a slot nobody has written falls
    -- back to the single legacy buffer, which is what every non-phone caller
    -- (the berry trees, the item gifts) still writes.
    if arg and arg:match("^wStringBuffer%d$") then
      local slot = tonumber(arg:sub(-1))
      local slots = game.stringBuffers
      local value = slot and slots and slots[slot]
      if value ~= nil then return value end
      return game.stringBuffer
    end
    if arg == "wBoxNumString" then return game.boxNumString end
    -- SendNewMonToBox / _SentToBoxText reads the deposited nick here
    if arg == "wBoxMonNicks" then return game.boxMonNicks end
    return nil
  end,
}

function TextBox.registerInto(registry, _, owner)
  for id, handler in pairs(TextBox.TOKENS) do
    registry:register(id, handler, owner)
  end
end

function TextBox.substitute(game, text)
  local Tokens = require("src.script.Tokens")
  local handlers = game.data and game.data.tokens or TextBox.TOKENS
  return Tokens.expand(game, text, handlers)
end

-- Split marked-up text into pages of lines.  \v-scrolled lines become
-- additional lines on the same page (the box scrolls them).
-- pages.contBefore[p][i] is true when line i was preceded by \v (cont):
-- pokered ContText waits for A/B + ▼ before scrolling that line in.
function TextBox.paginate(text, maxCols)
  -- A missing line is a content bug, not a reason to take the whole game
  -- down.  It arrives as nil whenever a dataset lacks a symbol some caller
  -- assumed -- Prism's new game died here, at `text .. "\f"` below, on the
  -- intro's very first line -- and an empty page list just closes the box,
  -- which is recoverable where a hard error is not.
  if type(text) ~= "string" then text = text ~= nil and tostring(text) or "" end
  maxCols = maxCols or (Theme.textBox and Theme.textBox.maxCols) or MAX_COLS
  -- maxCols is a column count, so the budget is that many vanilla 8px
  -- cells.  Measuring in pixels rather than columns is what lets a mod's
  -- variable-advance page wrap correctly (#186).
  local budget = maxCols * 8
  local pages = {}
  local contBefore = {}
  -- Soft-wrap on glyph boundaries, never byte boundaries: a line is over
  -- budget by what it *draws*, and the cut falls between glyphs so a
  -- multi-byte char is never torn in half.
  local function pushLine(lines, conts, line, wait)
    while true do
      local spans = Font.split(line)
      local fit = Font.spansFitting(spans, budget)
      if fit >= #spans then break end
      -- a glyph wider than the whole box still has to advance by one
      fit = math.max(fit, 1)
      local cut = spans[fit].to
      for i = fit, 1, -1 do
        if line:sub(spans[i].from, spans[i].to) == " " then
          cut = spans[i].to
          break
        end
      end
      table.insert(lines, line:sub(1, cut))
      table.insert(conts, wait)
      wait = false
      line = line:sub(cut + 1)
    end
    table.insert(lines, line)
    table.insert(conts, wait)
  end
  for pageText in (text .. "\f"):gmatch("(.-)\f") do
    if pageText ~= "" then
      local lines, conts = {}, {}
      local pos, waitNext = 1, false
      while true do
        local npos = pageText:find("[\n\v]", pos)
        if not npos then
          pushLine(lines, conts, pageText:sub(pos), waitNext)
          break
        end
        pushLine(lines, conts, pageText:sub(pos, npos - 1), waitNext)
        waitNext = pageText:sub(npos, npos) == "\v"
        pos = npos + 1
      end
      if lines[#lines] == "" then
        table.remove(lines)
        table.remove(conts)
      end
      if #lines > 0 then
        table.insert(pages, lines)
        table.insert(contBefore, conts)
      end
    end
  end
  if #pages == 0 then
    pages = { { "" } }
    contBefore = { { false } }
  end
  pages.contBefore = contBefore
  return pages
end

-- PLAIN PROSE -> THE MARKED-UP TEXT THE CARTRIDGE WOULD HAVE HAD.
--
-- Cartridge text arrives carrying its own layout: `\n` starts the second
-- line, `\f` ends a page and waits for A. Text an author typed in the map
-- editor carries none of that -- it is a sentence -- so `paginate` wrapped it
-- to the box width and put every one of the resulting lines on a SINGLE page.
-- A page with ten lines does not wait; it scrolls them past and closes. The
-- report was "the text box just runs to the end without me pressing A", which
-- is exactly that.
--
-- So the layout is put back. The wrapping is `paginate`'s own -- called here
-- rather than reimplemented, because it measures in PIXELS against the font
-- actually loaded (a mod's variable-advance font wraps differently) and a
-- second copy that counted characters would disagree with the box it is
-- wrapping for.
--
-- TWO LINES A PAGE, which is what the window shows. Not three with a scroll:
-- the ROM's own authored text is written two lines at a time, and a box that
-- scrolled a line away before the reader pressed anything is the bug being
-- fixed, not a smaller version of it.
--
-- THE AUTHOR'S OWN BREAKS ARE KEPT. A blank line between paragraphs becomes a
-- page break, and a single newline starts a new line -- so someone who laid
-- their dialogue out deliberately gets what they laid out, and someone who
-- typed one long sentence gets it wrapped for them.
function TextBox.fromProse(text, maxCols)
  if type(text) ~= "string" or text == "" then return text end
  -- Already marked up: leave it exactly alone. Cartridge text comes through
  -- here too by way of the same call sites, and re-paginating it would move
  -- breaks its author chose.
  if text:find("[\f\v]") then return text end

  -- THE AUTHOR'S OWN BREAKS ARE UNITS, not suggestions.
  --
  -- A single newline is a line break -- the ROM's `\n` means exactly that --
  -- so each typed line is wrapped on its own and its pieces stay in order. A
  -- BLANK line ends the page, which is how anyone lays out dialogue without
  -- being taught a markup.
  --
  -- The alternative -- reflowing everything into one paragraph -- was the
  -- first cut, and it silently discarded a layout the author had chosen. Being
  -- friendlier to someone who typed one long line is not worth overriding
  -- someone who typed three short ones deliberately.
  local blocks, current = {}, {}
  for line in (text .. "\n"):gmatch("(.-)\n") do
    if line:match("^%s*$") then
      if #current > 0 then blocks[#blocks + 1] = current; current = {} end
    else
      current[#current + 1] = (line:gsub("^%s+", ""):gsub("%s+$", ""))
    end
  end
  if #current > 0 then blocks[#blocks + 1] = current end
  if #blocks == 0 then return text end

  local pages = {}
  for _, block in ipairs(blocks) do
    local wrapped = {}
    for _, line in ipairs(block) do
      -- `paginate` on a break-free string yields one page holding every
      -- wrapped line, which is precisely the list this wants. Called rather
      -- than reimplemented: it measures in PIXELS against the font actually
      -- loaded, and a second copy counting characters would disagree with the
      -- box it is wrapping for.
      for _, piece in ipairs(TextBox.paginate(line, maxCols)[1] or { line }) do
        wrapped[#wrapped + 1] = piece
      end
    end
    local i = 1
    while i <= #wrapped do
      local a, b = wrapped[i], wrapped[i + 1]
      pages[#pages + 1] = b and (a .. "\n" .. b) or a
      i = i + 2
    end
  end
  return table.concat(pages, "\f")
end

function TextBox:currentLine()
  return self.pages[self.pageIndex][self.lineIndex]
end

function TextBox:beginLine()
  self.charIndex = 0
  self.codes = Font.encode(self:currentLine())
  if #self.shown >= 2 then
    table.remove(self.shown, 1)
    self.scrollPx = 8 -- pixel scroll-up (ScrollTextUpOneLine)
  end
  table.insert(self.shown, {})
end

function TextBox:update(dt)
  local input = self.game.input
  self.blink = (self.blink + 1) % 60
  -- A page or CONT advance blocks the whole box while the original's scroll
  -- and clear run (src/core/Timing.lua TEXT_SCROLL_PAIR / TEXT_PAGE_CLEAR).
  -- Nothing types and no input is read until it drains.
  if (self.holdFrames or 0) > 0 then
    self.holdFrames = self.holdFrames - 1
    return
  end
  if self.done then
    -- opts.stay: the box is finished but stays up under whatever the caller
    -- pushed over it; StateStack updates the top state only, so this runs
    -- exactly once (#591)
    if self.stay then
      if not self.stayShown then
        self.stayShown = true
        if self.stay.onShown then self.stay.onShown() end
      end
      return
    end
    if self.auto then
      if not self.autoStarted then
        self.autoStarted = true
        self.autoSrc = self.auto.sound and self.auto.sound() or nil
        self.autoTimer = 0
      end
      -- auto.tick: one call per frame for as long as the box is held open,
      -- run before the autoSrc gate so a tick-driven gate can clear itself
      -- on the same frame.  It is the only per-frame hook a script gets
      -- while a box is up, since StateStack updates the top state only and
      -- the overworld underneath is frozen (the Pewter JIGGLYPUFF spin,
      -- #249).
      if self.auto.tick then self.auto.tick() end
      if self.autoSrc and self.autoSrc.isPlaying and self.autoSrc:isPlaying() then
        -- WaitForSoundToFinish, but bounded.  This gate swallows input, so a
        -- source that never reports itself finished -- a looping def, a
        -- driver that leaves isPlaying() true, an OpenAL device that stalls
        -- -- is not a slow box, it is a hard freeze with no way out: the
        -- report was the game locking on the Clear Bell hand-over in the
        -- Radio Tower, which is a keyItem verbosegiveitem and so the one
        -- box in that scene with a fanfare gate on it.  No fanfare in either
        -- generation runs longer than about six seconds, so give up at ten
        -- and hand the box to the ordinary A/B path.
        self.autoWaited = (self.autoWaited or 0) + 1
        if self.autoWaited < 600 then
          return -- the cry is still sounding (WaitForSoundToFinish)
        end
        Logger.warn("text box: fanfare never finished, releasing the box")
        self.autoSrc = nil
      end
      -- auto.wait: the pet-NPC cries (PewterNidoranHouseNidoranText,
      -- ViridianNicknameHouseSpearowText) have nothing queued behind the
      -- cry, so DisplayTextID's trailing WaitForTextScrollButtonPress still
      -- runs once it is over -- their maps enable auto text box drawing,
      -- which zeroes wDoNotWaitForButtonPressAfterDisplayingText
      -- (home/window.asm AutoTextBoxDrawingCommon).  Drop the auto gate and
      -- hand the box to the plain A/B path, which also starts the blinking
      -- arrow, instead of popping it (#247, #251).
      if self.auto.wait then
        self.auto = nil
        return
      end
      self.autoTimer = self.autoTimer + 1
      local delay = self.auto.delay or 3
      -- auto.onOverlap: fired once when the delay elapses but before the
      -- box closes, so an overlay (the Pallet "!" bubble) can appear
      -- while the box is still on screen; the box then lingers
      -- auto.overlap more frames before popping (scripts/PalletTown.asm
      -- PalletTownOakText: DelayFrames 10 then EmotionBubble over the
      -- still-shown "Hey! Wait!" box).
      if self.auto.onOverlap and not self.overlapFired
         and self.autoTimer >= delay then
        self.overlapFired = true
        self.auto.onOverlap()
      end
      if self.autoTimer >= delay + (self.auto.overlap or 0) then
        self.game.stack:pop()
        if self.onDone then self.onDone() end
      end
      return
    end
    if self.choice then
      if not self.choicePushed then
        self.choicePushed = true
        local ChoiceBox = require("src.ui.ChoiceBox")
        self.game.stack:push(ChoiceBox.new(self.game, function(yes)
          self.game.stack:pop() -- this text box, under the choice
          self.choice(yes)
        end, { defaultNo = self.defaultNo, noSound = self.choiceNoSound,
               -- this box is anchored below it; the pair moves together
               anchor = "bottom" }))
      end
      return
    end
    if input:wasPressed("a") or input:wasPressed("b") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      self.game.stack:pop()
      if self.onDone then self.onDone() end
    end
    return
  end
  if self.waiting then
    -- _ContText and Paragraph both print the â–¼ and run ProtectedDelay3
    -- before ManualTextScroll starts watching the joypad (home/text.asm:265,
    -- :234), so the arrow is up for three frames that swallow the button.
    if (self.preWait or 0) > 0 then
      self.preWait = self.preWait - 1
      return
    end
    if input:wasPressed("a") or input:wasPressed("b") then
      require("src.core.Sound").play(self.game.data, "Press_AB")
      self.waiting = false
      if self.contAdvance then
        -- ContText / ManualTextScroll: keep the box, scroll one line
        self.contAdvance = false
        self.lineIndex = self.lineIndex + 1
        self:beginLine()
        -- ScrollTextUpOneLine is 5 blocking frames and, as its own comment
        -- says, is "always called twice in a row" (home/text.asm:280-305)
        self.holdFrames = Timing.TEXT_SCROLL_PAIR
      else
        self.shown = {}
        self.pageIndex = self.pageIndex + 1
        self.lineIndex = 1
        self:beginLine()
        -- ClearScreenArea then DelayFrames 20: the box sits empty before the
        -- next page starts typing (home/text.asm:236-240)
        self.holdFrames = Timing.TEXT_PAGE_CLEAR
      end
    end
    return
  end
  -- typewriter cadence: one character every N frames, N = the OPTION
  -- text speed (TextSpeedOptionData frame delays 1/3/5); holding A/B
  -- prints every frame like the original's held-button fast path
  local delay = (self.game.save.options and self.game.save.options.textSpeed) or 3
  if delay ~= 1 and delay ~= 3 and delay ~= 5 then delay = 3 end
  if input:isDown("a") or input:isDown("b") then delay = 1 end
  self.charTimer = (self.charTimer or 0) + 1
  while self.charTimer >= delay do
    self.charTimer = self.charTimer - delay
    if self.charIndex < #self.codes then
      self.charIndex = self.charIndex + 1
      local line = self.shown[#self.shown]
      line[#line + 1] = self.codes[self.charIndex]
    else
      -- line finished
      local page = self.pages[self.pageIndex]
      if self.lineIndex < #page then
        local nextIdx = self.lineIndex + 1
        local conts = self.pages.contBefore and self.pages.contBefore[self.pageIndex]
        if conts and conts[nextIdx] then
          -- pokered <CONT>: ▼ + WaitForTextScrollButtonPress before scroll
          self.waiting = true
          self.preWait = Timing.TEXT_PRE_ADVANCE
          self.contAdvance = true
        else
          self.lineIndex = nextIdx
          self:beginLine()
        end
      elseif self.pageIndex < #self.pages then
        self.waiting = true
        self.preWait = Timing.TEXT_PRE_ADVANCE
        self.contAdvance = false
      else
        self.done = true
      end
      break
    end
  end
end

-- THE BOX HAS TO FIT ON THE SURFACE IT IS DRAWN ON.
--
-- The UI canvas is the Game Boy's 160x144 unless a state on the stack asks
-- for more, and the text box never did -- it had no reason to while every
-- box in the port was Red's twenty tiles.  Emerald's is twenty-eight, and a
-- 224-pixel box on a 160-pixel canvas is drawn off the right-hand edge and
-- blitted at the canvas's own scale, which is not the world's: the box came
-- out larger than the map behind it AND cut off.
--
-- Asking is all that is needed -- Game:draw already reallocates the canvas
-- for whichever state on the stack wants a native surface, and centres the
-- Game Boy-coordinate layouts inside it.  A box that fits the classic screen
-- asks for the classic screen, so nothing about Gen 1 or Gen 2 changes.
-- Theme owns the answer, and the FIELD gives the same one -- see
-- OverworldState:uiSize.  Asking here alone made the whole screen step down a
-- scale every time a box opened, because the fit scale follows the surface.
function TextBox:uiSize()
  return Theme.uiSize()
end

function TextBox:draw()
  -- The dialogue box belongs against the bottom of the screen, not floating
  -- in the middle of a zoomed-out letterbox.  Declared per frame; the
  -- renderer blits this region to the screen edge and the rest of the UI
  -- where it always was (Renderer:setUIAnchor).
  local r = self.game and self.game.renderer
  if r and r.setUIAnchor then
    r:setUIAnchor(self.boxTx * 8, self.boxTy * 8,
                  self.boxTw * 8, self.boxTh * 8, "bottom")
  end
  Font.drawDialogueBox(self.boxTx, self.boxTy, self.boxTw, self.boxTh)
  love.graphics.setColor(0, 0, 0, 1)
  if self.scrollPx and self.scrollPx > 0 then
    self.scrollPx = self.scrollPx - 2
    if self.scrollPx <= 0 then self.scrollPx = nil end
  end
  -- Only the retained line carries the offset: it slides up from where it
  -- already sat (line2Y) to line1Y.  The incoming line is drawn at its home
  -- row instead, because offsetting it too put fresh glyphs 8px low -- on the
  -- box's bottom border -- whenever the typewriter beat the 4-frame slide
  -- (#314).  The sub-tile slide is ours to begin with: ScrollTextUpOneLine
  -- (home/text.asm:283) copies the rows up whole and waits 5 frames, so
  -- nothing in the original is ever drawn between two rows.
  local off = self.scrollPx or 0
  local ys = { self.line1Y, self.line2Y }
  -- THE PEN ADVANCES BY EACH GLYPH'S OWN WIDTH, not by a flat eight.
  --
  -- A flat eight is Red's font, which is monospaced -- there the two agree.
  -- Emerald's runs 3 to 10 pixels, so a fixed pitch makes an 'i' as wide as a
  -- 'W': the text comes out airy and much wider than the cartridge draws it,
  -- and a line the wrapper measured as fitting runs off the end of the box.
  -- The wrapper already measures with Font.advanceOf, so this is what makes
  -- the drawing agree with the measuring rather than merely look better.
  for i, line in ipairs(self.shown) do
    local y = (ys[i] or self.line2Y) + (i == 1 and off or 0)
    local pen = self.textX
    for _, code in ipairs(line) do
      Font.drawCode(code, pen, y)
      pen = pen + Font.advanceOf(code)
    end
  end
  if (self.waiting or (self.done and not self.choice and not self.auto
                       and not self.stay))
     and self.blink < 30 then
    -- page-advance cursor: glyph $EE by default, the blinking down arrow
    -- the original prints via `ld a, "▼"` (home/text.asm)
    Font.drawCode(Theme.moreArrow or 0xEE,
                  (self.boxTx + self.boxTw - 2) * 8,
                  (self.boxTy + self.boxTh - 1) * 8 - 4)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

return TextBox
