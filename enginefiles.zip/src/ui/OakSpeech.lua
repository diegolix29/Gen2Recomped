-- The intro sequence (engine/movie/oak_speech/oak_speech.asm): Oak's
-- welcome, the NIDORINO show-off, player and rival naming, and the
-- closing "legend is about to unfold" text followed by the shrink-away.
--
-- Steps are a data table so mods can reshape the whole speech through
-- hooks:wrap("intro.oak_speech.build").  Vanilla ids stay stable so a
-- mod can insertBefore("name_player", ...) without counting indices.
-- Calls onDone() after popping itself.

local Assets = require("src.render.Assets")
local Sound = require("src.core.Sound")
local Music = require("src.core.Music")
local Logger = require("src.core.Logger")
local Runtime = require("src.mods.Runtime")
local TextBox = require("src.render.TextBox")
local Font = require("src.render.Font")
local Strings = require("src.core.Strings")
local GameVersion = require("src.core.GameVersion")

local OakSpeech = {}
OakSpeech.__index = OakSpeech
OakSpeech.isOpaque = true

-- The speech is a white field with a pic on it, and its dialogue box docks to
-- the WINDOW's bottom edge (Renderer:setUIAnchor, via TextBox).  The white it
-- fills below is only the 160x144 UI canvas, so once the box moved to the
-- window edge the two stopped touching: black letterbox showed between the
-- bottom of Oak's white and the top of the box he is speaking from.  Filling
-- the voids with the paper shade -- the same opt-in a battle uses -- puts the
-- box back on the field.  Not a literal 1,1,1: the canvas is colorized, so
-- endFrame matches it with PaletteFX.paperShade.
OakSpeech.letterboxWhite = true

-- FadeInIntroPic runs a 6-step palette fade; MovePicLeft wipes the mon
-- sprite in from the right.  Both play out before the beat's text prints.
local FADE_FRAMES = 24
local WIPE_FRAMES = 32

-- naming presets are boot config (field.boot.namePresets), which a total
-- conversion replaces; the Red/Blue lists remain the fallback
local function namePresets(game, who, fallback)
  local boot = game.data.field and game.data.field.boot
  local presets = boot and boot.namePresets and boot.namePresets[who]
  if type(presets) == "table" and #presets > 0 then return presets end
  return fallback
end

-- SGB: generic whole-screen palette (SET_PAL_GENERIC)
function OakSpeech:sgbPalettes(game)
  return require("src.render.PaletteFX").wholeNamed(game.data, "MEWMON")
end

local FALLBACKS = {
  _OakSpeechText1 = Strings.source("Hello there!\nWelcome to the\vworld of POKéMON!\fMy name is OAK!\nPeople call me\vthe POKéMON PROF!"),
  _OakSpeechText2A = Strings.source("This world is\ninhabited by\vcreatures called\vPOKéMON!"),
  _OakSpeechText2B = Strings.source("\fFor some people,\nPOKéMON are\vpets. Others use\vthem for fights.\fMyself...\fI study POKéMON\nas a profession."),
  _OakSpeechText3 = Strings.source("{PLAYER}!\fYour very own\nPOKéMON legend is\vabout to unfold!\fA world of dreams\nand adventures\vwith POKéMON\vawaits! Let's go!"),
  _IntroducePlayerText = Strings.source("First, what is\nyour name?"),
  _IntroduceRivalText = Strings.source("This is your rival.\nHe has always been\vat your side.\f...Erm, what is\nhis name again?"),
  _YourNameIsText = Strings.source("Right! So your\nname is {PLAYER}!"),
  _HisNameIsText = Strings.source("That's right! I\nremember now! His\vname is {RIVAL}!"),
}

-- FALLBACKS is keyed by the GEN1 symbol names, but gen2Steps asks for the
-- GEN2 ones -- _OakText1, _OakText2, _OakText4, _OakText6, _OakText7 -- and
-- `alt` below only maps Gen1 -> Gen2, never back.  So on a Gen2 dataset that
-- does not carry those symbols, textOr("_OakText4") found no value, looked up
-- FALLBACKS["_OakText4"], which does not exist, and answered NIL.  stepText
-- passed that straight to TextBox, which concatenated it: the crash Prism hit
-- on the very first line of a new game.  Crystal and Gold have the symbols, so
-- the hole only opened on a romhack whose intro is written its own way.
--
-- _OakText5 (the "I study POKéMON as a profession" half) deliberately has no
-- entry: _OakText4 already answers with the combined 2B fallback, and pointing
-- both at it would print the same paragraph twice.  A step with no text at all
-- is skipped rather than shown empty -- see runStep.
local FALLBACK_ALIAS = {
  _OakText1 = "_OakSpeechText1",  OakText1 = "_OakSpeechText1",
  _OakText2 = "_OakSpeechText2A", OakText2 = "_OakSpeechText2A",
  _OakText4 = "_OakSpeechText2B", OakText4 = "_OakSpeechText2B",
  _OakText6 = "_IntroducePlayerText", OakText6 = "_IntroducePlayerText",
  _OakText7 = "_OakSpeechText3",  OakText7 = "_OakSpeechText3",
}

local function fallbackFor(key)
  return FALLBACKS[key] or FALLBACKS[FALLBACK_ALIAS[key] or ""]
end

local function textOr(game, key)
  local t = game.data.text
  local Version = require("src.core.GameVersion")
  local alt = {
    _OakSpeechText1 = { "_OakText1", "OakText1" },
    _OakSpeechText2A = { "_OakText2", "OakText2" },
    _OakSpeechText2B = { "_OakText4", "OakText4", "_OakText5", "OakText5" },
    _OakSpeechText3 = { "_OakText7", "OakText7" },
    _IntroducePlayerText = { "_OakText6", "OakText6" },
  }
  local value = t and t[key]
  if Version.isGen2() then
    for _, k in ipairs(alt[key] or {}) do
      local candidate = t and t[k]
      if type(candidate) == "string" and candidate ~= ""
          and not candidate:match("^%{GEN2_TEXT") then
        value = candidate
        break
      end
    end
    -- and the other direction: a Gen2 key whose own symbol is absent falls
    -- back through the Gen1 name the scaffold DOES carry
    if type(value) ~= "string" or value == "" then
      local canon = FALLBACK_ALIAS[key]
      local candidate = canon and t and t[canon]
      if type(candidate) == "string" and candidate ~= ""
          and not candidate:match("^%{GEN2_TEXT") then
        value = candidate
      end
    end
  end
  if type(value) ~= "string" then
    return fallbackFor(key)
  end
  if value == "" or value:match("^%{GEN2_TEXT") then
    return fallbackFor(key)
  end
  return value
end

-- through Assets.resolve so an enabled mod's overrides/ shadows these the
-- same way it shadows every other generated asset
local function tryImage(path)
  if not path then return nil end
  local ok, img = pcall(love.graphics.newImage, Assets.resolve(path))
  return ok and img or nil
end

-- Resolve a pic descriptor to (image, flip, trueColor).
-- Descriptors:
--   "oak" | "rival" | "player"          shorthand
--   { type = "trainer", id = "OPP_PROF_OAK" }
--   { type = "pokemon", id = "PIKACHU", flip = true }
--   { type = "player", path = "..." }   optional override path
--   { type = "image", path = "..." }
--   { type = "sprite", id = "SPRITE_RED" }
function OakSpeech.resolvePic(game, desc, speech)
  if desc == nil then return nil, false, false end
  if type(desc) == "string" then
    if desc == "oak" then
      desc = { type = "trainer", id = "OPP_PROF_OAK" }
    elseif desc == "rival" then
      desc = { type = "trainer", id = "OPP_RIVAL1" }
    elseif desc == "player" then
      desc = { type = "player" }
    else
      -- bare species id
      desc = { type = "pokemon", id = desc }
    end
  end
  local t = desc.type
  if t == "trainer" then
    if GameVersion.isGen2() and desc.id == "OPP_PROF_OAK" then
      local img = tryImage("assets/generated/battle/trainers/prof_oak.png")
      if img then return img, false, false end
    end
    if GameVersion.isGen2() and desc.id == "OPP_RIVAL1" then
      local img = tryImage("assets/generated/battle/trainers/rival1.png")
      if img then return img, false, false end
    end
    if speech and desc.id == "OPP_PROF_OAK" and speech.oakPic then
      return speech.oakPic, false, false
    end
    if speech and desc.id == "OPP_RIVAL1" and speech.rivalPic then
      return speech.rivalPic, false, false
    end
    local trainers = game.data.trainers or {}
    local tr = trainers[desc.id]
    return tryImage(tr and tr.pic), false, false
  elseif t == "pokemon" then
    if speech and desc.id == speech.demoSpecies and speech.demoPic then
      return speech.demoPic, desc.flip and true or false, speech.demoTrueColor
    end
    local path, trueColor = require("src.pokemon.Sprites").path(
      game.data, desc.id, "front", { kind = "oak" })
    return tryImage(path), desc.flip and true or false, trueColor
  elseif t == "player" then
    if speech and speech.playerPic and not desc.path then
      return speech.playerPic, false, speech.playerTrueColor
    end
    if desc.path then return tryImage(desc.path), false, false end
    local path, trueColor = require("src.pokemon.Sprites").playerPath(
      game.data, "front", { kind = "intro" })
    return tryImage(path), false, trueColor
  elseif t == "image" then
    return tryImage(desc.path), desc.flip and true or false, false
  elseif t == "sprite" then
    local sp = game.data.sprites and game.data.sprites[desc.id]
    return tryImage(sp and sp.image), desc.flip and true or false,
           sp and sp.trueColor or false
  end
  return nil, false, false
end

-- Vanilla step list.  Ids are the stable anchors mods insert around.
function OakSpeech.defaultSteps(speech)
  return {
    {
      id = "oak_welcome",
      kind = "say",
      textKey = "_OakSpeechText1",
      pic = "oak",
      reveal = "fade",
    },
    {
      id = "demo_mon",
      kind = "demo",
    },
    {
      id = "world_spiel",
      kind = "say",
      textKey = "_OakSpeechText2B",
    },
    {
      id = "ask_player_name",
      kind = "say",
      textKey = "_IntroducePlayerText",
      pic = "player",
    },
    {
      id = "name_player",
      kind = "name",
      who = "player",
      title = Strings("YOUR NAME?"),
      presetsWho = "player",
      presetsFallback = { "RED", "ASH", "JACK" },
    },
    {
      -- oak_speech.asm prints YourNameIsText right after the naming screen
      -- returns ("Right! So your name is RED!"); the port went straight on
      -- to the rival and dropped it, in every language.
      id = "confirm_player_name",
      kind = "say",
      textKey = "_YourNameIsText",
    },
    {
      id = "ask_rival_name",
      kind = "say",
      textKey = "_IntroduceRivalText",
      pic = "rival",
    },
    {
      id = "name_rival",
      kind = "name",
      who = "rival",
      title = Strings("HIS NAME?"),
      presetsWho = "rival",
      presetsFallback = { "BLUE", "GARY", "JOHN" },
    },
    {
      -- HisNameIsText, the rival's counterpart to the confirmation above
      id = "confirm_rival_name",
      kind = "say",
      textKey = "_HisNameIsText",
    },
    {
      id = "legend",
      kind = "say",
      textKey = "_OakSpeechText3",
      pic = "player",
    },
    {
      id = "shrink",
      kind = "shrink",
    },
  }
end

-- Gold/Silver run a different beat list (OakSpeech, 01:5FA5): there is no
-- rival to name here -- Silver is named later by the NameRival special -- and
-- the closing line follows the player's own naming screen directly.  Reusing
-- the Red list printed Red's rival dialogue, and the Gen1 FALLBACKS with it,
-- over a Gen2 save.  The keys are the ROM's own text labels, so textOr finds
-- them in data.text instead of falling through.
function OakSpeech.gen2Steps()
  return {
    {
      id = "oak_welcome",
      kind = "say",
      textKey = "_OakText1",
      pic = "oak",
      reveal = "fade",
    },
    {
      id = "demo_mon",
      kind = "demo",
      textKey = "_OakText2",
    },
    {
      id = "world_spiel",
      kind = "say",
      textKey = "_OakText4",
      pic = "oak",
    },
    {
      id = "study_spiel",
      kind = "say",
      textKey = "_OakText5",
    },
    -- Crystal asks which you are before it asks your name
    -- (AreYouABoyOrAreYouAGirlText, a symbol Gold does not have).  The step
    -- drops out entirely on Gold and Silver, which only have Chris.
    {
      id = "ask_gender",
      kind = "choice",
      onlyIf = "playerForms",
      notIf = "playerCustomization",
      textKey = "AreYouABoyOrAreYouAGirlText",
      textFallback = Strings("Are you a boy?\nOr are you a girl?"),
      pic = "oak",
      choices = { Strings("BOY"), Strings("GIRL") },
      values = { "boy", "girl" },
      -- A CARTRIDGE MAY OFFER MORE THAN TWO.  Polished Crystal has Chris,
      -- Kris AND Crys, and its forms table carries `order` naming every
      -- key; the labels come off each form so the menu reads CHRIS / KRIS /
      -- CRYS rather than forcing a third character into BOY/GIRL.
      choicesFromForms = true,
      saveKey = "gender",
      playerKey = "gender",
      -- swap the pic above the box to whichever character the cursor is on,
      -- so the question is answered by looking at CHRIS and KRIS rather than
      -- by reading two words
      picForValue = "playerForm",
      -- tx 13 (not 12) keeps the 7-tile box clear of the pic area, which
      -- runs to x = 104 = tile 13 for a full 7x7 portrait
      tx = 13, ty = 0, tw = 7,
    },
    -- Prism's replacement for the boy/girl question: PlayerCustomization
    -- (event/customization.asm), run from the intro at exactly this point --
    -- after the "introduce yourself" line and before the name prompt
    -- (engine/intro_menu.asm `callba PlayerCustomization`).  It writes
    -- save.player.gender as a p0..p13 form id, which is the same key the
    -- BOY/GIRL answer writes, so the name presets and every sprite lookup
    -- downstream carry on unchanged.
    {
      id = "customize_player",
      kind = "fn",
      onlyIf = "playerCustomization",
      run = function(speech, done)
        -- guarded for the same reason as Game:makeTitleState's copy: a build
        -- without the screen must skip the step, not take the intro down
        local okCust, Cust = pcall(require, "src.ui.PrismCustomization")
        if not (okCust and type(Cust) == "table") then
          Logger.error("player customisation screen unavailable: %s",
                       tostring(Cust))
          return done()
        end
        if not Cust.available(speech.game) then return done() end
        speech.game.stack:push(Cust.new(speech.game, function() done() end))
      end,
    },
    {
      id = "ask_player_name",
      kind = "say",
      textKey = "_OakText6",
    },
    {
      id = "name_player",
      kind = "name",
      who = "player",
      title = Strings("YOUR NAME?"),
      presetsWho = "player",
      presetsFallback = { "GOLD", "HIRO", "CHRIS" },
      -- Crystal offers a different default-name list per gender
      -- (ChrisNameMenuHeader.MaleNames / KrisNameMenuHeader.FemaleNames)
      presetsFromForm = true,
    },
    {
      id = "legend",
      kind = "say",
      textKey = "_OakText7",
      pic = "player",
    },
    {
      id = "shrink",
      kind = "shrink",
    },
  }
end

-- list helpers for intro.oak_speech.build wrappers (also on ModUI)
local function indexOfId(steps, id)
  for i, step in ipairs(steps) do
    if step.id == id then return i end
  end
  return nil
end

function OakSpeech.insertBefore(steps, anchorId, step)
  local i = indexOfId(steps, anchorId)
  table.insert(steps, i or (#steps + 1), step)
  return steps
end

function OakSpeech.insertAfter(steps, anchorId, step)
  local i = indexOfId(steps, anchorId)
  table.insert(steps, i and (i + 1) or (#steps + 1), step)
  return steps
end

function OakSpeech.removeId(steps, id)
  for i = #steps, 1, -1 do
    if steps[i].id == id then table.remove(steps, i) end
  end
  return steps
end

function OakSpeech.new(game, onDone)
  local self = setmetatable({}, OakSpeech)
  self.game = game
  self.onDone = onDone
  self.step = 0
  self.pic = nil
  self.answers = {}
  local trainers = game.data.trainers or {}
  self.oakPic = tryImage(trainers.OPP_PROF_OAK and trainers.OPP_PROF_OAK.pic)
  self.rivalPic = tryImage(trainers.OPP_RIVAL1 and trainers.OPP_RIVAL1.pic)
  local oakGfx = (game.data.field and game.data.field.oakSpeech) or {}
  self.cfg = oakGfx
  -- the show-off mon and the name length cap come from data; the vanilla
  -- literals stay as the fallbacks
  self.demoSpecies = oakGfx.demoSpecies or "NIDORINO"
  local demoPath, demoTrueColor = require("src.pokemon.Sprites").path(
    game.data, self.demoSpecies, "front", { kind = "oak" })
  self.demoPic = tryImage(demoPath)
  self.demoTrueColor = self.demoPic and demoTrueColor or false
  local constants = game.data.constants or {}
  self.nameLen = constants.playerNameLength or 7
  -- RedPicFront (gfx/player/red.png, shared with the trainer card) and
  -- the ShrinkPic1/ShrinkPic2 frames (gfx/player/shrink{1,2}.png)
  local playerPath, playerTrueColor = require("src.pokemon.Sprites").playerPath(
    game.data, "front", { kind = "intro" })
  self.playerPic = tryImage(playerPath)
  self.playerTrueColor = self.playerPic and playerTrueColor or false
  self.shrinkPic1 = tryImage(oakGfx.shrink1
                             or "assets/generated/intro/shrink1.png")
  self.shrinkPic2 = tryImage(oakGfx.shrink2
                             or "assets/generated/intro/shrink2.png")
  -- RedSprite: the walking sprite the pic shrinks into (frame 0 =
  -- standing, facing down)
  local red = game.data.sprites and game.data.sprites.SPRITE_RED
  self.walkSheet = tryImage(red and red.image)
  return self
end

-- A step may declare `onlyIf = "<field key>"`: it survives only when the
-- imported dataset actually carries that field.  The gender question uses it,
-- because field.playerForms exists on Crystal (which has KRIS) and nowhere
-- else -- Gold and Silver must not be asked a question with one answer.
function OakSpeech:stepApplies(step)
  local field = self.game.data and self.game.data.field
  -- `notIf` is the mirror: the step drops out when the dataset DOES carry the
  -- field.  Prism needs it -- it has playerForms like Crystal, so the boy/girl
  -- question survives its gate, but Prism does not ask that question at all.
  -- It runs a whole customisation screen instead, and asking both would set
  -- the character twice.
  if step.notIf ~= nil and (field and field[step.notIf]) ~= nil then
    return false
  end
  local key = step.onlyIf
  if key == nil then return true end
  return (field and field[key]) ~= nil
end

function OakSpeech:buildSteps()
  local steps = GameVersion.isGen2() and OakSpeech.gen2Steps()
                or OakSpeech.defaultSteps(self)
  local kept = {}
  for _, step in ipairs(steps) do
    if self:stepApplies(step) then kept[#kept + 1] = step end
  end
  steps = kept
  local hooked = Runtime.call("intro.oak_speech.build",
    function(s) return s end, steps, self)
  if type(hooked) ~= "table" then
    Logger.error("intro.oak_speech.build returned %s; keeping vanilla steps",
                 type(hooked))
    return steps
  end
  return hooked
end

function OakSpeech:enter()
  -- MUSIC_ROUTES2 plays under the whole speech (oak_speech.asm:43-48)
  Music.play(self.game.data, self.cfg.music or "Music_Routes2")
  self.answers = {}
  self.steps = self:buildSteps()
  if Runtime.wants("intro.oak_speech.started") then
    Runtime.emit("intro.oak_speech.started", { speech = self, steps = self.steps })
  end
  self:advance()
end

function OakSpeech:say(key, next)
  self.game.stack:push(TextBox.new(self.game, textOr(self.game, key), next))
end

-- A step with nothing to say is SKIPPED, not shown as an empty box.  Some
-- Gen2 datasets carry only part of the intro (Prism writes its own, so it has
-- none of Crystal's _OakText symbols), and a speech that pushes a box with no
-- pages leaves the player looking at a frame with no text and no way to know
-- whether A does anything.  Running `next` straight away keeps the sequence
-- moving through to the parts that do exist -- the name entry above all.
function OakSpeech:sayText(text, next, opts)
  if type(text) ~= "string" or text == "" then
    if next then next() end
    return
  end
  self.game.stack:push(TextBox.new(self.game, text, next, opts))
end

function OakSpeech:stepText(step)
  if step.text then return step.text end
  if step.textKey then
    local text = textOr(self.game, step.textKey)
    -- textFallback covers a symbol the dataset did not carry; the ROM's own
    -- line always wins when it is there
    if (text == nil or text == "") and step.textFallback then
      return step.textFallback
    end
    return text
  end
  return step.textFallback or ""
end

function OakSpeech:applyPic(step)
  if step.pic == nil then return end
  local img, flip, trueColor = OakSpeech.resolvePic(self.game, step.pic, self)
  if img then
    self.pic = img
    self.picFlip = flip or false
    self.picTrueColor = trueColor or false
  elseif step.pic == "player" or (type(step.pic) == "table" and step.pic.type == "player") then
    -- mirror the old fallback: player pic missing → oak
    self.pic = self.playerPic or self.oakPic
    self.picFlip = false
    self.picTrueColor = self.pic == self.playerPic and self.playerTrueColor
                        or false
  end
end

-- The intro pic for one gender, loaded on demand and cached.
-- Returns image, trueColor.  Falls back to the speech's own player pic when
-- the dataset has no playerForms (Gold and Silver), which is also what makes
-- picForValue harmless on a version that never asks the question.
function OakSpeech:formPic(gender)
  self._formPics = self._formPics or {}
  local hit = self._formPics[gender]
  if hit then return hit[1], hit[2] end
  local forms = self.game.data.field and self.game.data.field.playerForms
  local form = forms and forms[gender]
  local path = form and (form.intro or form.card)
  local img = path and tryImage(path) or self.playerPic
  local trueColor = (path and img and form.trueColor) and true or false
  if img == self.playerPic then trueColor = self.playerTrueColor or false end
  self._formPics[gender] = { img, trueColor }
  return img, trueColor
end

-- A choice step may set `picForValue = "playerForm"`: as the cursor moves,
-- the pic becomes the character that row would pick.  Nothing else about the
-- step changes, so a step without it keeps whatever applyPic put up.
function OakSpeech:applyChoicePic(step, index)
  if step.picForValue ~= "playerForm" then return end
  local gender = step.values and step.values[index]
  if type(gender) ~= "string" then return end
  local img, trueColor = self:formPic(gender)
  if not img then return end
  self.pic = img
  self.picFlip = false
  self.picTrueColor = trueColor
end

-- Once the gender is on the save, everything the speech still has to draw --
-- the legend beat's player pic, the sprite the pic shrinks into -- and the
-- overworld Player already standing on the map behind this screen have to be
-- re-resolved.  Player.new ran before the question was even asked
-- (Game:makeTitleState pushes the overworld first).
function OakSpeech:applyPlayerForm()
  self.playerPic, self.playerTrueColor = self:formPic(
    self.game.save and self.game.save.player and self.game.save.player.gender
    or "boy")
  self.playerTrueColor = self.playerPic and self.playerTrueColor or false
  local form = require("src.pokemon.Sprites").playerForm(self.game.data,
                                                         self.game.save)
  local sprites = self.game.data.sprites or {}
  local sheet = form and form.walk and sprites[form.walk]
  self.walkSheet = tryImage(sheet and sheet.image) or self.walkSheet
  self.walkQuad = nil
  local overworld = self.game.overworld
  local player = overworld and overworld.player
  if player and player.refreshForm then
    player:refreshForm(self.game.data)
  end
end

function OakSpeech:recordAnswer(step, index, label, value)
  if value == nil then value = label end
  if step.saveKey then
    self.answers[step.saveKey] = value
  end
  -- answers only live on the speech; a step that names playerKey wants the
  -- value kept on the save the way the naming step keeps the player's name
  if step.playerKey and self.game.save and self.game.save.player then
    self.game.save.player[step.playerKey] = value
    if step.playerKey == "gender" then self:applyPlayerForm() end
  end
  if Runtime.wants("intro.oak_speech.answered") then
    Runtime.emit("intro.oak_speech.answered", {
      speech = self,
      step = step,
      index = index,
      label = label,
      value = value,
      saveKey = step.saveKey,
    })
  end
end

function OakSpeech:afterReveal(step, fn)
  if step.reveal then
    self:revealPic(step.reveal, fn)
  else
    fn()
  end
end

function OakSpeech:runCry(step)
  local cry = step.cry
  if not cry then return end
  if cry == true then
    if type(step.pic) == "string" and step.pic ~= "oak"
        and step.pic ~= "rival" and step.pic ~= "player" then
      cry = step.pic
    elseif type(step.pic) == "table" and step.pic.type == "pokemon" then
      cry = step.pic.id
    else
      return
    end
  end
  Sound.playCry(self.game.data, cry)
end

function OakSpeech:runStep(step)
  local kind = step.kind or "say"
  if kind == "say" then
    self:applyPic(step)
    self:afterReveal(step, function()
      self:runCry(step)
      self:sayText(self:stepText(step), function() self:advance() end)
    end)
  elseif kind == "demo" then
    -- NIDORINO show-off: mirrored front sprite + wipe + cry + text 2A
    self.pic = self.demoPic
    self.picFlip = true
    self.picTrueColor = self.demoTrueColor
    self:revealPic("wipe", function()
      Sound.playCry(self.game.data, self.demoSpecies)
      local text = step.textKey and self:stepText(step)
                   or Strings("_OakSpeechText2A")
      self:sayText(text, function() self:advance() end)
    end)
  elseif kind == "name" then
    local who = step.who or "player"
    local presets = step.presets
    if not presets and step.presetsFromForm then
      local form = require("src.pokemon.Sprites").playerForm(self.game.data,
                                                             self.game.save)
      if form and type(form.names) == "table" and form.names[1] then
        presets = form.names
      end
    end
    presets = presets
      or namePresets(self.game, step.presetsWho or who,
                     step.presetsFallback or { "RED" })
    require("src.ui.Screens").push(self.game, "NamingScreen", {
      title = step.title or (who == "rival" and "HIS NAME?" or Strings("YOUR NAME?")),
      presets = presets,
      maxLen = step.maxLen or self.nameLen,
      onDone = function(name)
        if who == "rival" then
          self.game.save.player.rival = name
        else
          self.game.save.player.name = name
        end
        self:recordAnswer(step, 1, name, name)
        self:advance()
      end,
    })
  elseif kind == "choice" then
    self:applyPic(step)
    -- a forms table with an `order` list overrides the static pair: each
    -- entry's key is the value saved and its label is the menu row, so
    -- polished's three characters all appear (see ask_gender)
    if step.choicesFromForms then
      local forms = self.game.data and self.game.data.field
        and self.game.data.field.playerForms
      if type(forms) == "table" and type(forms.order) == "table"
         and #forms.order > 0 then
        local choices, values = {}, {}
        for _, key in ipairs(forms.order) do
          local form = forms[key]
          if form then
            choices[#choices + 1] = form.label or key:upper()
            values[#values + 1] = key
          end
        end
        if #choices >= 2 then
          step = setmetatable({ choices = choices, values = values },
                              { __index = step })
        end
      end
    end
    self:afterReveal(step, function()
      self:runCry(step)
      local function openMenu()
        local Menu = require("src.ui.Menu")
        local items = {}
        for i, label in ipairs(step.choices or {}) do
          items[i] = {
            label = label,
            onSelect = function()
              local value = label
              if step.values and step.values[i] ~= nil then
                value = step.values[i]
              end
              self:recordAnswer(step, i, label, value)
              self:advance()
            end,
          }
        end
        self.game.stack:push(Menu.new(self.game, items, {
          cancelable = step.cancelable == true,
          tx = step.tx or 4,
          ty = step.ty or 0,
          tw = step.tw or 12,
          th = step.th,
          onHighlight = step.picForValue and function(i)
            self:applyChoicePic(step, i)
          end or nil,
        }))
      end
      local text = self:stepText(step)
      if text ~= "" then
        self:sayText(text, openMenu)
      else
        openMenu()
      end
    end)
  elseif kind == "yesno" then
    self:applyPic(step)
    self:afterReveal(step, function()
      self:runCry(step)
      self:sayText(self:stepText(step), nil, {
        defaultNo = step.defaultNo,
        choice = function(yes)
          local label = yes and "YES" or "NO"
          local value = yes
          if step.values then
            if yes then
              value = step.values[1]
            else
              value = step.values[2]
            end
          end
          self:recordAnswer(step, yes and 1 or 2, label, value)
          self:advance()
        end,
      })
    end)
  elseif kind == "pic" then
    -- show a sprite with an optional reveal, no text
    self:applyPic(step)
    self:afterReveal(step, function()
      self:runCry(step)
      self:advance()
    end)
  elseif kind == "shrink" then
    Sound.play(self.game.data, "Shrink")
    -- prefer an explicit shrink text key; fall back to the legend beat
    local key = step.textKey or "_OakSpeechText3"
    self.shrinkText = self:lastPageLines(key)
    self.shrink = { frame = 0 }
  elseif kind == "fn" then
    -- full escape hatch: step.run(speech, done)
    if type(step.run) == "function" then
      step.run(self, function() self:advance() end)
    else
      self:advance()
    end
  else
    Logger.warn("oak speech unknown step kind %s (id=%s); skipping",
                tostring(kind), tostring(step.id))
    self:advance()
  end
end

-- the last two visible lines of a text's final page, pre-encoded
function OakSpeech:lastPageLines(key)
  local ok, lines = pcall(function()
    local text = TextBox.substitute(self.game, textOr(self.game, key))
    local pages = TextBox.paginate(text)
    local page = pages[#pages]
    local out = {}
    for i = math.max(1, #page - 1), #page do
      out[#out + 1] = Font.encode(page[i])
    end
    return out
  end)
  return ok and lines or nil
end

-- Reveal the current pic over `dur` frames, then run `next`.  Ticked from
-- update() while OakSpeech is the top state (before the beat's text box is
-- pushed), so the fade/wipe plays out ahead of the text like the ROM.
function OakSpeech:revealPic(kind, next)
  self.picReveal = {
    kind = kind,
    t = 0,
    dur = kind == "fade" and FADE_FRAMES or WIPE_FRAMES,
    next = next,
  }
end

function OakSpeech:advance()
  self.step = self.step + 1
  -- picFlip belongs to the pic, not to the step: OakSpeechText2 prints 2A
  -- and 2B over one flipped NIDORINO with no redraw between them
  -- (oak_speech.asm:80-83), so a pic-less step must not un-mirror what is
  -- still on screen; only applyPic and the demo step may change it (#397)
  local steps = self.steps
  if not steps then
    -- enter() builds steps; keep a path for callers that advance early
    steps = self:buildSteps()
    self.steps = steps
  end
  local step = steps[self.step]
  if step then
    if Runtime.wants("intro.oak_speech.step") then
      Runtime.emit("intro.oak_speech.step", {
        speech = self, step = step, index = self.step,
      })
    end
    self:runStep(step)
  else
    self:finish()
  end
end

function OakSpeech:finish()
  if Runtime.wants("intro.oak_speech.finished") then
    Runtime.emit("intro.oak_speech.finished", {
      speech = self, answers = self.answers,
    })
  end
  -- the map theme starts with the overworld beneath (the original's
  -- special warp into Pallet Town)
  local ow = self.game.overworld
  local mapId = (ow and ow.map and ow.map.id)
                or (self.game.save.player and self.game.save.player.map)
  if mapId then Music.playMap(self.game.data, mapId) end
  self.game.stack:pop()
  if self.onDone then self.onDone() end
end

-- Shrink timeline (oak_speech.asm .next):
--   frames  1-4   RedPicFront still up      (ld c, 4 / DelayFrames)
--   frames  5-8   ShrinkPic1                (ld c, 4 / DelayFrames)
--   frames  9-28  ShrinkPic2, music fades   (wAudioFadeOutControl; ld c, 20)
--   frames 29-78  pic area cleared, walking sprite at the standard
--                 player screen spot        (ResetPlayerSpriteData /
--                 ClearScreenArea / wUpdateSpritesEnabled; ld c, 50)
--   frames 79-102 GBFadeOutToWhite          (3 palettes x 8 frames)
function OakSpeech:update(dt)
  local r = self.picReveal
  if r then
    r.t = r.t + 1
    if r.t >= r.dur then
      self.picReveal = nil
      if r.next then r.next() end
    end
    return
  end
  if not self.shrink then return end
  local s = self.shrink
  s.frame = s.frame + 1
  if s.frame == 5 then
    self.pic = self.shrinkPic1 or self.pic
    self.picTrueColor = false
  elseif s.frame == 9 then
    self.pic = self.shrinkPic2 or self.pic
    self.picTrueColor = false
    -- wAudioFadeOutControl = 10: the music ramps to silence over ~70
    -- frames (7 levels x 10), reaching 0 just as the fade-to-white
    -- begins at frame 79, instead of a hard cut (oak_speech.asm:145-149,
    -- home/fade_audio.asm)
    Music.fadeOut(10)
  elseif s.frame == 29 then
    self.pic = nil
    self.picTrueColor = false
    self.walkVisible = true
  elseif s.frame >= 79 and s.frame <= 102 then
    self.fadeLevel = math.floor((s.frame - 79) / 8) + 1
  elseif s.frame > 102 then
    -- clear before finish(): a finished-listener that pushes a state gets
    -- ITS state popped in the speech's place, and a live shrink would call
    -- finish() again next frame, re-firing the event every frame (#308)
    self.shrink = nil
    self:finish()
  end
end

function OakSpeech:draw()
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.rectangle("fill", 0, 0, 160, 144)
  if self.pic then
    -- IntroDisplayPicCenteredOrUpperRight centered: the 7x7-tile pic
    -- area sits at hlcoord 6,4 = (48,32); smaller mon pics pad inside
    -- it like the sprite buffer does ((8 - w) >> 1) tiles across,
    -- bottom-aligned
    local w, h = self.pic:getDimensions()
    local x = 48 + math.floor((8 - w / 8) / 2) * 8
    local y = 32 + (7 - h / 8) * 8
    local reveal = self.picReveal
    local off = 0
    if reveal and reveal.kind == "fade" then
      -- FadeInIntroPic: ramp the pic's alpha up over the fade window
      love.graphics.setColor(1, 1, 1, math.min(1, reveal.t / reveal.dur))
    elseif reveal and reveal.kind == "wipe" then
      -- MovePicLeft: the pic slides in from the right edge to its spot
      off = math.floor((160 - x) * (1 - math.min(1, reveal.t / reveal.dur)))
    end
    if self.picFlip then
      -- LoadFlippedFrontSpriteByMonIndex mirrors the front sprite
      -- horizontally (wSpriteFlipped): draw with a negative x scale
      love.graphics.draw(self.pic, x + off + w, y, 0, -1, 1)
    else
      love.graphics.draw(self.pic, x + off, y)
    end
    if self.picTrueColor then
      require("src.render.PaletteFX").markTrueColor(x + off, y, w, h)
    end
    love.graphics.setColor(1, 1, 1, 1)
  end
  if self.walkVisible and self.walkSheet then
    -- ResetPlayerSpriteData: Y screen pos $3c, X screen pos $40
    self.walkQuad = self.walkQuad
      or love.graphics.newQuad(0, 0, 16, 16, self.walkSheet:getDimensions())
    love.graphics.draw(self.walkSheet, self.walkQuad, 64, 60)
  end
  if self.shrinkText then
    -- This is a REPLICA of the dialogue box that just closed, redrawn at
    -- TextBox's own rect (BOX_TX..BOX_TH = 0,12,20,6) so the last page holds
    -- while the pic shrinks.  The real box rides the bottom anchor, so this
    -- one has to as well -- otherwise the text visibly jumps up a letterbox
    -- on the frame the real box is swapped for this copy.
    local r = self.game and self.game.renderer
    if r and r.setUIAnchor then
      r:setUIAnchor(0, 12 * 8, 20 * 8, 6 * 8, "bottom")
    end
    Font.drawBox(0, 12, 20, 6)
    love.graphics.setColor(0, 0, 0, 1)
    for i, line in ipairs(self.shrinkText) do
      local y = (12 + 2 * i) * 8
      for j, code in ipairs(line) do
        Font.drawCode(code, 8 + (j - 1) * 8, y)
      end
    end
    love.graphics.setColor(1, 1, 1, 1)
  end
  if self.fadeLevel then
    love.graphics.setColor(1, 1, 1, self.fadeLevel / 3)
    love.graphics.rectangle("fill", 0, 0, 160, 144)
    love.graphics.setColor(1, 1, 1, 1)
  end
end

return OakSpeech
