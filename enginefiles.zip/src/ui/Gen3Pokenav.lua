-- Copyright (c) 2026 Cedric. All rights reserved.
-- Source-available under the Gen2Recomped License (see LICENSE.md): you may
-- read, build and privately modify this file; you may not redistribute it or
-- use it commercially. Cartridge-derived data is excluded and is not the
-- copyright holder's to license.

-- THE POKéNAV.
--
-- The one row on the START menu that opened nothing.  Its flag was read
-- correctly and the row appeared exactly when the cartridge shows it; behind
-- it there was no screen at all.
--
-- FOUR THINGS IT DOES, and the gating between them is the cartridge's:
--
--   MAP          the region map, with the zoom that only exists here.
--   CONDITION    the pentagon -- PARTY, or SEARCH the boxes by a category.
--   MATCH CALL   who is registered, and who wants a rematch.
--   RIBBONS      thirty-two kinds in a nine-by-four grid.
--
-- GetPokenavMainMenuType (0x081C9268) is three lines: MAP, CONDITION and
-- SWITCH OFF always; MATCH CALL on flag $130; RIBBONS on $130 AND $89B.  The
-- cartridge really does make RIBBONS depend on MATCH CALL -- its menu type 2
-- is only reachable through type 1 -- and RIBBONS is gated a SECOND time when
-- you press A: with no ribbon anywhere in the party or the boxes it refuses
-- with a line rather than opening an empty grid.
--
-- THE ROW LABELS ARE ART, NOT TEXT.  There are no MAP / CONDITION / MATCH
-- CALL strings anywhere in the cartridge: the five rows are thirteen 128x16
-- buttons in one compressed sprite sheet, four sprites each, and the import
-- composes them into a strip.  The only words on the menu are the one-line
-- description underneath, and those ARE strings -- fourteen of them, one per
-- selectable row, which is why this screen can say what every row does
-- without inventing a single sentence.

local Assets = require("src.render.Assets")
local Boxes = require("src.pokemon.Boxes")
local Contest = require("src.pokemon.Contest")
local Font = require("src.render.Font")
local Logger = require("src.core.Logger")
local MatchCall = require("src.script.MatchCall")
local Screens = require("src.ui.Screens")
local Sound = require("src.core.Sound")
local Strings = require("src.core.Strings")
local Theme = require("src.ui.Theme")

local Gen3Pokenav = {}
Gen3Pokenav.__index = Gen3Pokenav
Gen3Pokenav.isOpaque = true

local GBA_W, GBA_H = 240, 160

-- MEASURED OFF THE BAKED MENU PICTURE: where the cartridge's own message box
-- is, so the description goes inside it instead of under a second box.
local MESSAGE = { x = 23, y = 136, w = 194, h = 16 }

-- WHICH PICTURE EACH MODE SITS ON.
--
-- The POKeNAV has one background per screen and they are the cartridge's, not
-- drawn boxes: RomExtractorGen3.POKENAV.SCREENS says how each was found and
-- which handler it belongs to.  CONDITION's list and its graph share a screen
-- because the cartridge draws the pentagon into the same panel the list uses.
local SCREEN_FOR_MODE = {
  menu = "menu",
  conditionList = "condition",
  conditionDetail = "condition",
  ribbonList = "ribbonList",
  ribbonGrid = "ribbons",
  matchCall = "matchCall",
}

-- MEASURED OFF THOSE BAKES: the list panel is the same rectangle on all three
-- list screens, and it is the hardware BACKDROP showing through -- black -- so
-- what is printed in it is printed in the cartridge's own list text colour,
-- which is white (the text palette the list loads into bank 15, 0623208, is
-- black, white, grey).  Everything to the left of the panel sits on a light
-- field and stays dark.
local LIST = { x = 104, y = 8, w = 136, h = 128 }
-- inside that panel: the cursor column, then the name, then a right margin the
-- counts are right-aligned against
local LIST_CURSOR, LIST_TEXT, LIST_RIGHT = 2, 14, 16

-- The row ids sMenuItems holds, named.  0..4 are the main menu, 5..7 the
-- CONDITION submenu, 8..13 the SEARCH one.
local ROW = {
  MAP = 0, CONDITION = 1, MATCH_CALL = 2, RIBBONS = 3, SWITCH_OFF = 4,
  COND_PARTY = 5, COND_SEARCH = 6, COND_CANCEL = 7,
  SEARCH_COOL = 8, SEARCH_CANCEL = 13,
}

-- Used only when the cache predates the POKéNAV stage: the same five rows,
-- the same three menus, drawn as words instead of the cartridge's buttons.
local FALLBACK = {
  menus = {
    { highlightY = 42, highlightStep = 20, rows = { 0, 1, 4 } },
    { highlightY = 42, highlightStep = 20, rows = { 0, 1, 2, 4 } },
    { highlightY = 42, highlightStep = 20, rows = { 0, 1, 2, 3, 4 } },
    { highlightY = 56, highlightStep = 20, rows = { 5, 6, 7 } },
    { highlightY = 40, highlightStep = 16, rows = { 8, 9, 10, 11, 12, 13 } },
  },
  labels = {
    [0] = "MAP", [1] = "CONDITION", [2] = "MATCH CALL", [3] = "RIBBONS",
    [4] = "SWITCH OFF", [5] = "PARTY", [6] = "SEARCH", [7] = "CANCEL",
    [8] = "COOL", [9] = "BEAUTY", [10] = "CUTE", [11] = "SMART",
    [12] = "TOUGH", [13] = "CANCEL",
  },
  flags = { matchCall = 0x130, ribbons = 0x89B, has = 0x862 },
}

local function flagKey(n)
  return require("src.script.Gen3Commands").flagKey(n)
end

function Gen3Pokenav:uiSize() return GBA_W, GBA_H end
function Gen3Pokenav:wantsFillScale() return true end

function Gen3Pokenav:sgbPalettes()
  local P = require("src.render.PaletteFX")
  return { P.trueColorZone(0, 0, math.ceil(GBA_W / 8) - 1,
                           math.ceil(GBA_H / 8) - 1) }
end

function Gen3Pokenav:record()
  local r = (self.game.data.constants or {}).gen3Pokenav
  if type(r) ~= "table" or type(r.menus) ~= "table" then return nil end
  return r
end

function Gen3Pokenav:menus()
  local r = self:record()
  return (r and r.menus) or FALLBACK.menus
end

function Gen3Pokenav:describe(rowId)
  local r = self:record()
  local d = r and r.descriptions and r.descriptions[rowId]
  return d
end

function Gen3Pokenav:label(rowId)
  return FALLBACK.labels[rowId] or ""
end

-- ---------------------------------------------------------------------------
-- WHICH MENU, and what is on it
-- ---------------------------------------------------------------------------
function Gen3Pokenav:mainMenuType()
  local r = self:record()
  local flags = (r and r.flags) or FALLBACK.flags
  local set = self.game.save.flags or {}
  if set[flagKey(flags.matchCall)] ~= true then return 0 end
  if set[flagKey(flags.ribbons)] ~= true then return 1 end
  return 2
end

-- HasAnyRibbons: the party and every box, and it is asked ONCE when the
-- POKéNAV opens rather than every frame, which is also when the cartridge
-- asks it.
function Gen3Pokenav:anyRibbons()
  for _, mon in ipairs(self.game.save.party or {}) do
    if Contest.ribbonCount(mon) > 0 then return true end
  end
  local boxes = (self.game.save or {}).boxes
  for _, box in pairs(boxes or {}) do
    for _, mon in pairs(box.mons or box) do
      if type(mon) == "table" and Contest.ribbonCount(mon) > 0 then
        return true
      end
    end
  end
  return false
end

function Gen3Pokenav.new(game, opts)
  local self = setmetatable({}, Gen3Pokenav)
  self.game = game
  self.opts = opts or {}
  self.onCancel = self.opts.onCancel
  self.mode = "menu"
  self.menuType = self:mainMenuType()
  self.cursor = 1
  self.hasRibbons = self:anyRibbons()
  self.notice = nil
  self.blink = 0
  return self
end

function Gen3Pokenav:menu()
  return self:menus()[self.menuType + 1] or FALLBACK.menus[1]
end

function Gen3Pokenav:rowId()
  local m = self:menu()
  return m.rows[self.cursor] or m.rows[1]
end

function Gen3Pokenav:close()
  if self.game.stack then self.game.stack:pop() end
  if self.onCancel then self.onCancel() end
end

-- ---------------------------------------------------------------------------
-- CHOOSING
-- ---------------------------------------------------------------------------
function Gen3Pokenav:choose()
  local id = self:rowId()
  local game = self.game
  Sound.play(game.data, "Press_AB")

  if id == ROW.MAP then
    Screens.push(game, "Gen3RegionMap", { zoom = true })
  elseif id == ROW.CONDITION then
    self.menuType, self.cursor = 3, 1
  elseif id == ROW.MATCH_CALL then
    self:openMatchCall()
  elseif id == ROW.RIBBONS then
    -- THE SECOND GATE.  The row is on the menu because the ribbon FLAG is
    -- set; whether it opens is a different question, and the cartridge
    -- answers it with a line rather than an empty grid.
    if not self.hasRibbons then
      Sound.play(game.data, "Wrong")
      self.notice = Strings("There are no RIBBON winners.")
      self.noticePage = 1
      return
    end
    self:openList("ribbons")
  elseif id == ROW.SWITCH_OFF then
    return self:close()
  elseif id == ROW.COND_PARTY then
    self:openList("condition")
  elseif id == ROW.COND_SEARCH then
    self.menuType, self.cursor = 4, 1
  elseif id == ROW.COND_CANCEL then
    self.menuType, self.cursor = self:mainMenuType(), 2
  elseif id == ROW.SEARCH_CANCEL then
    self.menuType, self.cursor = 3, 2
  elseif id >= ROW.SEARCH_COOL and id < ROW.SEARCH_CANCEL then
    self.searchCategory = Contest.ORDER[id - ROW.SEARCH_COOL + 1]
    self:openList("condition")
  end
end

function Gen3Pokenav:back()
  Sound.play(self.game.data, "Press_AB")
  if self.notice then
    -- A TURNS THE PAGE FIRST.  Dismissing on the first A is what made a long
    -- match call show its opening line and nothing else.
    if self:noticeAdvance() then return end
    self.notice = nil
    return
  end
  if self.mode ~= "menu" then
    self.mode = "menu"
    return
  end
  if self.menuType == 3 then
    self.menuType, self.cursor = self:mainMenuType(), 2
  elseif self.menuType == 4 then
    self.menuType, self.cursor = 3, 2
  else
    self:close()
  end
end

-- ---------------------------------------------------------------------------
-- THE MON LIST, shared by CONDITION and RIBBONS
--
-- CONDITION▸PARTY walks the party; CONDITION▸SEARCH walks the party AND every
-- box, ordered by the category you picked, which is what "find cool POKéMON"
-- means.  RIBBONS walks everything that has one.
-- ---------------------------------------------------------------------------
local function boxMons(save)
  local out = {}
  for name, box in pairs((save or {}).boxes or {}) do
    local list = box.mons or box
    for slot, mon in pairs(list) do
      if type(mon) == "table" and mon.species then
        out[#out + 1] = { mon = mon, where = name, slot = slot }
      end
    end
  end
  return out
end

function Gen3Pokenav:openList(kind)
  local save = self.game.save
  local rows = {}
  if kind == "condition" and self.searchCategory then
    for i, mon in ipairs(save.party or {}) do
      rows[#rows + 1] = { mon = mon, where = "party", slot = i }
    end
    for _, row in ipairs(boxMons(save)) do rows[#rows + 1] = row end
    local cat = self.searchCategory
    table.sort(rows, function(a, b)
      return Contest.graph(a.mon, cat) > Contest.graph(b.mon, cat)
    end)
  elseif kind == "condition" then
    for i, mon in ipairs(save.party or {}) do
      rows[#rows + 1] = { mon = mon, where = "party", slot = i }
    end
  else
    for i, mon in ipairs(save.party or {}) do
      if Contest.ribbonCount(mon) > 0 then
        rows[#rows + 1] = { mon = mon, where = "party", slot = i }
      end
    end
    for _, row in ipairs(boxMons(save)) do
      if Contest.ribbonCount(row.mon) > 0 then rows[#rows + 1] = row end
    end
  end
  if #rows == 0 then
    Sound.play(self.game.data, "Wrong")
    self.notice = Strings("There are no POKéMON to check.")
    self.noticePage = 1
    return
  end
  self.mode = kind == "ribbons" and "ribbonList" or "conditionList"
  self.rows = rows
  self.listIndex = 1
  self.listTop = 1
end

function Gen3Pokenav:selectedMon()
  local row = self.rows and self.rows[self.listIndex]
  return row and row.mon or nil
end

-- ---------------------------------------------------------------------------
-- MATCH CALL
-- ---------------------------------------------------------------------------
function Gen3Pokenav:openMatchCall()
  local entries = MatchCall.list(self.game.data, self.game.save)
  self.mode = "matchCall"
  self.calls = entries
  self.callIndex = 1
  self.callTop = 1
  self.callMenu = nil
end

function Gen3Pokenav:callName(entry)
  if not entry then return "" end
  if entry.name then return entry.name end
  -- A header with no name of its own names a rematch ROW instead, and the name
  -- on it is that row's first trainer's.  The lookup lives in MatchCall
  -- because the rematch table holds trainer INDICES and the trainers module is
  -- keyed by slug -- indexing it with the number found nothing and left every
  -- Gym Leader on this screen reading as the fallback word.
  local row = entry.rematch
               and MatchCall.rematchRows(self.game.data)[entry.rematch + 1]
  local trainer = row and MatchCall.trainer(self.game.data, row.trainers[1])
  return (trainer and trainer.name) or Strings("TRAINER")
end

function Gen3Pokenav:callWhere(entry)
  local sections = (self.game.data.constants or {}).gen3MapSections
  local sec = entry and entry.mapSec
  if sec and sections and sections[sec] then return sections[sec] end
  local row = entry and entry.rematch
               and MatchCall.rematchRows(self.game.data)[entry.rematch + 1]
  local def = row and (self.game.data.maps or {})[row.map]
  local id = def and tonumber(def.regionMapSection)
  if id and sections and sections[id] then return sections[id] end
  return Strings("UNKNOWN")
end

-- ---------------------------------------------------------------------------
-- INPUT
-- ---------------------------------------------------------------------------
local function listMove(self, field, topField, delta, rows, visible)
  local n = #rows
  if n == 0 then return end
  self[field] = (self[field] - 1 + delta) % n + 1
  if self[field] < self[topField] then self[topField] = self[field] end
  if self[field] > self[topField] + visible - 1 then
    self[topField] = self[field] - visible + 1
  end
end

Gen3Pokenav.LIST_ROWS = 8

function Gen3Pokenav:update()
  self.blink = (self.blink + 1) % 60
  local input = self.game.input
  if not input then return end

  if self.notice then
    if input:wasPressed("a") or input:wasPressed("b") then
      Sound.play(self.game.data, "Press_AB")
      -- A TURNS THE PAGE.  Reported from play: "when calling someone with the
      -- pokenav it only shows their first line of text doesnt go through
      -- their whole dialogue".
      --
      -- The paging is written and it was unreachable.  noticeAdvance lives in
      -- back(), which is the B handler -- and this branch sits ABOVE the line
      -- that calls back(), and returns.  So every press, A or B, landed here
      -- and cleared the whole notice, and a match call that the cartridge
      -- spreads over three or four boxes showed its first box and stopped.
      if not self:noticeAdvance() then self.notice = nil end
    end
    return
  end

  if input:wasPressed("b") then return self:back() end

  if self.mode == "menu" then
    local m = self:menu()
    if input:wasPressed("down") then
      self.cursor = self.cursor % #m.rows + 1
      Sound.play(self.game.data, "Press_AB")
    elseif input:wasPressed("up") then
      self.cursor = (self.cursor - 2) % #m.rows + 1
      Sound.play(self.game.data, "Press_AB")
    elseif input:wasPressed("a") then
      self:choose()
    end
    return
  end

  if self.mode == "conditionList" or self.mode == "ribbonList" then
    if input:wasPressed("down") then
      listMove(self, "listIndex", "listTop", 1, self.rows, Gen3Pokenav.LIST_ROWS)
    elseif input:wasPressed("up") then
      listMove(self, "listIndex", "listTop", -1, self.rows, Gen3Pokenav.LIST_ROWS)
    elseif input:wasPressed("a") then
      Sound.play(self.game.data, "Press_AB")
      self.mode = (self.mode == "ribbonList") and "ribbonGrid" or "conditionDetail"
      self.ribbonIndex = 1
    end
    return
  end

  if self.mode == "conditionDetail" then
    if input:wasPressed("down") then
      listMove(self, "listIndex", "listTop", 1, self.rows, Gen3Pokenav.LIST_ROWS)
    elseif input:wasPressed("up") then
      listMove(self, "listIndex", "listTop", -1, self.rows, Gen3Pokenav.LIST_ROWS)
    end
    return
  end

  if self.mode == "ribbonGrid" then
    local ids = Contest.ribbonIds(self:selectedMon())
    if #ids > 0 then
      if input:wasPressed("right") then
        self.ribbonIndex = self.ribbonIndex % #ids + 1
      elseif input:wasPressed("left") then
        self.ribbonIndex = (self.ribbonIndex - 2) % #ids + 1
      end
    end
    return
  end

  if self.mode == "matchCall" then
    if self.callMenu then
      if input:wasPressed("down") then
        self.callMenu = self.callMenu % 3 + 1
      elseif input:wasPressed("up") then
        self.callMenu = (self.callMenu - 2) % 3 + 1
      elseif input:wasPressed("a") then
        return self:callAction()
      end
      return
    end
    if input:wasPressed("down") then
      listMove(self, "callIndex", "callTop", 1, self.calls, Gen3Pokenav.LIST_ROWS)
    elseif input:wasPressed("up") then
      listMove(self, "callIndex", "callTop", -1, self.calls, Gen3Pokenav.LIST_ROWS)
    elseif input:wasPressed("a") then
      Sound.play(self.game.data, "Press_AB")
      self.callMenu = 1
    end
    return
  end
end

-- CALL / CHECK / CANCEL.
function Gen3Pokenav:callAction()
  local entry = self.calls and self.calls[self.callIndex]
  local game = self.game
  Sound.play(game.data, "Press_AB")
  if self.callMenu == 3 or not entry then
    self.callMenu = nil
    return
  end
  if self.callMenu == 1 then
    -- THE CALL.  SelectMatchCallMessage walks the trainer's own lines
    -- backwards and takes the highest whose gate flag is set, then sets
    -- whatever that line says to set -- which is how MR. STONE's opening
    -- line unlocks his second one.
    -- WHERE YOU ARE STANDING CHANGES WHAT THEY SAY: a registered trainer on
    -- your own route asks whether you are near them, and one anywhere else
    -- talks about their battles instead.  MatchCall cannot see the overworld,
    -- so the screen hands it the map.
    local ow = game.overworld
    local here = ow and ow.map and ow.map.id or nil
    local text = MatchCall.message(game.data, game.save, entry, { here = here })
    if not text and MatchCall.entryReady(game.data, game.save, entry) then
      text = Strings("%s wants to battle again!", self:callName(entry))
    end
    self.notice = text or Strings("%s is not answering.", self:callName(entry))
    self.noticePage = 1
  else
    local ready = MatchCall.entryReady(game.data, game.save, entry)
    local lines = {
      self:callName(entry),
      entry.row and entry.row.description or entry.className or "",
      self:callWhere(entry),
      ready and Strings("Wants a rematch!") or "",
    }
    self.notice = table.concat(lines, "\n")
    self.noticePage = 1
  end
  self.callMenu = nil
end

function Gen3Pokenav:keypressed(key)
  if key == "b" then return self:back() end
  if key == "a" and self.mode == "menu" then return self:choose() end
end

-- ---------------------------------------------------------------------------
-- DRAWING
-- ---------------------------------------------------------------------------
local warned = false
function Gen3Pokenav:art(which)
  local r = self:record()
  local path = r and r.images and r.images[which]
  if type(path) ~= "string" then
    if not warned and which == "menu" then
      warned = true
      Logger.warn("gen3 pokenav: this cache carries no POKeNAV art -- "
                    .. "re-import to get the cartridge's own screen")
    end
    return nil
  end
  local ok, img = pcall(Assets.image, path)
  return ok and img or nil
end

-- The picture this mode sits on, or the menu's where a mode has none.
function Gen3Pokenav:screenArt()
  return self:art(SCREEN_FOR_MODE[self.mode] or "menu")
end

-- White inside the list panel, black outside it.
function Gen3Pokenav:listInk()
  if self:screenArt() then
    love.graphics.setColor(1, 1, 1, 1)
  else
    love.graphics.setColor(0, 0, 0, 1)
  end
end

function Gen3Pokenav:drawBackground()
  -- No fallback to the menu's picture for a mode that has none of its own:
  -- an old cache would then show the menu behind a MATCH CALL list.  A mode
  -- with no picture gets the flat field and draws its own boxes, which is
  -- what every screen did before the art was derived.
  local field = self:screenArt()
  if field then
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(field, 0, 0)
  else
    love.graphics.setColor(0.16, 0.22, 0.36, 1)
    love.graphics.rectangle("fill", 0, 0, GBA_W, GBA_H)
    love.graphics.setColor(1, 1, 1, 1)
  end
end

-- The button strip, one 128x16 row per icon id.
function Gen3Pokenav:drawButton(rowId, x, y, selected)
  local r = self:record()
  local strip = self:art("buttons")
  local size = (r and r.button) or { width = 128, height = 16 }
  if strip then
    local iw, ih = strip:getDimensions()
    local quad = love.graphics.newQuad(0, rowId * size.height,
                                       size.width, size.height, iw, ih)
    love.graphics.setColor(1, 1, 1, selected and 1 or 0.72)
    love.graphics.draw(strip, quad, x, y)
    love.graphics.setColor(1, 1, 1, 1)
  else
    love.graphics.setColor(selected and 0.98 or 0.55, selected and 0.90 or 0.58,
                           selected and 0.40 or 0.62, 1)
    love.graphics.rectangle("fill", x, y, size.width, size.height)
    love.graphics.setColor(0, 0, 0, 1)
    Font.draw(self:label(rowId), x + 6, y + 4)
    love.graphics.setColor(1, 1, 1, 1)
  end
end

function Gen3Pokenav:drawMenu()
  local m = self:menu()
  -- the highlight band's own geometry: the cartridge fills sixteen scanlines
  -- starting eight above `highlightY + step * cursor`, and the buttons are
  -- 128 wide against the right edge of a 240 screen
  local x = GBA_W - 128 - 8
  for i, rowId in ipairs(m.rows) do
    local y = (m.highlightY or 42) + (m.highlightStep or 20) * (i - 1) - 8
    self:drawButton(rowId, x, y, i == self.cursor)
  end
  -- THE DESCRIPTION SITS IN THE BOX THE PICTURE ALREADY HAS.
  --
  -- The menu background is the cartridge's own three backgrounds composed
  -- (RomExtractorGen3.bgLayer), and the frontmost of them IS the message box
  -- across the bottom -- so drawing the engine's own box over it stacked two
  -- boxes of different widths on top of each other.  Measured off the bake,
  -- the cartridge's box runs x=23..216 and y=136..151; an eight-pixel line
  -- centred in it sits at 140.
  local text = self:describe(self:rowId()) or self:label(self:rowId())
  love.graphics.setColor(1, 1, 1, 1)
  local x, y
  if self:art("menu") then
    x = MESSAGE.x + math.floor((MESSAGE.w - Font.width(text)) / 2)
    y = MESSAGE.y + math.floor((MESSAGE.h - Font.glyphHeight()) / 2)
    x = math.max(MESSAGE.x, x)
  else
    Font.drawBox(0, 17, 30, 3)
    x = math.max(4, math.floor((GBA_W - Font.width(text)) / 2))
    y = 142
  end
  love.graphics.setColor(0, 0, 0, 1)
  Font.draw(text, x, y)
  love.graphics.setColor(1, 1, 1, 1)
end

local function monName(game, row)
  local mon = row and row.mon
  if not mon then return "" end
  local def = (game.data.pokemon or {})[mon.species]
  return mon.nickname or (def and def.name) or tostring(mon.species)
end

function Gen3Pokenav:drawMonList()
  love.graphics.setColor(1, 1, 1, 1)
  if not self:screenArt() then Font.drawBox(11, 0, 19, 17) end
  self:listInk()
  local cat = self.searchCategory
  for i = 0, Gen3Pokenav.LIST_ROWS - 1 do
    local row = self.rows[self.listTop + i]
    if not row then break end
    local y = LIST.y + i * 16 + 4
    Font.draw(monName(self.game, row), LIST.x + LIST_TEXT, y)
    local right = LIST.x + LIST.w - LIST_RIGHT
    if cat then
      local v = tostring(Contest.graph(row.mon, cat))
      Font.draw(v, right - Font.width(v), y)
    elseif self.mode == "ribbonList" then
      local v = tostring(Contest.ribbonCount(row.mon))
      Font.draw(v, right - Font.width(v), y)
    end
    if self.listTop + i == self.listIndex then
      Font.drawCode(Theme.cursor, LIST.x + LIST_CURSOR, y)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
end

-- THE PENTAGON.  Five vertices about (155, 91), each pushed out by a radius
-- that is looked up rather than scaled: the cartridge's table is deliberately
-- non-linear, 4 at zero and 35 at 255, with most of its resolution spent
-- under sixty -- so a Pokémon that has eaten a couple of Pokéblocks shows a
-- visible bump instead of nothing.
function Gen3Pokenav:drawCondition()
  local r = self:record()
  local cond = r and r.condition
  local mon = self:selectedMon()
  local pts = Contest.vertices(mon, cond)
  local centre = (cond and cond.centre) or { x = 155, y = 91 }

  love.graphics.setColor(0.10, 0.14, 0.24, 0.85)
  love.graphics.circle("fill", centre.x, centre.y, 42)

  -- THE FRAME, and the five directions it is built from.
  --
  -- These are kept rather than thrown away because the CATEGORY WORDS hang
  -- off them.  They used to hang off the DATA vertices instead, and that is
  -- the bug that was on screen: a Pokemon whose conditions are all zero has
  -- all five data vertices at the centre, so all five words were drawn on top
  -- of each other in a heap -- TOUGH over SMART, BEAUTY over CUTE.  Which is
  -- every Pokemon that has never eaten a POKeBLOCK, so it is what the screen
  -- looked like for most of a playthrough.
  --
  -- On the cartridge the five words are ART at fixed places around the
  -- pentagon.  They do not move with the data and neither do these.
  love.graphics.setColor(0.42, 0.48, 0.60, 1)
  local outer, frame = {}, {}
  local full = Contest.radius(cond, Contest.MAX)
  local dirs = Contest.directions(cond)
  for i in ipairs(Contest.ORDER) do
    local cos, sin = dirs[i].cos, dirs[i].sin
    local x = centre.x + cos * full / 256
    local y = centre.y - sin * full / 256
    outer[#outer + 1] = x
    outer[#outer + 1] = y
    frame[i] = { x = x, y = y, cos = cos / 256, sin = sin / 256 }
  end
  love.graphics.polygon("line", outer)

  local poly = {}
  for _, p in ipairs(pts) do poly[#poly + 1] = p.x; poly[#poly + 1] = p.y end
  love.graphics.setColor(0.98, 0.78, 0.30, 0.75)
  if #poly >= 6 then love.graphics.polygon("fill", poly) end
  love.graphics.setColor(1, 0.94, 0.62, 1)
  if #poly >= 6 then love.graphics.polygon("line", poly) end

  -- THE NAME AND THE SHEEN, on the cartridge's own left-hand field rather
  -- than under a box drawn over it: the picture keeps that side clear down to
  -- y=38 and then puts a small panel at (7,46) 58x19, which is where SHEEN
  -- goes -- it is the one line short enough to sit in it.
  local sheen = Contest.sheenLevel(mon, cond)
  local name = monName(self.game, self.rows[self.listIndex])
  if self:screenArt() then
    love.graphics.setColor(0, 0, 0, 1)
    Font.draw(name, 8, 14)
    Font.draw(Strings("SHEEN %d", sheen), 11, 52)
  else
    love.graphics.setColor(1, 1, 1, 1)
    Font.drawBox(0, 0, 12, 5)
    love.graphics.setColor(0, 0, 0, 1)
    Font.draw(name, 6, 8)
    Font.draw(Strings("SHEEN %d", sheen), 6, 24)
  end
  love.graphics.setColor(1, 1, 1, 1)

  -- AND WHAT EACH DIRECTION IS, placed off the FRAME and not off the data.
  --
  -- Each word sits just outside its own corner, pushed along that corner's
  -- own direction so it clears the pentagon's line, and then clamped to the
  -- screen -- the top corner is centred over itself, the two on the right run
  -- rightwards and the two on the left run leftwards, which is how the
  -- cartridge lays them out.
  local PAD = 5
  love.graphics.setColor(1, 1, 1, 1)
  for i, key in ipairs(Contest.ORDER) do
    local p = frame[i]
    local word = key:upper()
    local w = Font.width(word)
    if p then
      local lx = p.x + p.cos * PAD
      -- how far the corner leans left or right decides which edge of the word
      -- is anchored to it; a corner that leans neither way is centred
      if p.cos > 0.25 then lx = lx + 2
      elseif p.cos < -0.25 then lx = lx - w - 2
      else lx = lx - w / 2 end
      local ly = p.y - p.sin * PAD - Font.glyphHeight() / 2
      if p.sin > 0.25 then ly = ly - 2
      elseif p.sin < -0.25 then ly = ly + 2 end
      Font.draw(word,
                math.max(0, math.min(GBA_W - w, math.floor(lx + 0.5))),
                math.max(0, math.min(GBA_H - Font.glyphHeight(),
                                     math.floor(ly + 0.5))))
    end
  end
end

function Gen3Pokenav:drawRibbons()
  local r = self:record()
  local grid = (r and r.ribbons and r.ribbons.grid)
               or { cols = 9, x = 88, y = 32, step = 16, giftSlot = 27 }
  local mon = self:selectedMon()
  local ids = Contest.ribbonIds(mon)
  local art = self:screenArt()
  love.graphics.setColor(1, 1, 1, 1)
  if not art then Font.drawBox(0, 0, 30, 3) end
  love.graphics.setColor(0, 0, 0, 1)
  -- the title box the picture already has: x=103..216, y=8..23
  Font.draw(Strings("RIBBONS %d", #ids), art and 108 or 6, art and 12 or 6)
  love.graphics.setColor(1, 1, 1, 1)

  for i, id in ipairs(ids) do
    -- the seven gift ribbons always start on the fourth row, whatever came
    -- before them
    local slot = (id >= 25) and (grid.giftSlot + (id - 25)) or (i - 1)
    local col = slot % grid.cols
    local row = math.floor(slot / grid.cols)
    local x = grid.x + col * grid.step
    local y = grid.y + row * grid.step
    love.graphics.setColor(0.92, 0.84, 0.34, 1)
    love.graphics.rectangle("fill", x + 1, y + 1, grid.step - 2, grid.step - 2)
    if i == self.ribbonIndex then
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.rectangle("line", x, y, grid.step, grid.step)
    end
  end

  local chosen = ids[self.ribbonIndex]
  local text = r and r.ribbons and r.ribbons.text and chosen
               and r.ribbons.text[chosen]
  love.graphics.setColor(1, 1, 1, 1)
  if not art then Font.drawBox(0, 16, 30, 4) end
  love.graphics.setColor(0, 0, 0, 1)
  if text then
    -- the description box the picture already has: x=95..224, y=104..135
    local tx = art and 100 or 8
    local ty = art and 108 or 134
    Font.draw(text[1] or "", tx, ty)
    Font.draw(text[2] or "", tx, ty + 14)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

-- WHO YOU ARE LOOKING AT, which this screen never showed.
--
-- Reported from play: "the menu seems like it doesnt match the roms menu for
-- selecting someone to call".  The cartridge's MATCH CALL page is a CARD: the
-- contact's picture on the left with their trainer class written under it,
-- and the list of names on the right.  This drew the list and left the whole
-- upper-left quarter of the screen empty, so the only thing on it that said
-- who the highlighted row was, was the row itself.
--
-- The pictures are already in the cache -- they are the same trainer pics a
-- battle puts up, resolved through BattleState.trainerPicPath -- so this is a
-- lookup rather than new art, and a contact whose row names no trainer (a
-- header with a tagline and nothing behind it) simply gets no portrait rather
-- than a placeholder.
function Gen3Pokenav:callTrainer(entry)
  if not entry then return nil end
  local data = self.game.data
  local row = entry.rematch
              and MatchCall.rematchRows(data)[entry.rematch + 1]
  local index = row and row.trainers and row.trainers[1]
  return index and MatchCall.trainer(data, index) or nil
end

Gen3Pokenav.PORTRAIT = { tx = 0, ty = 0, tw = 11, th = 5 }

function Gen3Pokenav:drawCallPortrait(entry)
  local P = Gen3Pokenav.PORTRAIT
  love.graphics.setColor(1, 1, 1, 1)
  Font.drawBox(P.tx, P.ty, P.tw, P.th)
  local trainer = self:callTrainer(entry)
  local path = trainer and require("src.battle.BattleState")
                 .trainerPicPath(self.game.data, trainer)
  local img
  if type(path) == "string" then
    local ok, loaded = pcall(Assets.image, path)
    img = ok and loaded or nil
  end
  local boxX, boxY = (P.tx + 1) * 8, (P.ty + 1) * 8
  local boxW, boxH = (P.tw - 2) * 8, (P.th - 2) * 8
  if img then
    local iw, ih = img:getDimensions()
    -- never enlarged: a pic that already fits is drawn at its own size, which
    -- is how the cartridge shows it
    local scale = math.min(1, boxW / iw, boxH / ih)
    local x = math.floor(boxX + (boxW - iw * scale) / 2)
    local y = math.floor(boxY + (boxH - ih * scale) / 2)
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.draw(img, x, y, 0, scale, scale)
    require("src.render.PaletteFX").markTrueColor(
      x, y, math.ceil(iw * scale), math.ceil(ih * scale))
  end
  -- the class, which is the line the cartridge writes under the picture
  local class = (entry and entry.className)
                or (trainer and (trainer.class or trainer.trainerClass))
  if type(class) == "string" and class ~= "" then
    love.graphics.setColor(0, 0, 0, 1)
    local w = Font.width(class)
    Font.draw(class, math.floor(boxX + (boxW - w) / 2),
              boxY + boxH - Font.glyphHeight())
  end
  love.graphics.setColor(1, 1, 1, 1)
end

function Gen3Pokenav:drawMatchCall()
  love.graphics.setColor(1, 1, 1, 1)
  local art = self:screenArt()
  if not art then
    Font.drawBox(11, 0, 19, 17)
    Font.drawBox(0, 5, 11, 2)
    Font.drawBox(0, 9, 11, 8)
  end
  self:drawCallPortrait(self.calls and self.calls[self.callIndex])
  self:listInk()

  for i = 0, Gen3Pokenav.LIST_ROWS - 1 do
    local entry = self.calls[self.callTop + i]
    if not entry then break end
    local y = LIST.y + i * 16 + 4
    Font.draw(self:callName(entry), LIST.x + LIST_TEXT, y)
    -- "wants a rematch" is a marker at the far right of the row, which is
    -- where the cartridge puts its two-tile icon
    if MatchCall.entryReady(self.game.data, self.game.save, entry) then
      love.graphics.setColor(0.90, 0.30, 0.25, 1)
      love.graphics.rectangle("fill", LIST.x + LIST.w - 8, y + 2, 4, 10)
      self:listInk()
    end
    if self.callTop + i == self.callIndex then
      Font.drawCode(Theme.cursor, LIST.x + LIST_CURSOR, y)
    end
  end

  local entry = self.calls[self.callIndex]
  local where = self:callWhere(entry)
  love.graphics.setColor(0, 0, 0, 1)
  Font.draw(where, math.max(2, 88 - Font.width(where)), 46)

  if self.callMenu then
    for i, word in ipairs({ Strings("CALL"), Strings("CHECK"), Strings("CANCEL") }) do
      local y = 74 + (i - 1) * 16
      Font.draw(word, 16, y)
      if i == self.callMenu then Font.drawCode(Theme.cursor, 4, y) end
    end
  else
    Font.draw(Strings("No. registered"), 2, 74)
    local n = tostring(#self.calls)
    Font.draw(n, 86 - Font.width(n), 74)
    local ready = 0
    for _, e in ipairs(self.calls) do
      if MatchCall.entryReady(self.game.data, self.game.save, e) then
        ready = ready + 1
      end
    end
    Font.draw(Strings("Rematches"), 2, 90)
    local m = tostring(ready)
    Font.draw(m, 86 - Font.width(m), 90)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

function Gen3Pokenav:draw()
  self:drawBackground()
  if self.mode == "menu" then
    self:drawMenu()
  elseif self.mode == "conditionList" or self.mode == "ribbonList" then
    self:drawMonList()
  elseif self.mode == "conditionDetail" then
    self:drawCondition()
  elseif self.mode == "ribbonGrid" then
    self:drawRibbons()
  elseif self.mode == "matchCall" then
    self:drawMatchCall()
  end

  if self.notice then self:drawNotice() end
end

-- ---------------------------------------------------------------------------
-- THE MESSAGE BOX, WHICH WAS NOT A BOX.
--
-- Reported from play: "for the match call feature the text isnt fitting
-- properly and is going outside of the box and overlapping the border etc".
-- It was drawing whatever it was handed at a fixed x, splitting only on the
-- newlines already in the string and stepping down fourteen pixels a line
-- until it ran out of screen.  Two things came of that, and a MATCH CALL hit
-- both at once:
--
--   * A LINE TOO WIDE RAN OFF THE RIGHT EDGE.  Match call lines carry their
--     own breaks, but the port splices the player's name into them -- and a
--     seven-letter name is wider than the {PLAYER} it replaced, so lines that
--     fit on the cartridge do not fit here.  Nothing wrapped them.
--   * A LINE TOO MANY RAN THROUGH THE BOTTOM BORDER.  Three lines at fourteen
--     pixels from 120 reach 163 on a 160-pixel screen, so the third was drawn
--     through the frame and off the bottom.
--
-- So the box measures itself now.  The text is wrapped to the frame's own
-- inside width by the same paginator the field's text boxes use -- so a mod's
-- wider font wraps correctly too -- and what does not fit becomes another
-- PAGE rather than another line off the edge.  A more-to-come arrow sits
-- where the cartridge puts it and A turns over.
Gen3Pokenav.NOTICE = {
  tx = 0, ty = 14, tw = 30, th = 6,   -- the frame, in tiles
  padX = 8, padY = 8,                 -- inside it
  lineStep = 14,
}

-- ...AND THE NAME ACTUALLY GOES IN.
--
-- Reported from play, with a picture of MR. STONE's first call: it read
-- "MR. STONE: Oh? PLAYER  KUN !".  The line on the cartridge is
-- "Oh? {PLAYER}{KUN}!" -- the player's name and the honorific that is empty
-- in English -- and this screen paginated and drew it without ever expanding
-- either, so both tokens reached the box verbatim.  The braces are not in
-- this cartridge's font, which is why they came out as the gaps around them
-- rather than as braces.
--
-- Expanded HERE, above the wrap, and that ordering is the point: the note on
-- the box above says a seven-letter name is wider than the {PLAYER} it
-- replaces, so wrapping the token and then substituting would measure the
-- wrong string and put the overflow back.
function Gen3Pokenav:noticeLayout()
  local N = Gen3Pokenav.NOTICE
  local inner = N.tw * 8 - N.padX * 2
  local cols = math.max(1, math.floor(inner / 8))
  local TextBox = require("src.render.TextBox")
  local text = tostring(self.notice or "")
  local okSub, expanded = pcall(TextBox.substitute, self.game, text)
  if okSub and type(expanded) == "string" then text = expanded end
  local pages = TextBox.paginate(text, cols)
  -- how many lines actually fit between the frame's two borders
  local height = N.th * 8 - N.padY - 4
  local rows = math.max(1, math.floor(height / N.lineStep))
  -- ...and paginate wrapped to width, not to height, so a page longer than
  -- the box becomes several
  local out = {}
  for _, page in ipairs(pages) do
    for i = 1, #page, rows do
      local slice = {}
      for k = i, math.min(i + rows - 1, #page) do slice[#slice + 1] = page[k] end
      out[#out + 1] = slice
    end
  end
  if #out == 0 then out = { { "" } } end
  return out
end

-- A turns the page; the caller only clears the notice once the last one has
-- been read, which is what stops a long call vanishing after one screen.
function Gen3Pokenav:noticeAdvance()
  local pages = self:noticeLayout()
  local at = (self.noticePage or 1) + 1
  if at > #pages then
    self.noticePage = nil
    return false
  end
  self.noticePage = at
  return true
end

function Gen3Pokenav:drawNotice()
  local N = Gen3Pokenav.NOTICE
  local pages = self:noticeLayout()
  local page = pages[math.min(self.noticePage or 1, #pages)] or {}
  love.graphics.setColor(1, 1, 1, 1)
  Font.drawBox(N.tx, N.ty, N.tw, N.th)
  love.graphics.setColor(0, 0, 0, 1)
  local y = N.ty * 8 + N.padY
  for _, line in ipairs(page) do
    Font.draw(line, N.tx * 8 + N.padX, y)
    y = y + N.lineStep
  end
  -- there is more of this call to come
  if (self.noticePage or 1) < #pages then
    Font.drawCode(Theme.moreArrow or Theme.cursor,
                  (N.tx + N.tw) * 8 - 12, (N.ty + N.th) * 8 - 12)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

return Gen3Pokenav
