-- Gen 1 catch algorithm (engine/items/item_effects.asm, ItemUseBall).

local Status = require("src.battle.Status")

local Catching = {}

-- randMax is the ceiling of the catch roll, hpFactor the X of the HP term,
-- wobbleFactor the ballFactor2 divisor of the wobble math.  MASTER_BALL
-- never rolls (autoCatch), so its factors are unused.  tossAnim picks the
-- TossBallAnimation arc and flicker the Master/Ultra OBJ-palette strobe
-- (DoBallTossSpecialEffects).
local BALLS = {
  MASTER_BALL = { randMax = 0, autoCatch = true,
                  tossAnim = "ULTRATOSS_ANIM", flicker = true },
  POKE_BALL   = { randMax = 255, hpFactor = 12, wobbleFactor = 255,
                  tossAnim = "TOSS_ANIM" },
  GREAT_BALL  = { randMax = 200, hpFactor = 8,  wobbleFactor = 200,
                  tossAnim = "GREATTOSS_ANIM" },
  ULTRA_BALL  = { randMax = 150, hpFactor = 12, wobbleFactor = 150,
                  tossAnim = "ULTRATOSS_ANIM", flicker = true },
  SAFARI_BALL = { randMax = 150, hpFactor = 12, wobbleFactor = 150,
                  tossAnim = "ULTRATOSS_ANIM" },
  -- THE BUG CONTEST'S BALL, which had no record at all and fell through to
  -- DEFAULT_BALL -- so it rolled POKE_BALL's 255 against the contest's own
  -- rate and wobbled on a divisor no ball in the game actually uses.
  --
  -- Gen 2's Park Ball is Safari-shaped: it takes the same randMax/hpFactor
  -- path, and the contest's edge comes from ParkBallMultiplier (catch rate
  -- x1.5, saturating) applied BEFORE the roll -- BugContest.parkBallRate,
  -- which BattleState already calls. Giving it the Safari record leaves that
  -- multiplier as the only difference instead of stacking a silent second one.
  PARK_BALL   = { randMax = 150, hpFactor = 12, wobbleFactor = 150,
                  tossAnim = "ULTRATOSS_ANIM" },
}
Catching.BALLS = BALLS

-- an unknown ball falls back to POKE_BALL's roll and the 150 wobble
-- divisor, which is what the old per-field `or` defaults resolved to
local DEFAULT_BALL = { randMax = 255, hpFactor = 12, wobbleFactor = 150 }

-- ...AND HOENN'S TWELVE, WHICH ARE A DIFFERENT SUM.
--
-- Seven of Emerald's balls are not in the table above at all -- DIVE, LUXURY,
-- NEST, NET, PREMIER, REPEAT and TIMER -- so throwing one did nothing, and
-- the five that are ran Gen 1's arithmetic against Hoenn's catch rates.
-- Cmd_handleballthrow is a different shape (a multiplier, the HP, the status,
-- then two square roots), and Gen3Catching is that shape; extractBalls reads
-- every number in it off the cartridge.
--
-- Registered as ORDINARY BALL RECORDS carrying their own `attempt`, which is
-- the seam this file already has for exactly this: the battle code asks
-- Catching.attempt and never learns there are two formulas.  A mod that
-- overrides GREAT_BALL still overrides it, in Hoenn as in Johto.
local function registerGen3(registry, data, owner)
  local record = data and data.constants and data.constants.gen3Balls
  if type(record) ~= "table" or type(record.order) ~= "table" then
    return false
  end
  local Gen3Catching = require("src.battle.Gen3Catching")
  for _, id in ipairs(record.order) do
    -- REGISTER WHAT IS NEW, OVERRIDE WHAT IS NOT.
    --
    -- Reported from play as a boot crash: "balls already registered:
    -- MASTER_BALL".  A record registry refuses a duplicate outright -- that
    -- is the whole point of it, so a mod cannot silently shadow another
    -- pack's entry -- and five of Hoenn's twelve share a name with Gen 1's.
    -- The comment above always said these OVERRIDE the ones that share a
    -- name; `register` is simply not the call that does that.
    local write = registry:get(id) ~= nil and registry.override
                  or registry.register
    write(registry, id, {
      -- kept so a caller that reads a ball's fields rather than throwing it
      -- (the toss animation picks one, and Gen 1's wobble path is the
      -- fallback if `attempt` is ever removed) still finds sane numbers
      randMax = 255, hpFactor = 12, wobbleFactor = 150,
      autoCatch = (id == record.master) or nil,
      flicker = (id == record.master or id == record.order[2]) or nil,
      tossAnim = (id == record.master or id == record.order[2])
                 and "ULTRATOSS_ANIM" or "TOSS_ANIM",
      attempt = function(ctx)
        local mon, def = ctx.targetMon or {}, ctx.targetDef or {}
        local battle = ctx.battle
        local save = battle and battle.game and battle.game.save
        local dex = save and save.pokedex
        local owned = dex and dex.owned
        local ow = battle and battle.game and battle.game.overworld
        return Gen3Catching.attempt(record, id, {
          catchRate = ctx.rateOverride or def.catchRate,
          maxHP = (mon.stats and mon.stats.hp) or def.baseHP,
          hp = mon.hp,
          status = mon.status,
          level = mon.level,
          targetDef = def,
          turns = battle and battle.turnCount,
          alreadyCaught = (owned and mon.species
                           and owned[mon.species]) and true or false,
          -- the DIVE BALL asks the MAP, not the battle: the cartridge reads
          -- GetCurrentMapType and compares it against MAP_TYPE_UNDERWATER
          underwater = (ow and ow.map and ow.map.def
                        and ow.map.def.mapType == record.underwaterType)
                       or (ow and ow.diving) or false,
        }, ctx.rng)
      end,
    }, owner)
  end
  return true
end

function Catching.registerInto(registry, data, owner)
  for id, record in pairs(BALLS) do
    registry:register(id, record, owner)
  end
  -- Hoenn's override the ones that share a name and add the seven that had
  -- none, so this runs after the table above rather than instead of it
  registerGen3(registry, data, owner)
  -- ...AND SINNOH'S SIXTEEN, keyed by item number -- see src/battle/Gen4Catching.lua.
  local constants = data and data.constants
  if (data and data.isGen4Cache) or (type(constants) == "table" and constants.gen == 4) then
    require("src.battle.Gen4Catching").registerInto(registry, owner)
  end
end

-- The stock ItemUseBall math.  On failure the ball wobbles per the
-- original's shake calculation: Y = rate*100/ballFactor2 (255/200/150),
-- Z = X*Y/255 + status2 (5/10) where X is the HP factor; Z<10: 0 shakes,
-- <30: 1, <70: 2, else 3.  (We use the HP factor for X on both failure
-- paths; the original reads a stale quotient when the first roll fails.)
local function stockAttempt(def, targetMon, targetDef, rng, rateOverride, statuses)
  if def.autoCatch then return true, 3 end
  local randMax = def.randMax
  local rate = rateOverride or targetDef.catchRate

  -- the status subtraction and the wobble bonus come off the merged
  -- status record (SLP/FRZ 25 and +10, the rest 12 and +5)
  local s = targetMon.status
  local record = Status.recordFor(statuses, s)
  local statusBonus = record and record.catchBonus or 0

  -- HP factor (X)
  local maxhp = targetMon.stats.hp
  local hpQuarter = math.max(1, math.floor(targetMon.hp / 4))
  local factor = def.hpFactor or DEFAULT_BALL.hpFactor
  -- the 255 cap applies only after BOTH divisions (ItemUseBall keeps
  -- the intermediate in 16 bits); capping early collapses the value
  local f = math.min(255, math.floor(math.floor(maxhp * 255 / factor) / hpQuarter))

  local function shakes()
    local ballFactor2 = def.wobbleFactor or DEFAULT_BALL.wobbleFactor
    local y = math.floor(rate * 100 / ballFactor2)
    local z
    if y > 255 then
      z = 255
    else
      z = math.floor(f * y / 255)
    end
    if s then
      z = z + ((record and record.shakeBonus) or 5)
    end
    if z < 10 then return 0 elseif z < 30 then return 1
    elseif z < 70 then return 2 else return 3 end
  end

  local r = rng(0, randMax) - statusBonus
  if r < 0 then return true, 3 end
  if r > rate then return false, shakes() end
  if rng(0, 255) <= f then return true, 3 end
  return false, shakes()
end

-- Returns caught, shakes (0-3).  rateOverride replaces the species catch
-- rate (the Safari game's BAIT/ROCK-modified wEnemyMonActualCatchRate).
-- opts (all optional): ballDef = the merged ball record, statuses = the
-- merged statuses table, battle = the running battle.  A ball record's
-- attempt fn supersedes the whole formula; its ctx.vanillaAttempt() runs
-- the stock math with the ctx's (possibly rewritten) rateOverride.
function Catching.attempt(ball, targetMon, targetDef, rng, rateOverride, opts)
  rng = rng or love.math.random
  opts = opts or {}
  local def = opts.ballDef or BALLS[ball] or DEFAULT_BALL
  local statuses = opts.statuses
  if def.attempt then
    local ctx = {
      ballDef = def, targetMon = targetMon, targetDef = targetDef,
      rng = rng, rateOverride = rateOverride, battle = opts.battle,
    }
    ctx.vanillaAttempt = function()
      return stockAttempt(def, targetMon, targetDef, rng, ctx.rateOverride,
                          statuses)
    end
    return def.attempt(ctx)
  end
  return stockAttempt(def, targetMon, targetDef, rng, rateOverride, statuses)
end

return Catching
