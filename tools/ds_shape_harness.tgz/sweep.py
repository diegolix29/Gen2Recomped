# Run the audit over every exported map and rank the tilesets by the one
# defect that actually breaks a drawing: a cell whose four tiles carry
# different classes when one of them is a ROUND class (cylinder/planter/
# stump/canopy) -- such a cell cannot be carved as a single hull.
import os, json, subprocess, collections, sys
D = '/root/dsview'
ROUND = {'cylinder', 'canopy', 'stump', 'planter', 'can'}
# canopy pins only the 2x2 group's ANCHOR tile by design -- the other three
# tiles of that cell stay cylinder and the group build claims them, so a
# canopy+cylinder cell is the intended shape, not a broken one.
BENIGN = {frozenset(('canopy', 'cylinder'))}
maps = sorted(f[:-5] for f in os.listdir(D + '/data') if f.endswith('.json'))
per = collections.defaultdict(collections.Counter)
ex = {}
fails = []
for m in maps:
    r = subprocess.run(['luajit', 'harness.lua', m], cwd=D, capture_output=True, text=True)
    if r.returncode != 0:
        fails.append((m, r.stderr.strip().splitlines()[0] if r.stderr else '?')); continue
    ts = json.load(open('%s/data/%s.json' % (D, m)))['tileset']
    lines = open('%s/out_%s.txt' % (D, m)).read().splitlines()
    TW, TH = (int(v) for v in lines[0].split()[-1].split('x'))
    g = [[(c.split(':')[0], c.split(':')[1]) for c in ln.split()] for ln in lines[1:]]
    for cy in range(TH // 2):
        for cx in range(TW // 2):
            q = [g[cy*2+dy][cx*2+dx] for dy in (0, 1) for dx in (0, 1)]
            cs = set(c for _, c in q)
            if len(cs) > 1 and (ROUND & cs) and frozenset(cs) not in BENIGN:
                k = '+'.join(sorted(cs))
                per[ts][k] += 1
                ex.setdefault((ts, k), (m, cx, cy, q))
print('maps swept: %d   harness failures: %d' % (len(maps) - len(fails), len(fails)))
for m, e in fails[:8]: print('   FAIL %-24s %s' % (m, e[:80]))
print()
tot = {t: sum(c.values()) for t, c in per.items()}
for ts in sorted(tot, key=lambda t: -tot[t]):
    print('Tileset%02d  %d broken hull cells' % (ts, tot[ts]))
    for k, n in per[ts].most_common(6):
        m, cx, cy, q = ex[(ts, k)]
        print('    %-34s n=%-5d %s (%d,%d) %s' % (k, n, m, cx, cy, q))
if not tot: print('no broken hull cells anywhere')
