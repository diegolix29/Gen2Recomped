# Audit a harness dump for the failure modes this mod actually has.
import sys, collections
# canopy pins only the 2x2 group's ANCHOR tile by design -- the other three
# tiles of that cell stay cylinder and the group build claims them, so a
# canopy+cylinder cell is the intended shape, not a broken one.
BENIGN = {frozenset(('canopy', 'cylinder'))}
name = sys.argv[1]
lines = open('/root/dsview/out_%s.txt' % name).read().splitlines()
TW, TH = (int(v) for v in lines[0].split()[-1].split('x'))
g = []
for ln in lines[1:]:
    g.append([(int(c.split(':')[0], 16), c.split(':')[1], int(c.split(':')[2]))
              for c in ln.split()])

mixed = collections.Counter()
mixedwhere = {}
for cy in range(TH // 2):
    for cx in range(TW // 2):
        q = [g[cy*2+dy][cx*2+dx] for dy in (0,1) for dx in (0,1)]
        cs = set(c for _, c, _ in q)
        if len(cs) > 1 and frozenset(cs) not in BENIGN:
            key = tuple(sorted(cs))
            # only care where a ROUND class shares a cell with something else:
            # that is the combination that cannot be carved as one hull
            mixed[key] += 1
            mixedwhere.setdefault(key, (cx, cy, [('%02X'%t, c) for t, c, _ in q]))
print('=== %s  %dx%d tiles' % (name, TW, TH))
ROUND = {'cylinder', 'canopy', 'stump', 'planter', 'can'}
print('-- cells whose four tiles disagree (round classes first):')
for k, n in sorted(mixed.items(), key=lambda kv: (-(len(ROUND & set(kv[0])) > 0), -kv[1])):
    flag = ' <== ROUND' if ROUND & set(k) else ''
    cx, cy, q = mixedwhere[k]
    print('   %-40s n=%-5d e.g. cell (%d,%d) %s%s' % ('+'.join(k), n, cx, cy, q, flag))
hist = collections.Counter((c, h) for row in g for _, c, h in row)
print('-- class/height histogram:')
for (c, h), n in hist.most_common(20):
    print('   %-12s h=%-4d %d' % (c, h, n))
