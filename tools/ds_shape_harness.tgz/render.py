# Draw the harness dump as a 2.5D preview: every tile lifted by the height
# TileShape resolved for it, back-to-front, with a shaded side face under it.
# Not the mod's renderer -- enough of it to SEE flat vs raised vs sunken and
# to spot a cell whose four tiles disagree.
import sys, json
from PIL import Image, ImageDraw

name = sys.argv[1]
S = int(sys.argv[2]) if len(sys.argv) > 2 else 3
d = json.load(open('/root/dsview/data/%s.json' % name))
atlas = Image.frombytes('RGB', (d['imgW'], d['imgH']),
                        open('/root/dsview/data/ts%02d.raw' % d['tileset'], 'rb').read())
IW = d['imgW'] // 8

lines = open('/root/dsview/out_%s.txt' % name).read().splitlines()
hdr = lines[0].split()
TW, TH = (int(v) for v in hdr[-1].split('x'))
grid = []
for ln in lines[1:]:
    row = []
    for cell in ln.split():
        t, cls, h = cell.split(':')
        row.append((int(t, 16), cls, int(h)))
    grid.append(row)

CLS_TINT = {}
LIFT = 1.0                       # world px of height -> screen px
out = Image.new('RGB', (TW * 8 * S, (TH * 8 + 48) * S), (24, 28, 40))
dr = ImageDraw.Draw(out)
for ty in range(TH):
    for tx in range(TW):
        t, cls, h = grid[ty][tx]
        sx, sy = tx * 8 * S, (ty * 8 + 40 - int(h * LIFT)) * S
        src = atlas.crop(((t % IW) * 8, (t // IW) * 8, (t % IW) * 8 + 8, (t // IW) * 8 + 8))
        if h > 0:                # side face: the tile darkened, h px tall
            face = src.point(lambda v: int(v * 0.55))
            face = face.resize((8 * S, max(1, int(h * LIFT)) * S), Image.NEAREST)
            out.paste(face, (sx, sy + 8 * S))
        elif h < 0:
            dr.rectangle([sx, sy, sx + 8 * S, sy + 8 * S], fill=(20, 30, 70))
        out.paste(src.resize((8 * S, 8 * S), Image.NEAREST), (sx, sy))
out.save('/root/dsview/view_%s.png' % name)
print('view_%s.png' % name, out.size)

# and a class map, so a mixed cell is visible as a colour seam
PAL = {}
import colorsys
def col(c):
    if c not in PAL:
        i = len(PAL)
        r, g, b = colorsys.hsv_to_rgb((i * 0.37) % 1.0, 0.75, 1.0)
        PAL[c] = (int(r * 255), int(g * 255), int(b * 255))
    return PAL[c]
cm = Image.new('RGB', (TW * 8, TH * 8))
cd = ImageDraw.Draw(cm)
for ty in range(TH):
    for tx in range(TW):
        cd.rectangle([tx * 8, ty * 8, tx * 8 + 7, ty * 8 + 7], fill=col(grid[ty][tx][1]))
cm.save('/root/dsview/class_%s.png' % name)
print('classes:', ', '.join('%s' % k for k in PAL))
