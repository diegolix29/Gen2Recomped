-- Headless driver for DRAMATIC_SHAPE's shape pipeline.
-- Runs the REAL lib/TileShape.lua and lib/Structures.lua against Prism map
-- data exported from the disassembly, and dumps the resolved class+height
-- per tile so the result can be looked at instead of guessed at.
local MODDIR = "/root/ds/work"
local DATADIR = "/root/dsview/data"
local mapname = arg[1] or "CaperRidge"
local want = arg[2] or "shapes"   -- shapes | structures

-- ---- tiny JSON reader (numbers, strings, arrays, objects) ----------------
local function readjson(path)
  local s = assert(io.open(path)):read("*a")
  local pos = 1
  local function skip() pos = s:find("[^ \n\t\r]", pos) or #s + 1 end
  local parse
  local function pstr()
    local a = s:find('"', pos + 1, true); local v = s:sub(pos + 1, a - 1)
    pos = a + 1; return v
  end
  function parse()
    skip()
    local c = s:sub(pos, pos)
    if c == "{" then
      local o = {}; pos = pos + 1; skip()
      if s:sub(pos, pos) == "}" then pos = pos + 1; return o end
      while true do
        skip(); local k = pstr(); skip(); pos = pos + 1
        o[k] = parse(); skip()
        local d = s:sub(pos, pos); pos = pos + 1
        if d == "}" then return o end
      end
    elseif c == "[" then
      local a = {}; pos = pos + 1; skip()
      if s:sub(pos, pos) == "]" then pos = pos + 1; return a end
      while true do
        a[#a + 1] = parse(); skip()
        local d = s:sub(pos, pos); pos = pos + 1
        if d == "]" then return a end
      end
    elseif c == '"' then return pstr()
    else
      local e = s:find("[,%]}]", pos) or #s + 1
      local v = s:sub(pos, e - 1); pos = e
      if v == "true" then return true elseif v == "false" then return false end
      return tonumber(v)
    end
  end
  return parse()
end

local M = readjson(DATADIR .. "/" .. mapname .. ".json")

-- ---- stubs for the game modules the mod reaches into ---------------------
package.preload["src.core.GameVersion"] = function()
  return { get = function() return "prism" end }
end
package.preload["src.world.Map"] = function()
  return { isOutdoor = function(def)
    return def.env == "ROUTE" or def.env == "TOWN"
  end }
end
local raw = assert(io.open(DATADIR .. ("/ts%02d.raw"):format(M.tileset), "rb")):read("*a")
local IMGW, IMGH = M.imgW, M.imgH
local imageData = {
  getDimensions = function() return IMGW, IMGH end,
  getPixel = function(_, x, y)
    local o = (y * IMGW + x) * 3
    local r, g, b = raw:byte(o + 1, o + 3)
    if not r then return 0, 0, 0, 0 end
    return r / 255, g / 255, b / 255, 1
  end,
}
package.preload["src.render.Assets"] = function()
  return { imageData = function() return imageData end,
           register = function() end }
end
package.preload["src.render.TileRenderer"] = function()
  return { borderBlockFor = function(m)
             if m.def.env == "ROUTE" or m.def.env == "TOWN" then return M.border end
             return M.border
           end,
           voidFill = "trees" }
end

-- ---- the mod's own loader ------------------------------------------------
local V = {}
local modules, datafiles = {}, {}
local function chunk(rel)
  local f = assert(io.open(MODDIR .. "/" .. rel))
  local src = f:read("*a"); f:close()
  return assert(load(src, "@" .. rel))
end
function V.require(n)
  if modules[n] == nil then modules[n] = chunk("lib/" .. n .. ".lua")(V) end
  return modules[n]
end
function V.data(n)
  if datafiles[n] == nil then datafiles[n] = chunk("data/" .. n .. ".lua")(V) end
  return datafiles[n]
end

-- ---- fabricate the map ---------------------------------------------------
local W, H = M.w, M.h                       -- in BLOCKS
local TW, TH = W * 4, H * 4                 -- in tiles
local blocks = {}
for b = 0, #M.meta / 16 - 1 do
  local t = {}
  for i = 1, 16 do t[i] = M.meta[b * 16 + i] end
  blocks[b + 1] = t
end
local collision = {}
for b = 0, #M.coll / 4 - 1 do
  collision[b + 1] = { M.coll[b * 4 + 1], M.coll[b * 4 + 2],
                       M.coll[b * 4 + 3], M.coll[b * 4 + 4] }
end
local tileset = {
  id = ("Tileset%02d"):format(M.tileset),
  blocks = blocks, collision = collision,
  image = imageData, imageWidth = M.imgW, imageHeight = M.imgH,
  tilesPerRow = M.imgW / 8, animatedTiles = nil,
}
local function blockAt(bx, by)
  if bx < 0 or by < 0 or bx >= W or by >= H then return M.border end
  return M.blocks[by * W + bx + 1]
end
local map = {}
map.id = mapname
map.tileset = tileset
map.def = { width = W, height = H, tileset = "OVERWORLD", env = M.env, objects = {} }
map.widthCells, map.heightCells = W * 2, H * 2
map.walkable, map.waterTiles, map.doorTiles = nil, nil, {}
function map:tileAt(tx, ty)
  local b = blockAt(math.floor(tx / 4), math.floor(ty / 4))
  return blocks[b + 1][(ty % 4) * 4 + (tx % 4) + 1] or 0
end
function map:cellTile(cx, cy)                -- Gen 2: the COLLISION CLASS
  local b = blockAt(math.floor(cx / 2), math.floor(cy / 2))
  return collision[b + 1][(cy % 2) * 2 + (cx % 2) + 1] or 0
end
-- Prism's own TileCollisionTable (tilesets/collision.asm): LANDTILE rows
-- are walkable, WATERTILE is water, WALLTILE is solid.  Read from the
-- engine's list rather than guessed.
local PERM = {}
for i, v in ipairs(M.perm) do PERM[i - 1] = v end
function map:isWalkableCell(cx, cy) return PERM[self:cellTile(cx, cy)] == 0 end
function map:isWaterCell(cx, cy) return PERM[self:cellTile(cx, cy)] == 1 end
function map:isGrassCell(cx, cy)
  local c = self:cellTile(cx, cy)
  return c == 0x18 or c == 0x14
end
function map:warpAtCell() return nil end
map.warpAt = {}

-- ---- run -----------------------------------------------------------------
local TileShape = V.require("TileShape")
if want == "structures" then
  local Structures = V.require("Structures")
  local S = Structures.forMap(map)
  -- how many `canopy` anchors actually formed a 2x2 group, and how many
  -- fell through to the mesher's plain box (the partner test failed)
  local stamps = #(S.roundStamps or {})
  local anchors, grouped = 0, 0
  for cy = 0, H * 2 - 1 do
    for cx = 0, W * 2 - 1 do
      local sh = S.shapeAt[(cy * 2 + 64) * 4096 + (cx * 2 + 64)]
      if sh and sh.art == "canopy" then
        anchors = anchors + 1
        if S.skip[(cy * 2 + 64) * 4096 + (cx * 2 + 64)] then grouped = grouped + 1 end
      end
    end
  end
  print(("%s: roundStamps=%d canopyAnchors=%d grouped=%d LOOSE=%d")
        :format(mapname, stamps, anchors, grouped, anchors - grouped))
  return
end
local shapes = TileShape.forMap(map)
local out = assert(io.open("/root/dsview/out_" .. mapname .. ".txt", "w"))
out:write(("%s %s %dx%d\n"):format(mapname, tileset.id, TW, TH))
for ty = 0, TH - 1 do
  local row = {}
  for tx = 0, TW - 1 do
    local tile = map:tileAt(tx, ty)
    local s = TileShape.at(map, shapes, tile, tx, ty)
    row[#row + 1] = ("%02X:%s:%d"):format(tile, s and s.class or "nil",
                                          s and s.h or 0)
  end
  out:write(table.concat(row, " "), "\n")
end
out:close()
print("wrote /root/dsview/out_" .. mapname .. ".txt")
