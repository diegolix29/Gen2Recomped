# DRAMATIC_SHAPE headless shape harness

Runs the mod's REAL `lib/TileShape.lua` and `lib/Structures.lua` against Pokemon
Prism map data, with no LOVE and no GPU, so the shape profile can be measured
instead of guessed at from screenshots.

## Why

Every geometry pin in `data/voxel_heights.lua` used to be reasoned from block
sheets and checked by asking the player to reload.  That works for classifying a
tile and fails for geometry: three separate attempts at Caper Ridge's trees each
fixed one case and broke another.  This harness closes the loop.

## Pieces

- `export.py`   -- pulls a map out of a pokeprism disassembly checkout
                   (metatiles, collision, block data, tileset pixels, and the
                   engine's own `TileCollisionTable` permissions) into JSON +
                   a raw RGB blob.  `--tileset TILESET_NALJO_1` does every map
                   that uses one.
- `harness.lua` -- stubs `src.render.Assets`, `src.world.Map` and
                   `src.render.TileRenderer`, fabricates a `map` object, and
                   runs the pipeline.  Default mode dumps class + height per
                   tile; `structures` mode reports round-hull stamps and how
                   many `canopy` anchors actually formed a 2x2 group.
- `audit.py`    -- one map: cells whose four tiles disagree, class histogram.
- `sweep.py`    -- every exported map, ranked by tileset.
- `render.py`   -- a 2.5D preview PNG (every tile lifted by its resolved
                   height, back to front) plus a class map.

## The metric that matters

A cell whose four tiles carry different classes when one of them is ROUND
(`cylinder`/`canopy`/`stump`/`planter`) cannot be carved as a single hull --
that is what a "flat panel where a tree should be" is.  `sweep.py` counts them.

A `canopy` + `cylinder` cell is NOT one of these: the canopy class pins only
the 2x2 group's anchor tile by design.

## Usage

    python3 export.py --tileset TILESET_NALJO_1     # or: export.py CaperRidge
    luajit harness.lua CaperRidge                   # -> out_CaperRidge.txt
    luajit harness.lua CaperRidge structures        # -> hull/group counts
    python3 audit.py CaperRidge
    python3 sweep.py
    python3 render.py CaperRidge 3                  # -> view_CaperRidge.png

Paths at the top of `harness.lua` (`MODDIR`, `DATADIR`) and in `export.py`
(the disassembly checkout) are the only things to point at your own tree.

## Score

Broken hull cells over 123 Prism maps: 837 at first measurement, 204 now.
What remains is art the pin schema cannot split -- a Rijon bridge deck drawn
across the bottom half of a tree, `$40` reused as furniture in an indoor map
borrowing the Kanto set, and a Southerly City block that interleaves tree tiles
with fence tiles inside one cell.
