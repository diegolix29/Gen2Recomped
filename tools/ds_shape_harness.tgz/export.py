import re,os,json,sys
from PIL import Image
os.chdir('/home/claude/prismsrc')
DIMS={}
for l in open('constants/map_dimension_constants.asm'):
    m=re.match(r'\s*mapgroup\s+(\w+),\s*(\d+),\s*(\d+)',l)
    if m: DIMS[m.group(1)]=(int(m.group(2)),int(m.group(3)))
NAMES={}
for l in open('constants/tilemap_constants.asm'):
    m=re.match(r'\s*const (TILESET_\w+)\s*;([0-9a-f]+)',l)
    if m: NAMES[m.group(1)]=int(m.group(2),16)
HDR={}
for l in open('maps/map_headers.asm'):
    m=re.match(r'\s*map_header (\w+),\s*(TILESET_\w+),\s*(\w+)',l)
    if m: HDR[m.group(1)]=(NAMES[m.group(2)],m.group(3))
BORDER={}
for l in open('maps/second_map_headers.asm'):
    m=re.match(r'\s*map_header_2 (\w+),\s*(\w+),\s*(\$?\w+),',l)
    if m:
        v=m.group(3); BORDER[m.group(1)]=int(v[1:],16) if v.startswith('$') else int(v)
PERM=[]
for l in open('tilesets/collision.asm'):
    m=re.search(r'(NONTALKABLE|TALKABLE)\s+(\w+TILE)',l)
    if m: PERM.append({'LANDTILE':0,'WATERTILE':1,'WALLTILE':15}[m.group(2)])
DKEYS={k.replace('_',''):k for k in DIMS}
def export(mapname):
    ts,env=HDR[mapname]
    c=re.sub(r'(?<!^)(?=[A-Z])','_',mapname)
    c=re.sub(r'(?<=[A-Za-z])(?=\d)','_',c).upper()
    c=DKEYS.get(c.replace('_',''),c)
    h,w=DIMS[c]
    blk=open('maps/blk/%s.ablk'%mapname,'rb').read()
    assert len(blk)==w*h, (mapname,len(blk),w*h)
    mt=open('tilesets/%02d_metatiles.bin'%ts,'rb').read()
    coll=open('tilesets/%02d_collision.bin'%ts,'rb').read()
    im=Image.open('gfx/tilesets/%02d.png'%ts).convert('RGB')
    rp='/root/dsview/data/ts%02d.raw'%ts
    if not os.path.exists(rp): open(rp,'wb').write(im.tobytes())
    json.dump({'map':mapname,'tileset':ts,'env':env,'w':w,'h':h,
      'border':BORDER.get(mapname,0),'imgW':im.size[0],'imgH':im.size[1],
      'blocks':list(blk),'meta':list(mt),'coll':list(coll),'perm':PERM},
      open('/root/dsview/data/%s.json'%mapname,'w'))
    return ts,env,w,h
if __name__=='__main__':
    if sys.argv[1]=='--tileset':
        want=NAMES[sys.argv[2]]
        names=[n for n,(t,e) in HDR.items() if t==want]
    else:
        names=sys.argv[1:]
    ok=0
    for n in names:
        try:
            r=export(n); print(n,'ts%02d'%r[0],r[1],'%dx%d'%(r[2],r[3])); ok+=1
        except Exception as e: print(n,'skip',type(e).__name__)
    print(ok,'exported')
