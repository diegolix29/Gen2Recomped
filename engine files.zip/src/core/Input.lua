-- Input abstraction: maps keyboard to Game Boy buttons.
-- `down` = held this frame; `pressed` = edge, consumed per fixed step.

-- Pad tables live in src/core/GamepadMap.lua rather than here, because the
-- Switch needs different ones: SDL names face buttons by POSITION, and
-- Nintendo's A and B are swapped relative to the Xbox layout SDL is named
-- after, so SDL "a" is the button physically labelled B.  Selecting the
-- table at call time keeps that entirely inside GamepadMap.
local GamepadMap = require("src.core.GamepadMap")
local GameVersion = require("src.core.GameVersion")

local Input = {}

local DEFAULT_BINDINGS = {
  up = "up", w = "up",
  down = "down", s = "down",
  left = "left", a = "left",
  right = "right", d = "right",
  z = "a", ["return"] = "a", space = "a",
  x = "b", backspace = "b",
  ["/"] = "x", ["'"] = "y",
  ["kpenter"] = "start", escape = "start",
  -- Select: fight-menu move reorder + bag item reorder. Tab is the
  -- discoverable default (shown in CONTROLS); both shifts stay as
  -- aliases so Right-Shift muscle memory from older builds still works.
  tab = "select",
  rshift = "select",
  lshift = "select",
  -- L AND R, WHICH THIS ENGINE HAD NO BUTTONS FOR.
  --
  -- Reported from play: "in the controls options menu add in support for the
  -- L and R button for gen3 emerald."  There was nothing to add support for
  -- -- the abstraction stopped at the Game Boy's eight buttons, and Emerald's
  -- OPTION screen has drawn a BUTTON MODE row since the day the screen was
  -- read that could not do anything because two of its three settings are
  -- about buttons that did not exist.
  --
  -- Q and E rather than the shift keys: both shifts are already SELECT, and
  -- Q/E sit under the same two fingers a shoulder button does.  Both are
  -- rebindable, which is the half of the report that was actually about the
  -- controls menu.
  q = "l",
  e = "r",
}

-- EMERALD'S BUTTON MODE, and what its three settings mean.
--
--   1 NORMAL   L and R do nothing at all, which is the cartridge's default
--   2 LR       they page through a list -- the pockets in the BAG, the boxes
--              in the PC, the pages of a summary.  In this engine that job
--              belongs to LEFT and RIGHT, so that is what they become.
--   3 L=A      L is a second A button, and R still does nothing.
--
-- Written as "which buttons ALSO count as this one" so the lookup on the hot
-- path is one table index rather than a scan.
local BUTTON_MODES = {
  [1] = nil,
  [2] = { left = { "l" }, right = { "r" } },
  [3] = { a = { "l" } },
}

-- keys that map to "start" but also to "a" would conflict; keep Enter = a,
-- Escape = start for desktop friendliness.

-- LÖVE's standard gamepad mapping (SDL game controller DB), consistent
-- across Xbox/PlayStation/generic controllers on desktop and mobile. Some
-- third-party pads report their own SDL mapping for a given physical
-- button (e.g. Select/Back/View on off-brand XInput pads), which is what
-- src/ui/BindingsMenu.lua's rebinding is for -- see applyBindings below.
-- (moved to src/core/GamepadMap.DEFAULT_GAMEPAD_BINDINGS /
-- NX_GAMEPAD_BINDINGS -- see applyBindings below)

-- left-stick deadzones: press past STICK_ON, release once back under
-- STICK_OFF. The gap (hysteresis) stops the direction from flickering
-- while the stick sits near the threshold.
local STICK_ON = 0.5
local STICK_OFF = 0.3

-- Generic SDL joysticks expose the left stick as the first two numbered
-- axes and the D-pad as a hat.  This is common on Linux handhelds whose
-- controller has no game-controller database entry.  The indices below are
-- the desktop XInput order and are only meaningful for such pads: raw
-- numbering is per-driver, and SDL's iOS/MFi driver packs only the buttons
-- a pad actually reports, which slides the D-pad down onto 7..10 (#620).
-- These are the raw DEFAULTS only: applyBindings layers the player's
-- "joyN" pad bindings over them (#632), and only a stick SDL does NOT
-- recognize as a gamepad is ever served out of this table -- see
-- joystickpressed below.
-- (moved to src/core/GamepadMap.RAW_BUTTON_BINDINGS /
-- NX_RAW_BUTTON_BINDINGS)

local HAT_DIRECTIONS = {
  u = { "up" }, d = { "down" }, l = { "left" }, r = { "right" },
  lu = { "left", "up" }, ru = { "right", "up" },
  ld = { "left", "down" }, rd = { "right", "down" },
}

-- Display "hotkeys" (COLORS/TILT/ZOOM/GBC FX + zoom step) are one-shot
-- actions fired straight from Game:keypressed/gamepadpressed -- they are
-- not Game Boy buttons, so they get their own binding table instead of
-- sharing keyBindings/padBindings above. That keeps a hotkey rebind from
-- ever colliding with (or being overwritten by) a d-pad/A/B/Start/Select
-- rebind, and vice versa. See Game:fireHotkey and src/ui/HotkeyBindingsMenu.lua.
local DEFAULT_HOTKEY_KEY_BINDINGS = {
  ["2"] = "colors",
  ["3"] = "tilt",
  ["4"] = "fastForward",
  ["5"] = "gbcfx",
  ["-"] = "zoomOut",
  ["="] = "zoomIn",
  ["9"] = "quit",
  ["0"] = "softReset",
  ["f1"] = "saveGame",
  ["f2"] = "loadGame",
  ["f10"] = "toggleModMenu",
  -- vortex hotkey for mods (e.g., Dramatic Shape voxel mode)
  ["6"] = "vortex",
  -- camera rotation
  ["["] = "cameraRotateLeft",
  ["]"] = "cameraRotateRight",
  -- mod reload
  ["f5"] = "reloadMods",
}

-- No default pad buttons: every physical button LÖVE exposes on a
-- standard gamepad is either already claimed by a Game Boy button above
-- or left free, and guessing a mapping risks colliding with a shoulder
-- button some pad already uses for something else. A player opts in
-- through HotkeyBindingsMenu's "PRESS A BUTTON" capture instead.
-- Directional stick movements and triggers are available for binding.
local DEFAULT_HOTKEY_PAD_BINDINGS = {
  ["stickup"] = nil,
  ["stickdown"] = nil,
  ["stickleft"] = nil,
  ["stickright"] = nil,
  ["rightstickup"] = nil,
  ["rightstickdown"] = nil,
  ["rightstickleft"] = nil,
  ["rightstickright"] = nil,
  ["lefttrigger"] = nil,
  ["righttrigger"] = nil,
  ["dpadup"] = nil,
  ["dpaddown"] = nil,
  ["dpadleft"] = nil,
  ["dpadright"] = nil,
}

function Input:init()
  self:applyBindings(nil)
  self:applyHotkeyBindings(nil)
  self:reset()
end

-- Layers a player's rebind choices (save.options.bindings, written by
-- src/ui/BindingsMenu.lua) on top of the defaults above. A rebind adds an
-- extra way to trigger that action instead of replacing the default key,
-- so e.g. Z/Enter/Space all still press A even after binding a 4th key to
-- it. Call whenever options load or change (see Game:applyOptions and
-- BindingsMenu:storeBinding) -- without this the menu records a choice
-- that never actually reaches gameplay.
function Input:applyBindings(overlay)
  local keys, pads, joys = {}, {}, {}
  for key, action in pairs(DEFAULT_BINDINGS) do keys[key] = action end
  -- Resolved per call, not cached at load: GamepadMap picks the NX tables
  -- when love reports that OS, and applyBindings runs after love is up.
  for button, action in pairs(GamepadMap.gamepadBindings()) do pads[button] = action end
  for index, action in pairs(GamepadMap.rawBindings()) do joys[index] = action end
  for actionId, binding in pairs(overlay or {}) do
    if type(binding) == "table" then
      if binding.key then keys[binding.key] = actionId end
      if binding.pad then pads[binding.pad] = actionId end
    elseif type(binding) == "string" then
      keys[binding] = actionId
    end
  end
  -- A pad binding named "joyN" is the Nth button of a stick SDL has no
  -- game-controller-database entry for, captured on the joystick path by
  -- src/ui/BindingsMenu.lua (#632).  It deliberately rides the existing
  -- pad slot: the CONTROLS row, the swap in BindingsMenu:storeBinding and
  -- START's reset-all then all stay one code path, and this loop is the
  -- only place that has to know what the name means.  Laid over the raw
  -- defaults AFTER them, so a rebind wins the button it claims.
  for padName, action in pairs(pads) do
    local n = tonumber(padName:match("^joy(%d+)$"))
    if n then joys[n] = action end
  end
  self.keyBindings = keys
  self.padBindings = pads
  self.joyBindings = joys
end

-- Same layering as applyBindings above, but for the hotkey action table
-- (save.options.hotkeyBindings, written by src/ui/HotkeyBindingsMenu.lua).
-- A rebind here adds an extra trigger for that action rather than
-- replacing the default, exactly like applyBindings.
function Input:applyHotkeyBindings(overlay)
  local keys, pads = {}, {}
  for key, action in pairs(DEFAULT_HOTKEY_KEY_BINDINGS) do keys[key] = action end
  for button, action in pairs(DEFAULT_HOTKEY_PAD_BINDINGS) do pads[button] = action end
  for actionId, binding in pairs(overlay or {}) do
    if type(binding) == "table" then
      if binding.key then keys[binding.key] = actionId end
      if binding.pad then pads[binding.pad] = actionId end
    elseif type(binding) == "string" then
      keys[binding] = actionId
    end
  end
  self.hotkeyKeyBindings = keys
  self.hotkeyPadBindings = pads
end

-- Allow mods to add default hotkey bindings at runtime
function Input:addHotkeyKeyBinding(key, actionId)
  if not self.hotkeyKeyBindings then self.hotkeyKeyBindings = {} end
  self.hotkeyKeyBindings[key] = actionId
end

function Input:addHotkeyPadBinding(pad, actionId)
  if not self.hotkeyPadBindings then self.hotkeyPadBindings = {} end
  self.hotkeyPadBindings[pad] = actionId
end

-- Returns the hotkey action id (e.g. "tilt") bound to a keyboard key or
-- gamepad button, or nil. These are looked up straight from
-- Game:keypressed/gamepadpressed -- they never touch state/pressQueue,
-- since a hotkey fires once and has no held/isDown concept.
function Input:hotkeyForKey(key)
  return self.hotkeyKeyBindings and self.hotkeyKeyBindings[key]
end

function Input:hotkeyForPad(button)
  return self.hotkeyPadBindings and self.hotkeyPadBindings[button]
end

-- Purely event-driven state (press sets true, release sets false) has no
-- fallback if a release event never arrives -- focus loss, a minimized
-- window, or a disconnected gamepad can all swallow the key-up/button-up
-- that would have cleared a held direction. Called from Game on those
-- transitions so a stuck flag can't outlive them.
function Input:reset()
  self.state = {}
  self.pressQueue = {}
  self.pressed = {}
  self.sources = {}
  self.stickAxis = { x = 0, y = 0 }
  self.stickDir = nil
  self.hatDirs = {}
end

-- Multiple physical sources (W + Up, d-pad + stick, etc.) can claim the
-- same GB button. Track them individually so releasing one doesn't clear
-- a hold another source still owns, and so a press+release that both land
-- before the next FixedStep can't be revived when step() drains the queue.
local function press(self, btn, source)
  local sources = self.sources[btn]
  if not sources then
    sources = {}
    self.sources[btn] = sources
  end
  if not sources[source] then
    sources[source] = true
    table.insert(self.pressQueue, btn)
  end
  self.state[btn] = true
end

local function release(self, btn, source)
  local sources = self.sources[btn]
  if sources then
    sources[source] = nil
    if next(sources) == nil then
      -- Leave an empty table (not nil) so step() can tell a real
      -- source was released before the queue drained, versus a
      -- synthetic pressQueue inject that never had sources at all.
      self.state[btn] = false
    end
  else
    self.state[btn] = false
  end
end

function Input:keypressed(key)
  local btn = self.keyBindings[key]
  if btn then
    press(self, btn, "key:" .. key)
  end
end

function Input:keyreleased(key)
  local btn = self.keyBindings[key]
  if btn then
    release(self, btn, "key:" .. key)
  end
end

-- Called once per fixed step: promote queued presses to this step's edges.
-- Hold state is owned by live sources (updated in press/release), not
-- re-asserted here -- otherwise a same-frame press→release leaves the
-- button stuck on after the queue drains.
-- Synthetic injects (tests/drivers writing pressQueue directly, with no
-- source entry) still set state so scripted holds keep working.
function Input:step()
  self.pressed = {}
  for _, btn in ipairs(self.pressQueue) do
    self.pressed[btn] = true
    local sources = self.sources[btn]
    if sources == nil then
      -- synthetic pressQueue inject (tests/drivers): no live source map
      self.state[btn] = true
    elseif next(sources) ~= nil then
      self.state[btn] = true
    end
    -- sources == {}: real press fully released before this step -- keep up
  end
  for btn, sources in pairs(self.sources) do
    if next(sources) == nil then
      self.sources[btn] = nil
    end
  end
  self.pressQueue = {}
end

-- The on-screen touch overlay (src/core/TouchControls.lua) presses GB
-- buttons directly by name -- not through a keyboard alias -- so a player
-- rebind can never detach or shadow the overlay.
function Input:overlayPressed(btn)
  press(self, btn, "touch:" .. btn)
end

function Input:overlayReleased(btn)
  release(self, btn, "touch:" .. btn)
end

function Input:gamepadpressed(joystick, button)
  local btn = self.padBindings[button]
  if btn then
    press(self, btn, "pad:" .. button)
  end
end

function Input:gamepadreleased(joystick, button)
  local btn = self.padBindings[button]
  if btn then
    release(self, btn, "pad:" .. button)
  end
end

-- LOVE raises love.joystickpressed for EVERY stick, including ones SDL
-- recognizes as gamepads, which raise love.gamepadpressed for the same
-- physical press as well.  Answering both meant the fixed raw table
-- re-asserted the factory A/B/START/SELECT map underneath the player's
-- rebinds, so swapping A and B in CONTROLS pressed both at once and any
-- controller rebind of those four looked ignored; on iOS the MFi driver's
-- packing put the D-pad on 7..10, so a D-pad press also fired SELECT or
-- START (#620, #632).  A recognized pad is served by the gamepad path
-- alone; the raw path exists for sticks with no game-controller-database
-- entry.  A nil joystick is a raw stick: that is how
-- tests/input_hold_test.lua and the drivers drive this path.
local function isRawStick(joystick)
  -- pcall-safe via GamepadMap: love-nx's joystick objects answer isGamepad
  -- but a stubbed one in tests may not, and an error here would swallow
  -- every button press on the platform it was meant to protect.
  return not GamepadMap.ignoreRawForJoystick(joystick)
end

function Input:joystickpressed(joystick, button)
  if not isRawStick(joystick) then return end
  local btn = self.joyBindings[button]
  if btn then press(self, btn, "joy:" .. button) end
end

function Input:joystickreleased(joystick, button)
  if not isRawStick(joystick) then return end
  local btn = self.joyBindings[button]
  if btn then release(self, btn, "joy:" .. button) end
end

-- THE TRIGGERS AND THE RIGHT STICK AS BUTTONS, so CONTROLS can bind them.
--
-- Reported: players want to remap to every input their controller has. SDL
-- reports ZL / ZR (LT / RT) and the right stick as AXES, never as buttons, so
-- the capture never saw them. Each becomes a pseudo-button with a name of its
-- own -- "triggerleft", "triggerright", "rightx+", "rightx-", "righty+",
-- "righty-" -- pressed past STICK_ON and released under STICK_OFF, and
-- bound like any pad button (padBindings[name]). Unbound by default, so a
-- pad nobody remaps behaves exactly as before.
Input.AXIS_BUTTONS = {
  triggerleft = { "triggerleft" }, triggerright = { "triggerright" },
  rightx = { "rightx-", "rightx+" }, righty = { "righty-", "righty+" },
}

-- axisTransitions(axis, value) -> { { name, down } ... }: the pseudo-buttons
-- this axis event pressed or released
function Input:axisTransitions(axis, value)
  local names = Input.AXIS_BUTTONS[axis]
  if not names then return {} end
  self.axisHeld = self.axisHeld or {}
  local out = {}
  local function set(name, down)
    if (self.axisHeld[name] or false) ~= down then
      self.axisHeld[name] = down or nil
      out[#out + 1] = { name, down }
    end
  end
  if #names == 1 then
    local v = value
    if v > STICK_ON then set(names[1], true) elseif v < STICK_OFF then set(names[1], false) end
  else
    local neg, pos = names[1], names[2]
    if value > STICK_ON then set(neg, false); set(pos, true)
    elseif value < -STICK_ON then set(pos, false); set(neg, true)
    elseif math.abs(value) < STICK_OFF then set(neg, false); set(pos, false) end
  end
  return out
end

-- a pseudo-button's press or release, through the pad map
function Input:padButton(name, down)
  local btn = self.padBindings and self.padBindings[name]
  if not btn then return end
  if down then press(self, btn, "pad:" .. name) else release(self, btn, "pad:" .. name) end
end

-- left stick treated as a continuous held direction, same 4-way rule as
-- the touch swipe d-pad: whichever axis has the larger magnitude wins.
function Input:gamepadaxis(joystick, axis, value)
  if axis == "leftx" then
    self.stickAxis.x = value
  elseif axis == "lefty" then
    self.stickAxis.y = value
  else
    return
  end

  local x, y = self.stickAxis.x, self.stickAxis.y
  local ax, ay = math.abs(x), math.abs(y)
  local newDir = self.stickDir
  if ax > STICK_ON or ay > STICK_ON then
    if ax >= ay then
      newDir = x > 0 and "right" or "left"
    else
      newDir = y > 0 and "down" or "up"
    end
  elseif ax < STICK_OFF and ay < STICK_OFF then
    newDir = nil
  end

  if newDir ~= self.stickDir then
    if self.stickDir then
      release(self, self.stickDir, "stick")
    end
    if newDir then
      press(self, newDir, "stick")
    end
    self.stickDir = newDir
  end
end

-- RAW PADS DO NOT AGREE ON WHICH AXES THE LEFT STICK IS.
--
-- Axes 1 and 2 are the desktop XInput order, and that is all this accepted.
-- A pad SDL has no mapping for -- a Switch Pro over Bluetooth, a Joy-Con
-- pair, most GameSir models -- numbers its axes however its driver likes, so
-- the stick arrived on 3/4 (or 4/5) and nothing was listening: "the analog
-- stick isn't working".  GamepadMap.loadMappings fixes the pads that can be
-- named; this fixes the rest, by watching which axes actually move.
--
-- The rule: the first axis to cross the press threshold claims the stick,
-- and its PARTNER is the other half of the pair (axes arrive x-then-y, so an
-- odd index pairs with the one after it and an even with the one before).
-- Triggers are the thing not to adopt -- they rest at -1 and swing to +1 --
-- so an axis never seen near zero is refused.  Learned per joystick, and the
-- table is weak-keyed so unplugging a pad forgets it.
-- THE PAD THAT IS NOT AN OBJECT.  A Linux handheld with no SDL
-- game-controller mapping sends raw axes and hats with NO joystick at all --
-- which is the exact case this whole raw path exists to serve -- and `nil` is
-- not a table key: `self._rawSticks[nil] = st` raises "table index is nil"
-- and takes the input handler down with it.  Every stick movement on that
-- hardware, on the one code path written for that hardware.
--
-- One shared key stands in for "no joystick object".  It is an upvalue, so
-- the weak table cannot collect it while the game is running, and a device
-- that DOES identify itself still gets a row of its own.
local NO_JOYSTICK = {}

local function rawStickState(self, joystick)
  self._rawSticks = self._rawSticks or setmetatable({}, { __mode = "k" })
  local key = joystick or NO_JOYSTICK
  local st = self._rawSticks[key]
  if not st then
    st = { xAxis = 1, yAxis = 2, locked = false, restedNearZero = {} }
    self._rawSticks[key] = st
  end
  return st
end

function Input:joystickaxis(joystick, axis, value)
  if not isRawStick(joystick) then return end
  local st = rawStickState(self, joystick)
  if math.abs(value) < 0.2 then st.restedNearZero[axis] = true end
  if not st.locked and math.abs(value) > STICK_ON
     and st.restedNearZero[axis] then
    if axis % 2 == 1 then
      st.xAxis, st.yAxis = axis, axis + 1
    else
      st.xAxis, st.yAxis = axis - 1, axis
    end
    st.locked = true
  end
  if axis == st.xAxis then
    self:gamepadaxis(joystick, "leftx", value)
  elseif axis == st.yAxis then
    self:gamepadaxis(joystick, "lefty", value)
  end
end

-- Same duplicate-event rule as joystickpressed (#620, #632): a recognized
-- pad's D-pad already arrived as dpup/dpdown/dpleft/dpright through the
-- gamepad map, so letting the hat answer too would re-assert the factory
-- directions on top of a direction rebind.
function Input:joystickhat(joystick, hat, direction)
  if not isRawStick(joystick) then return end
  local source = "hat:" .. hat
  for _, btn in ipairs(self.hatDirs[hat] or {}) do
    release(self, btn, source)
  end
  local dirs = HAT_DIRECTIONS[direction] or {}
  for _, btn in ipairs(dirs) do
    press(self, btn, source)
  end
  self.hatDirs[hat] = dirs
end

-- ...and the one place both readers go through, so a mode that aliases a
-- button cannot be honoured by one of them and not the other.
local function alsoHeld(self, map, btn)
  -- Gen4's X opens the field menu and Y uses the registered key item.
  -- Keep START/SELECT as portable shortcuts for existing screen callers.
  if GameVersion.isGen4() then
    if btn=='start' and map.x then return true end
    if btn=='select' and map.y then return true end
  end
  local extra = self.buttonAlias and self.buttonAlias[btn]
  if not extra then return false end
  for _, from in ipairs(extra) do
    if map[from] then return true end
  end
  return false
end

function Input:setButtonMode(mode)
  self.buttonMode = tonumber(mode) or 1
  self.buttonAlias = BUTTON_MODES[self.buttonMode]
end

function Input:isDown(btn)
  if self.state[btn] then return true end
  return alsoHeld(self, self.state, btn)
end

-- True when the on-screen overlay is one of the live sources holding this
-- button (see overlayPressed above).  Player:turnWindow widens the
-- turn-in-place tap window on touch, where a press and release can never be
-- as short as a physical d-pad's (#415).
function Input:isTouchDown(btn)
  local sources = self.sources[btn]
  return (sources and sources["touch:" .. btn]) and true or false
end

function Input:wasPressed(btn)
  if self.pressed[btn] then return true end
  return alsoHeld(self, self.pressed, btn)
end

-- Soft reset (#563).  _Joypad (engine/joypad.asm) tests the RAW joypad read
-- with `cp PAD_BUTTONS` -- an equality, not a mask -- so the combo counts
-- only while A, B, SELECT and START are the only buttons down; any d-pad
-- direction in the mix cancels it.  That test sits ahead of the wJoyIgnore
-- and BIT_DISABLE_JOYPAD masking below it, which is why the reset still
-- works mid-battle and mid-cutscene where ordinary input is thrown away.
-- TrySoftReset then burns one DelayFrame per pass and decrements hSoftReset,
-- seeded with 16 by Init (home/init.asm), so the combo has to survive 16
-- consecutive polls.  That hold is also what keeps the on-screen overlay
-- safe: it already takes four separate fingers on four separate controls,
-- and they all have to stay put for better than a quarter of a second.
local SOFT_RESET_FRAMES = 16

function Input:softResetHeld()
  if not (self.state.a and self.state.b
          and self.state.start and self.state.select) then
    return false
  end
  return not (self.state.up or self.state.down
              or self.state.left or self.state.right)
end

-- Ticked once per fixed step by Game:step; true on the step the countdown
-- runs out.  hSoftReset is never re-seeded on release in the original, so
-- its count leaks across a whole session; a port that copied that would
-- eventually reset on a stray four-button press, so the counter re-arms as
-- soon as the combo drops.
function Input:softResetStep()
  if not self:softResetHeld() then
    self.softResetFrames = nil
    return false
  end
  local left = (self.softResetFrames or SOFT_RESET_FRAMES) - 1
  self.softResetFrames = left
  if left > 0 then return false end
  self.softResetFrames = nil
  return true
end

return Input
