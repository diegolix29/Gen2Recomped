-- Save/load via love.filesystem.  Game progress lives in save.lua;
-- Options (audio, display, battle preferences) live in a separate
-- options.lua so they survive New Game and aren't tied to a save slot.
-- Both are plain Lua tables serialized as Lua source (deterministic
-- key order) and read back through SaveSerializer's data-only parser,
-- so a save can never execute code.
--
-- The load pipeline is read -> parse -> migrate -> validate/quarantine
-- -> restore; Game:restoreSave drives the last two phases with the
-- merged Data threaded in, because this module must not reach into
-- Data itself.

local Logger = require("src.core.Logger")
local Version = require("src.core.Version")
local SaveSerializer = require("src.core.SaveSerializer")
local Runtime = require("src.mods.Runtime")
local Semver = require("src.mods.Semver")
local Boxes = require("src.pokemon.Boxes")
local Stats = require("src.pokemon.Stats")
local Bag = require("src.inventory.Bag")
local Badges = require("src.inventory.Badges")

local GameVersion = require("src.core.GameVersion")
local SaveSafety = require("src.core.SaveSafety")

local SaveData = {}

-- Progress files carry the game-version suffix so Red / Blue / Yellow saves
-- coexist: Red keeps save.lua / .bak / .tmp exactly as before; Blue is
-- save_blue.lua and Yellow is save_yellow.lua (+ .bak/.tmp).  options.lua is
-- deliberately shared across versions (it holds global preferences and the
-- mod enable-state, not per-playthrough data).
local OPTIONS_FILENAME = "options.lua"

-- Main / backup / staged-witness names for a version (defaults to the active
-- one).  The backup is a rolling copy and .tmp is the staged-write witness;
-- load promotes either when the main file is missing or fails to parse.
-- Forward-declared here so saveFilename (just below) and every save/load
-- caller share the one upvalue; the body is filled in under "save slots"
-- once the options IO it depends on exists, because it now resolves the
-- ACTIVE slot for a version rather than the fixed flat name.
local saveNames

-- The main save filename for a version -- used by the title screen's
-- CONTINUE gate so it looks for the right game's save.
function SaveData.saveFilename(version)
  -- every CONTINUE gate asks this first: a lost or unreadable main file with
  -- a good copy behind it is put back before the answer (once per process)
  pcall(SaveData.ensureRecovered, version)
  local main = saveNames(version)
  return main
end

-- ------- portable mode
-- LÖVE's save directory is always the OS per-user path derived from the
-- identity (conf.lua), so it can't be relocated at runtime. Portable mode
-- instead drops a plain-Lua io.* filesystem next to the game whenever a
-- `portable.txt` marker sits beside the executable/source, letting a USB
-- copy carry its own save.lua/options.lua (and, through options.lua, the
-- mod enable-state) rather than leaving them on the host machine.
local PORTABLE_MARKER = "portable.txt"
local SEP = package.config:sub(1, 1)

local portableChecked = false
local portableBase = false      -- resolved base dir when active, else false
local portableFsCache = nil

local function pathExists(path)
  local f = io.open(path, "rb")
  if not f then return false end
  f:close()
  return true
end

-- an io.* filesystem exposing the love.filesystem subset the save/options
-- round-trip needs (getInfo/read/write/remove), rooted at `dir`
local function makePortableFs(dir)
  local function full(name) return dir .. SEP .. name end
  return {
    getInfo = function(name)
      if not pathExists(full(name)) then return nil end
      return { type = "file" }
    end,
    read = function(name)
      local f = io.open(full(name), "rb")
      if not f then return nil, "no file: " .. name end
      local data = f:read("*a")
      f:close()
      return data
    end,
    write = function(name, data)
      local f, err = io.open(full(name), "wb")
      if not f then return false, err end
      f:write(data)
      f:close()
      return true
    end,
    remove = function(name)
      os.remove(full(name))
      return true
    end,
    -- for SaveSafety.atomicWrite's rename-over-the-old-file step
    realPath = function(name) return full(name) end,
    createDirectory = function(name)
      -- portable mode writes real files through io.*, which will not
      -- create missing parent directories; mkdir the tree so a slot path
      -- like "saves/red" exists before a write lands inside it
      local osPath = full(name):gsub("/", SEP)
      if SEP == "\\" then
        os.execute('mkdir "' .. osPath .. '" 2>nul')
      else
        os.execute('mkdir -p "' .. osPath .. '" 2>/dev/null')
      end
      return true
    end,
  }
end

-- Every folder a player might reasonably call "the game folder", best first:
-- the packaged-app container, the folder holding the executable, then the
-- source itself.  Portable mode is the case where one of these holds the
-- marker; the list itself is just locations, marker or not, which is also
-- what the mods panel needs to notice a mod dropped beside the game by hand
-- (LauncherMods.strays).  Empty on Android/iOS and outside LOVE.
function SaveData.gameFolders()
  if not (love and love.filesystem) then return {} end
  -- Desktop only: portable mode carries the save (and, since issue #74, the
  -- ROM cache) in the game folder next to the executable/source.  On
  -- Android/iOS the source is a read-only package with no such folder, so
  -- portable mode never applies there.
  if love.system and love.system.getOS then
    local osName = love.system.getOS()
    if osName ~= "Windows" and osName ~= "Linux" and osName ~= "OS X" then
      return {}
    end
  end
  local src = love.filesystem.getSource and love.filesystem.getSource()
  local sbd = love.filesystem.getSourceBaseDirectory
    and love.filesystem.getSourceBaseDirectory()
  -- A packaged macOS build nests the game inside Gen2Recomped.app/Contents/
  -- Resources, so getSource()/getSourceBaseDirectory() point INSIDE the
  -- bundle -- not where the player drops portable.txt (next to the .app).
  -- Recover the folder containing the .app so a packaged app finds its
  -- marker.  On Windows/Linux the executable is not a bundle, so this is nil
  -- and the plain source-base directory (next to the .exe/AppImage) is used.
  local function parentDir(path)
    return path and path:match("^(.*)/[^/]+$") or nil
  end
  local function appContainer(path)
    return parentDir(path and path:match("^(.*%.app)/Contents/"))
  end
  -- The Linux AppImage build works similarly to macOs, but the runtime mounts
  -- the squashfs at a temp path, and that becomes the base directory.
  -- The runtime exports the real .AppImage path in $APPIMAGE, so we get the
  -- base dir from there.
  local function appImageContainer()
    return parentDir(os.getenv("APPIMAGE"))
  end
  -- Order: the packaged-app containing folder (macOS .app / Linux AppImage),
  -- then the source-base directory (next to a packaged .exe), then the source
  -- itself (a `love <gamedir>` run drops portable.txt in the game folder).
  -- Built by appending so a nil (e.g. no .app in the path) never truncates
  -- the ipairs scan.
  local candidates = {}
  local appDir = appContainer(src) or appContainer(sbd) or appImageContainer()
  if appDir then candidates[#candidates + 1] = appDir end
  if sbd and sbd ~= "" then candidates[#candidates + 1] = sbd end
  if src and src ~= "" then candidates[#candidates + 1] = src end
  return candidates
end

-- The game folder carrying portable.txt, or false.  First candidate holding
-- the marker wins.
local function detectPortable()
  if portableChecked then return portableBase end
  portableChecked = true
  portableBase = false
  for _, base in ipairs(SaveData.gameFolders()) do
    if pathExists(base .. SEP .. PORTABLE_MARKER) then
      portableBase = base
      break
    end
  end
  return portableBase
end

function SaveData.isPortable()
  return detectPortable() ~= false
end

-- the raw portable-folder path (for callers building their own nested
-- paths, e.g. the ROM-derived asset cache), or nil when portable mode
-- is off
function SaveData.portableBaseDir()
  return detectPortable() or nil
end

-- the io.* filesystem for the active portable folder, or nil when off
function SaveData.portableFs()
  local base = detectPortable()
  if not base then return nil end
  if not portableFsCache then portableFsCache = makePortableFs(base) end
  return portableFsCache
end


-- ------- the game-data folder
--
-- LOVE puts the save directory under %APPDATA% (or ~/.local/share), and an
-- import writes the big thing on disk into it: a Gen 3 cartridge unpacks to
-- hundreds of megabytes of data/generated and assets/generated.  On a small
-- system drive that is exactly where a player does not want it, so the
-- launcher can point the cache at a folder of their choosing.
--
-- SCOPE IS THE CACHE AND NOTHING ELSE.  Saves, options and the mod
-- enable-state are kilobytes; they are also the first things a player goes
-- looking for when something has gone wrong, and quietly relocating them is
-- how a save "disappears".  CacheFs.root() is the single seam the cache goes
-- through, so that is the single seam this feeds.
--
-- WHERE THE CHOICE LIVES: options.dataDir, in the ordinary options file,
-- which stays in the save directory -- it could hardly live in the folder it
-- names.  PORTABLE MODE OUTRANKS IT: a portable copy is already off the host
-- machine by definition, and two relocation mechanisms arguing over one
-- cache is a bug report nobody can read.
--
-- Desktop always, Android once a folder can be proved writable with the
-- same io.* probe CacheFs uses.  iOS still has no arbitrary writable
-- folder to point at.  Android 11+ will refuse most shared folders
-- (Downloads, DCIM); app-owned dirs on phone storage or an SD card still
-- pass, which is the whole point of offering the setting there.
local PROBE_NAME = ".gen2recomp-write-test"

local dataDirChecked = false
local dataDirBase = false     -- resolved folder when active, else false
local dataDirWhy = nil        -- why a stored folder is not in use

function SaveData.dataDirSupported()
  if not (love and love.filesystem) then return false end
  if not (love.system and love.system.getOS) then return false end
  local osName = love.system.getOS()
  return osName == "Windows" or osName == "Linux" or osName == "OS X"
    or osName == "Android"
end

-- Extra app-owned volumes the Android bridge can name (phone vs SD card).
-- Each line from love.system.getExternalDataDirs is "label<TAB>absolute path".
-- Empty on every other OS, and on an APK older than the bridge.
function SaveData.externalDataDirs()
  if not (love and love.system and type(love.system.getExternalDataDirs) == "function") then
    return {}
  end
  local ok, raw = pcall(love.system.getExternalDataDirs)
  if not ok or type(raw) ~= "string" or raw == "" then return {} end
  local out = {}
  for line in raw:gmatch("[^\r\n]+") do
    local label, path = line:match("^(.-)\t(.+)$")
    path = SaveData.normalizeDataDir(path or line)
    if path then
      out[#out + 1] = { label = (label and label ~= "" and label) or path, path = path }
    end
  end
  return out
end

-- Trailing separators removed and slashes left alone otherwise: this string
-- is concatenated with SEP by every caller, and "D:/Games/" would build
-- "D:/Games//data" -- which Windows tolerates and a player comparing the
-- path against the one the panel prints does not.
function SaveData.normalizeDataDir(path)
  if type(path) ~= "string" then return nil end
  path = path:gsub("^%s+", ""):gsub("%s+$", "")
  if path == "" then return nil end
  while #path > 1 and (path:sub(-1) == "/" or path:sub(-1) == "\\") do
    -- ...but never past a bare root ("/" or "C:\"), which IS the whole path
    if path:match("^%a:[/\\]$") then break end
    path = path:sub(1, -2)
  end
  return path
end

-- An absolute path only.  A relative one resolves against the working
-- directory, which for a packaged build is wherever the player happened to
-- launch it from -- so the same setting would name a different folder on the
-- next launch.
function SaveData.isAbsolutePath(path)
  if type(path) ~= "string" or path == "" then return false end
  return path:sub(1, 1) == "/" or path:sub(1, 1) == "\\"
    or path:match("^%a:[/\\]") ~= nil
end

-- checkDataDir(path) -> normalised path, or nil, reason
--
-- Proves the folder is WRITABLE rather than merely present: a player who
-- picks Program Files gets told so here, not by a half-finished import.  The
-- probe file is removed again whatever happens.
function SaveData.checkDataDir(path)
  local dir = SaveData.normalizeDataDir(path)
  if not dir then return nil, "no folder chosen" end
  if not SaveData.isAbsolutePath(dir) then
    return nil, "that is not a full path"
  end
  local probe = dir .. SEP .. PROBE_NAME
  local f = io.open(probe, "wb")
  if not f then
    -- The folder may simply not exist yet (a player typing a path, or a
    -- picker that offered to make one), so try to create it once and retry
    -- before calling it unwritable.
    local ok = pcall(function()
      require("src.import.CacheFs").mkdirReal(dir)
    end)
    if ok then f = io.open(probe, "wb") end
  end
  if not f then
    return nil, "that folder could not be written to"
  end
  local wrote = pcall(function() f:write("gen2recomp") end)
  f:close()
  os.remove(probe)
  if not wrote then return nil, "that folder could not be written to" end
  return dir
end

-- The folder the cache should live in, or nil for the save directory.
-- Resolved once per process; setDataDir below drops the cache.
function SaveData.dataDir()
  if dataDirChecked then return dataDirBase or nil end
  dataDirChecked = true
  dataDirBase, dataDirWhy = false, nil
  if not SaveData.dataDirSupported() then return nil end
  -- portable wins, silently: the player already said where this copy lives
  if SaveData.isPortable() then return nil end
  local ok, opts = pcall(SaveData.loadOptions)
  local raw = ok and type(opts) == "table" and opts.dataDir or nil
  if type(raw) ~= "string" or raw == "" then return nil end
  local dir, why = SaveData.checkDataDir(raw)
  if not dir then
    -- A folder on a drive that is not plugged in today is the common case,
    -- and falling back to the save directory keeps the game playable.  The
    -- setting is NOT cleared: the drive comes back.
    dataDirWhy = why
    Logger.warn("game-data folder %s is unusable (%s); using the save directory",
      tostring(raw), tostring(why))
    return nil
  end
  dataDirBase = dir
  return dataDirBase
end

-- What is stored, whether or not it currently works -- the launcher shows
-- this one, so a folder on an unplugged drive still reads back as the
-- player's choice instead of silently becoming "default".
function SaveData.dataDirSetting()
  local ok, opts = pcall(SaveData.loadOptions)
  local raw = ok and type(opts) == "table" and opts.dataDir or nil
  if type(raw) ~= "string" or raw == "" then return nil end
  return raw
end

-- nil once the folder is in use, otherwise why it is not.
function SaveData.dataDirProblem()
  SaveData.dataDir()
  return dataDirWhy
end

-- setDataDir(path) -> ok, err.  nil or "" clears it back to the save
-- directory.  Writes the options file and drops both this module's cache and
-- CacheFs's, so the next read/write lands in the new place without a restart.
function SaveData.setDataDir(path)
  local dir, why = nil, nil
  if path ~= nil and path ~= "" then
    if not SaveData.dataDirSupported() then
      return false, "this build stores its games in one place"
    end
    dir, why = SaveData.checkDataDir(path)
    if not dir then return false, why end
  end
  local ok, opts = pcall(SaveData.loadOptions)
  if not ok or type(opts) ~= "table" then opts = SaveData.defaultOptions() end
  opts.dataDir = dir or false
  if not SaveData.saveOptions(opts) then
    return false, "the options file could not be written"
  end
  SaveData.forgetDataDir()
  pcall(function() require("src.import.CacheFs").forgetRoot() end)
  return true
end

function SaveData.forgetDataDir()
  dataDirChecked = false
  dataDirBase = false
  dataDirWhy = nil
end

-- Resolve the filesystem a persistent read/write should land on: an
-- explicitly injected non-love fs (headless tests, the mod loader's stub)
-- always wins; otherwise portable mode reroutes off the OS save directory.
local function persistFs(fs)
  if fs and love and love.filesystem and fs ~= love.filesystem then
    return fs
  end
  return SaveData.portableFs() or fs or (love and love.filesystem)
end

-- Public seam for mods (Stadium import, HD zip install, custom pickers).
-- Same routing as options/saves: injected fs, then portable.io, then LOVE.
function SaveData.persistenceFs()
  return persistFs(love and love.filesystem)
end

-- Port + original Options menu defaults.  Missing keys on load are filled
-- from this table so old options.lua files stay compatible.
function SaveData.defaultOptions()
  return {
    -- textSpeed 3 = MEDIUM, matching InitOptions' TEXT_DELAY_MEDIUM
    -- in wOptions (engine/menus/main_menu.asm)
    textSpeed = 3,
    animations = true,
    -- HOW OFTEN A SHINY TURNS UP.  nil is the cartridge's own rate -- the
    -- 1/8192 both generations roll, arrived at by their own arithmetic --
    -- and a number here is a DENOMINATOR the port rolls against instead
    -- (4096, 512, ... 1 for every single Pokemon).  Kept as the denominator
    -- rather than a percentage because that is how a player says it: "one in
    -- five hundred".
    shinyOdds = nil,
    battleStyle = "shift",
    -- battle screen composition: og (the 160x144 original) | wide
    -- (304x144, src/battle/WideBattle.lua)
    battleLayout = "og",
    -- BATTLE SIZE: "fixed" = the classic integer-scaled letterbox; "fill" =
    -- scale the battle surface to the window so it fills vertically.  See
    -- BattleState:wantsFillScale.
    battleFit = "fixed",
    -- BATTLE BG: what fills the screen behind and around the battle.
    -- "white" = the display mode's paper shade (the classic look),
    -- "black" = plain black bars, "world" = the frozen overworld showing
    -- through, dimmed.  See BattleState:bgMode.
    battleBg = "white",
    -- UI LAYOUT: "centered" = a fixed letterbox.  Every element sits where it
    -- was drawn in the 160x144 canvas and the UI does not follow the survey
    -- zoom, so nothing moves or resizes under the player.  The original
    -- composition.  "dynamic" = the dialogue box docks to the window's bottom
    -- edge, the START menu to its top right, and the UI steps down with the
    -- zoom.  Centered is the default: dynamic reads better zoomed out, but it
    -- moves the screen furniture, so it is opt-in.
    -- See Game.dynamicUI, Renderer:setUIAnchor and Renderer:uiScale.
    uiLayout = "centered",
    ruleset = "gen1_faithful",
    -- 0-7 like the GB's NR50 master volume
    musicVol = 7,
    sfxVol = 7,
    -- Yellow only: 0-7 trim for Pikachu's PCM voice clips on top of sfxVol
    -- (the PIKACHU VOL row appears only on Yellow; see Sound.lua)
    pikaVol = 7,
    musicFilter = 0,
    -- logic fast-forward multiplier; audio is unaffected (GameSpeed.lua)
    speed = 1,
    -- port display options (OptionsMenu / hotkeys 2/3/4/5)
    colors = "gbc",
    tilt = 0,
    gbcfx = 0,
    -- survey zoom offset from window fit scale (0 = FIT); see Zoom.lua
    zoom = 0,
    -- OVERWORLD beyond-edge fill: trees | water | black
    voidFill = "trees",
    -- windowed | borderless (desktop fullscreen); ignored on mobile
    videoMode = "windowed",
    -- lock the window to an exact 160x144 multiple, 1..4 (0 = OFF); see
    -- src/core/FaithfulRes.lua.  Ignored on mobile.
    faithfulRes = 0,
    -- hard render frame-rate cap; render-only pacing (issue #88, FrameCap.lua)
    fpsCap = 60,
    -- graphics performance tier: auto | high | balanced | low.  "auto"
    -- picks a default from the device (ARM handhelds/phones drop the heavy
    -- extras); scales TILT / GBC FX / survey ZOOM / FPS but never game
    -- logic.  See src/core/Performance.lua.
    performance = "auto",
    -- Per-pipeline display levels, keyed by render_pipelines id (see
    -- src/render/Pipelines.lua).  A level for a mod that is not installed
    -- is kept rather than pruned, so re-enabling the mod restores the mode
    -- the player left it in.
    pipelines = {},
    -- Installation-wide one-time explanations, keyed by tutorial and option.
    -- Keep these in shared launcher options so dismissals survive save slots.
    tutorials = {},
    -- Native mod enablement is an installation option, not save-slot data.
    -- Missing entries mean enabled so newly installed mods work by default.
    mods = {},
    -- Which generation the launcher's chip row is filtered to (1/2/3), or
    -- false for ALL.  A view setting, not game state: it hides chips and
    -- nothing else, and every game stays registered and playable.
    launcherGeneration = false,
    -- Named setups the player can switch between (#593; src/mods/ModProfile.lua
    -- owns the shape, src/mods/ManagerState.lua the UI): each row is
    -- { name, enabled = {id=bool}, options = {id={k=v}}, slots = {version=slotId} }.
    -- activeProfile names the row the live set currently matches (nil for
    -- ad-hoc, so it has no default entry here; mergeOptions preserves it).
    -- modProfilesSeeded records that the pre-profiles setup was already
    -- migrated into PROFILE 1, so deleting every profile does not re-seed one.
    modProfiles = {},
    modProfilesSeeded = false,
    -- GitHub release checks for mods with a manifest "github" field
    -- (src/mods/ModUpdate.lua). Keyed by owner/repo; TTL is six hours.
    modUpdateCache = {},
    -- Community mod indexes the player has chosen to browse
    -- (src/mods/ModIndex.lua), in the order they added them.  Empty by
    -- default and never populated automatically: adding an index is how a
    -- player says they trust whoever publishes it, so the launcher asks
    -- rather than shipping one.  Rows are { url, feed, base, fallback,
    -- label }.
    modIndexes = {},
    -- Parsed index listings keyed by feed URL; TTL is 24 hours, matching how
    -- often the feeds themselves rebuild.
    modIndexCache = {},
    -- On-screen touch overlay (Android/iOS; see src/core/TouchControls.lua).
    -- enabled=false hides it permanently (distinct from auto-hide-on-gamepad).
    -- layouts.portrait / layouts.landscape each hold optional normalized
    -- centers {x=0..1, y=0..1} per control (dpad/a/b/start/select) plus a
    -- size scale; nil positions mean that orientation draws the default
    -- layout (#633).  Pre-#633 files stored one top-level positions table;
    -- TouchControls.normalizeConfig folds it into both orientations on load.
    touchControls = { enabled = true },
    -- Where imported game data lives.  false = LOVE's save directory (the
    -- appdata folder); a string is an absolute folder the player chose in
    -- LAUNCHER SETTINGS.  See the game-data folder block above.
    dataDir = false,
    -- Launcher appearance: a palette preset and an accent colour, both ids
    -- from src/import/LauncherTheme.lua.  false on either means "the one the
    -- launcher shipped with".
    launcherTheme = false,
    launcherAccent = false,
    launcherText = false,
    -- Per-generation overrides for the rows above, as
    -- { [1] = {colors="dmg"}, [2] = {...}, [3] = {...} }.  An absent
    -- generation, or an absent key inside one, means the shared value is
    -- used; see src/core/GenOptions.lua.
    perGeneration = {},
  }
end

-- Merge loaded keys over defaults (shallow).  Unknown keys are kept so
-- future options aren't dropped by older builds writing the file back.
function SaveData.mergeOptions(loaded)
  local opts = SaveData.defaultOptions()
  if type(loaded) == "table" then
    for k, v in pairs(loaded) do
      opts[k] = v
    end
  end
  return opts
end

function SaveData.encode(data)
  return SaveSerializer.encode(data)
end

function SaveData.decode(str)
  return SaveSerializer.decode(str)
end

local function readTable(fs, name)
  if not fs.getInfo(name) then return nil, "no file: " .. name end
  local body = fs.read(name)
  if type(body) ~= "string" then return nil, "unreadable: " .. name end
  return SaveSerializer.decode(body)
end

-- the stub filesystem some headless harnesses inject has no remove; a
-- lingering tmp/bak there is harmless
local function remove(fs, name)
  if fs.remove then fs.remove(name) end
end

-- ------- options

-- Both take an optional fs (write/getInfo/read) defaulting to
-- love.filesystem, so the mod loader's injected filesystem can carry the
-- options round-trip headless (no love global).
-- `gen` (1/2/3, optional) says that `opts` is a table a game has been playing
-- with, resolved for that generation by optionsFor below.  A key that
-- generation overrides then goes back into its override instead of leaking
-- into the shared value everyone else reads; see src/core/GenOptions.lua.
-- The launcher and every other caller passes nothing and writes shared values,
-- exactly as before.
function SaveData.saveOptions(opts, fs, gen)
  fs = persistFs(fs)
  if gen then
    local GenOptions = require("src.core.GenOptions")
    if GenOptions.isGeneration(gen) then
      local stored = readTable(fs, OPTIONS_FILENAME)
      opts = GenOptions.fold(stored or {}, opts, gen)
    end
  end
  opts = SaveData.mergeOptions(opts)
  -- modOptions is per-mod nested state: fold the on-disk sub-tree
  -- underneath (newest value winning per key) so one caller's partial
  -- write cannot clobber another mod's persisted keys.  Every other
  -- option stays on the shallow path.
  local onDisk = readTable(fs, OPTIONS_FILENAME)
  if onDisk and type(onDisk.modOptions) == "table" then
    local merged = {}
    for modId, bucket in pairs(onDisk.modOptions) do
      merged[modId] = bucket
    end
    for modId, bucket in pairs(opts.modOptions or {}) do
      if type(bucket) == "table" and type(merged[modId]) == "table" then
        for k, v in pairs(bucket) do merged[modId][k] = v end
      else
        merged[modId] = bucket
      end
    end
    opts.modOptions = merged
  end
  -- Tutorial acknowledgements are append-only. Preserve flags written by a
  -- newer options snapshot so saving stale in-memory options cannot show a
  -- dismissed explanation again.
  if onDisk and type(onDisk.tutorials) == "table" then
    local merged = {}
    for tutorial, flags in pairs(onDisk.tutorials) do
      merged[tutorial] = flags
    end
    local pending = type(opts.tutorials) == "table" and opts.tutorials or {}
    for tutorial, flags in pairs(pending) do
      if type(flags) == "table" and type(merged[tutorial]) == "table" then
        local copy = {}
        for key, seen in pairs(merged[tutorial]) do copy[key] = seen end
        for key, seen in pairs(flags) do
          if seen == true then copy[key] = true end
        end
        merged[tutorial] = copy
      else
        merged[tutorial] = flags
      end
    end
    opts.tutorials = merged
  end
  -- options.lua also holds every game's save-slot registry, so a write cut
  -- short here used to make every slot vanish from the launcher.  Atomic,
  -- with the previous good copy kept as options.lua.bak (SaveSafety).
  local ok, err = SaveSafety.atomicWrite(fs, OPTIONS_FILENAME, SaveSerializer.encode(opts),
    { bak = OPTIONS_FILENAME .. ".bak", decode = SaveSafety.decodeAny })
  if not ok then
    Logger.error("options save failed: %s", tostring(err))
  end
  return ok and opts or nil
end

-- The options a game of `version` should run with: the shared table with that
-- generation's overrides laid over it.  This is what a save gets attached to
-- it, so every consumer downstream -- the audio subsystems, the palette, the
-- frame cap -- reads the right value without knowing per-generation settings
-- exist.  `version` may be a version id, a generation number, or nil for the
-- version currently selected.
function SaveData.optionsFor(version, fs)
  local opts = SaveData.loadOptions(fs)
  local GenOptions = require("src.core.GenOptions")
  local gen = SaveData.generationOf(version)
  if not GenOptions.isGeneration(gen) then return opts end
  return GenOptions.resolve(opts, gen)
end

-- version id -> generation, a bare generation passed straight through, nil ->
-- whatever cartridge is selected.  Wrapped in pcall because this is reached
-- from the options round-trip, which runs in headless tests where
-- GameVersion may not be loaded at all.
function SaveData.generationOf(version)
  local GenOptions = require("src.core.GenOptions")
  if GenOptions.isGeneration(version) then return tonumber(version) end
  local ok, GameVersion = pcall(require, "src.core.GameVersion")
  if not ok or type(GameVersion) ~= "table" then return nil end
  local id = version
  if type(id) ~= "string" or id == "" then id = GameVersion.current end
  if type(id) ~= "string" or id == "" then return nil end
  local okGen, gen = pcall(GameVersion.generation, id)
  if okGen and GenOptions.isGeneration(gen) then return gen end
  return nil
end

function SaveData.loadOptions(fs)
  fs = persistFs(fs)
  local data, err = readTable(fs, OPTIONS_FILENAME)
  if not data then
    -- a cut-short options.lua: the staged and the previous copy hold the
    -- slot registry too (SaveSafety.atomicWrite)
    data = readTable(fs, OPTIONS_FILENAME .. ".tmp")
      or readTable(fs, OPTIONS_FILENAME .. ".bak")
    if data then
      Logger.warn("options.lua unreadable (%s); using its backup copy", tostring(err))
    end
  end
  if not data then
    if fs.getInfo(OPTIONS_FILENAME) then
      Logger.error("options load failed: %s", tostring(err))
    end
    return SaveData.defaultOptions()
  end
  return SaveData.mergeOptions(data)
end

-- Persist one installation-wide tutorial acknowledgement.
function SaveData.markTutorialSeen(tutorial, key, fs)
  if type(tutorial) ~= "string" or tutorial == ""
     or type(key) ~= "string" or key == "" then
    return nil
  end
  local opts = SaveData.loadOptions(fs)
  opts.tutorials = type(opts.tutorials) == "table" and opts.tutorials or {}
  local flags = opts.tutorials[tutorial]
  if type(flags) ~= "table" then
    flags = {}
    opts.tutorials[tutorial] = flags
  end
  if flags[key] == true then return opts end
  flags[key] = true
  return SaveData.saveOptions(opts, fs)
end

-- ------- save slots

-- A version's playthroughs live in numbered slots under saves/<version>/;
-- the active slot is where in-game SAVE and CONTINUE land.  The registry
-- (the ordered slot list plus which one is active) persists in options.lua
-- under options.saveSlots[version]; the active slot is also cached
-- process-wide (like GameVersion.current) so the hot saveNames path does
-- not re-read options every call.  A false cache entry means "no slot in
-- use" and the flat legacy path (save.lua / save_blue.lua / save_yellow.lua)
-- is used, which keeps a brand-new install and every pre-slots caller
-- working unchanged.
local activeSlotCache = {}   -- version -> slotId in use, or false when none
local slotsChecked = {}      -- version -> true once resolved this process

local function slotDir(version) return "saves/" .. version end

local function slotNames(version, id)
  local main = slotDir(version) .. "/" .. id .. ".lua"
  return main, main .. ".bak", main .. ".tmp"
end

-- the pre-slots flat names a version always used (save.lua for Red,
-- save_blue.lua / save_yellow.lua for the others); still the destination
-- before any slot exists
local function legacyNames(version)
  local main = "save" .. GameVersion.saveSuffix(version) .. ".lua"
  return main, main .. ".bak", main .. ".tmp"
end

-- Slot resolution is only meaningful for versions GameVersion actually knows
-- (red / blue / yellow).  An unknown id has no info entry and therefore no
-- saveSuffix; resolving its legacy names would index a nil info table and
-- crash.  Treat any unknown version as having no slots so the slot APIs
-- degrade to empty/no-op instead.
local function knownVersion(version)
  return GameVersion.info(version) ~= nil
end

-- Create the parent directory of a slot path when the fs supports it.
-- love.filesystem.createDirectory makes the whole tree; the injected memfs
-- stub keys files by full path and exposes no such method, so this is a
-- no-op there.
local function ensureParentDir(fs, name)
  local dir = name:match("^(.*)/[^/]+$")
  if dir and fs.createDirectory then fs.createDirectory(dir) end
end

-- Decode a slot's save using the same recovery order load() uses -- main,
-- then the .tmp write-witness, then the .bak -- so a slot mid-crash still
-- summarizes.  nil when nothing readable is present.
--
-- Since the save-safety pass the order runs on through every stamped
-- .bak-* copy and the Pokewalker / cloud backups of the slot
-- (SaveSafety.loadBest), and the second return says what was found:
-- "ok" | "recovered" | "unreadable" (files there, none decode) | "none".
local function decodeSlot(fs, version, id)
  local main, bak = slotNames(version, id)
  local data, from, _, state = SaveSafety.loadBest(fs, main, bak,
    function() return SaveData._slotExtras(version, id) end)
  return data, state, from
end

-- One-time legacy consolidation: a pre-slots install has a flat save file
-- (+ .bak) and no saves/<version>/ registry.  Copy both into slot1, verify
-- the copy reads back, then remove the originals and register slot1 as the
-- active slot.  Returns the new slot id, or nil when there is nothing to
-- migrate or the copy could not be verified (originals left in place so no
-- data is ever lost to a failed move).
-- ORPHANED SLOT FILES.  The registry lives in options.lua; a slot file on
-- disk the registry does not list (options.lua lost or rolled back) is a save
-- the launcher would never show and a later createSlot/migration would have
-- written over.  These find such files and pick ids that collide with none.
local MAX_SLOT_PROBE = 64

local function slotFilesExist(fs, version, id)
  local main, bak, tmp = slotNames(version, id)
  return fs.getInfo(main) or fs.getInfo(bak) or fs.getInfo(tmp)
    or fs.getInfo(main .. ".backups") or nil
end

local function slotNumber(id) return tonumber(tostring(id):match("^slot(%d+)$")) end

local function freeSlotId(fs, version, list)
  local taken, n = {}, 0
  for _, id in ipairs(list or {}) do
    taken[id] = true
    local k = slotNumber(id)
    if k and k > n then n = k end
  end
  repeat n = n + 1 until not taken["slot" .. n] and not slotFilesExist(fs, version, "slot" .. n)
  return "slot" .. n
end

-- slot ids with a main/.tmp/.bak file on disk that `list` does not register
local function orphanSlots(fs, version, list)
  local registered, found, out = {}, {}, {}
  for _, id in ipairs(list or {}) do registered[id] = true end
  local function consider(id)
    if id and not registered[id] and not found[id] then
      local main, bak, tmp = slotNames(version, id)
      if fs.getInfo(main) or fs.getInfo(bak) or fs.getInfo(tmp) then
        found[id] = true
        out[#out + 1] = id
      end
    end
  end
  if fs.getDirectoryItems then
    local ok, items = pcall(fs.getDirectoryItems, slotDir(version))
    if ok and type(items) == "table" then
      for _, item in ipairs(items) do consider(item:match("^(slot%d+)%.lua")) end
    end
  end
  for n = 1, MAX_SLOT_PROBE do consider("slot" .. n) end
  table.sort(out, function(a, b) return (slotNumber(a) or 0) < (slotNumber(b) or 0) end)
  return out
end

local function tryMigrateLegacy(version, fs)
  local lmain, lbak, ltmp = legacyNames(version)
  local mainBody = fs.getInfo(lmain) and fs.read(lmain)
  local bakBody = fs.getInfo(lbak) and fs.read(lbak)
  if not (mainBody or bakBody) then return nil end
  -- never "slot1" blindly: a slot file left by a lost registry would be
  -- written over
  local id = freeSlotId(fs, version, {})
  local dmain, dbak = slotNames(version, id)
  ensureParentDir(fs, dmain)
  if mainBody then fs.write(dmain, mainBody) end
  if bakBody then fs.write(dbak, bakBody) end
  -- refuse to delete the originals unless the new slot is loadable (from
  -- the main copy or, failing that, the backup)
  if not decodeSlot(fs, version, id) then return nil end
  remove(fs, lmain)
  remove(fs, lbak)
  remove(fs, ltmp)
  local opts = SaveData.loadOptions(fs)
  opts.saveSlots = opts.saveSlots or {}
  opts.saveSlots[version] = { list = { id }, active = id }
  SaveData.saveOptions(opts, fs)
  return id
end

-- Resolve (once per version per process) which slot in-game saves use: an
-- existing registry wins; otherwise a lazy legacy migration may create
-- slot1; otherwise false, meaning the flat legacy path.
local function ensureVersionSlots(version, fs)
  if slotsChecked[version] then return end
  slotsChecked[version] = true
  if not knownVersion(version) then
    activeSlotCache[version] = false
    return
  end
  local opts = SaveData.loadOptions(fs)
  local reg = opts.saveSlots and opts.saveSlots[version]
  local hasList = reg and type(reg.list) == "table" and #reg.list > 0
  if not hasList and tryMigrateLegacy(version, fs) then
    opts = SaveData.loadOptions(fs)
    reg = opts.saveSlots and opts.saveSlots[version]
  end
  -- slot files on disk the registry has lost track of come back into it
  local okO, orphans = pcall(orphanSlots, fs, version, reg and reg.list)
  if okO and #orphans > 0 then
    reg = type(reg) == "table" and reg or {}
    reg.list = type(reg.list) == "table" and reg.list or {}
    for _, id in ipairs(orphans) do reg.list[#reg.list + 1] = id end
    reg.active = reg.active or reg.list[1]
    opts.saveSlots = opts.saveSlots or {}
    opts.saveSlots[version] = reg
    SaveData.saveOptions(opts, fs)
    Logger.warn("save slots for %s were missing from options.lua; re-registered %s",
      tostring(version), table.concat(orphans, ", "))
  end
  -- NOTHING HERE AT ALL: the save directory itself may have moved (Android
  -- volume change, portable switch, fused vs unfused).  Slots found in another
  -- location are registered here -- read only there; a load copies the save in
  -- (SaveData._slotExtras / load) -- so the launcher does not start fresh.
  if not (reg and type(reg.list) == "table" and #reg.list > 0)
      and type(SaveData._foreignSlots) == "function" then
    local okF, found = pcall(SaveData._foreignSlots, version)
    if okF and #found > 0 then
      reg = { list = found, active = found[1] }
      opts.saveSlots = opts.saveSlots or {}
      opts.saveSlots[version] = reg
      SaveData.saveOptions(opts, fs)
      Logger.warn("no %s saves here; found %s in another storage location",
        tostring(version), table.concat(found, ", "))
    end
  end
  if reg and type(reg.list) == "table" and #reg.list > 0 then
    activeSlotCache[version] = reg.active or reg.list[1]
    return
  end
  activeSlotCache[version] = false
end

-- (body for the forward-declared saveNames.)  Resolves the ACTIVE slot for
-- the version, falling back to the flat legacy names when no slot is in use.
function saveNames(version)
  version = version or GameVersion.get()
  local fs = persistFs(nil)
  ensureVersionSlots(version, fs)
  local slot = activeSlotCache[version]
  if slot then return slotNames(version, slot) end
  return legacyNames(version)
end

-- Pure extraction of the launcher's per-slot summary from a decoded save,
-- factored out so it is unit-testable with no filesystem: the player name
-- (nil for an empty slot) and { badges, timeText, dexCount } -- the same
-- fields the title screen's ContinueInfo derives.  The launcher has no
-- loaded Data, so `version` is what picks Badges' Kanto or Johto+Kanto
-- fallback list; without it a Gold save always summarised as zero badges.
-- HOW LONG THIS SAVE HAS BEEN PLAYED, IN SECONDS, WHATEVER SHAPE IT IS IN.
--
-- Reported from play, on the launcher's save list: "src/core/SaveData.lua:529:
-- bad argument #1 to 'floor' (number expected, got table)", on Gold and Silver
-- and sometimes Crystal.
--
-- This project's convention is that save.playTime is a single float of SECONDS
-- -- Game:update accumulates dt into it and every codec in src/save_convert
-- writes a number -- but saves written by older builds carry the BROKEN-DOWN
-- form the cartridges use, { hours, minutes, seconds, frames }.  Nothing in
-- this tree writes that any more, which is exactly why it went unnoticed: a
-- character made today is fine and one made a year ago is not, so it looks
-- like a version bug rather than an age one.  (mods/gen2recomped-online
-- already carried a `type(save.playTime) == "table"` branch of its own, which
-- is the other half of the evidence that these files are out there.)
--
-- It crashed in the LAUNCHER first because that is the one screen that decodes
-- every slot before you have chosen one: a single old save takes down the list
-- that every other save is on.  Loading it would have crashed a frame later
-- anyway -- Game:update does `(self.save.playTime or 0) + dt` -- so this is a
-- reader that accepts both shapes, and SaveData.validate turns the field into
-- a number once so nothing downstream has to think about it again.
--
-- `vblanks` is Gen 3's name for the same sixtieths Gen 1 and 2 call `frames`.
function SaveData.playSeconds(save)
  local t = type(save) == "table" and save.playTime or nil
  local n = tonumber(t)
  if n then return n end
  if type(t) ~= "table" then return 0 end
  local ticks = tonumber(t.frames) or tonumber(t.vblanks) or 0
  return (tonumber(t.hours) or 0) * 3600
         + (tonumber(t.minutes) or tonumber(t.mins) or 0) * 60
         + (tonumber(t.seconds) or tonumber(t.secs) or 0)
         + ticks / 60
end

function SaveData.slotSummary(save, version)
  if type(save) ~= "table" then return nil, nil end
  local name = save.player and save.player.name or nil
  local dexCount = 0
  for _ in pairs((save.pokedex and save.pokedex.owned) or {}) do
    dexCount = dexCount + 1
  end
  local t = math.floor(SaveData.playSeconds(save))
  local timeText = ("%d:%02d"):format(math.floor(t / 3600),
                                      math.floor(t / 60) % 60)
  return name, {
    badges = Badges.count(nil, save, version),
    timeText = timeText,
    dexCount = dexCount,
  }
end

-- The absolute on-disk path of a slot's save file, for the one caller that
-- cannot go through love.filesystem: the save editor reads and writes with
-- raw io.* so it can also open a file the player dragged in from anywhere.
-- Resolves against the same root persistFs would write to -- the portable
-- game folder when portable mode is on, otherwise LOVE's save directory --
-- so Edit on a launcher save row lands on the file the game actually plays.
-- nil when neither root is available (headless tests with an injected fs).
function SaveData.slotDiskPath(version, slotId)
  version = version or GameVersion.get()
  if not knownVersion(version) or not slotId then return nil end
  local base = SaveData.portableBaseDir()
    or (love and love.filesystem and love.filesystem.getSaveDirectory
        and love.filesystem.getSaveDirectory())
  if not base then return nil end
  local sep = package.config:sub(1, 1)
  local rel = select(1, slotNames(version, slotId))
  return base .. sep .. rel:gsub("/", sep)
end

-- Slots visible to the launcher: every registered slot for a version, each
-- with whether it holds a save and the cheap summary above.  A fresh
-- install with nothing registered returns an empty array; a legacy install
-- is migrated to slot1 first.
function SaveData.listSlots(version)
  version = version or GameVersion.get()
  if not knownVersion(version) then return {} end
  local fs = persistFs(nil)
  ensureVersionSlots(version, fs)
  local opts = SaveData.loadOptions(fs)
  local reg = opts.saveSlots and opts.saveSlots[version]
  local list = (reg and reg.list) or {}
  local out = {}
  for _, id in ipairs(list) do
    -- ONE BAD SLOT MUST NOT TAKE THE LIST DOWN, and a slot whose files do not
    -- decode is SHOWN (unreadable = true, "restore from backup") rather than
    -- passed off as an empty NEW GAME slot that a click would overwrite.
    local okD, save, state, from = pcall(decodeSlot, fs, version, id)
    if not okD then save, state, from = nil, "unreadable", nil end
    local okS, name, meta = pcall(SaveData.slotSummary, save, version)
    if not okS then name, meta = nil, nil end
    local unreadable = save == nil and state == "unreadable"
    out[#out + 1] = { id = id, exists = save ~= nil, name = name, meta = meta,
                      label = reg.names and reg.names[id] or nil,
                      unreadable = unreadable or nil,
                      recoveredFrom = from }
  end
  return out
end

-- Give a registered slot a custom label (#205: "a way to name save slots so
-- you can see that in the launcher").  The label lives in the options
-- registry next to list/active, never in the save file itself, so renaming
-- needs no save rewrite and an empty slot can be labeled too.  The label is
-- trimmed; an empty (or whitespace-only) one clears it.  Returns true, or
-- false + an error string when the id is not registered.
function SaveData.renameSlot(version, slotId, name)
  version = version or GameVersion.get()
  if not knownVersion(version) then return false, "unknown version" end
  if type(slotId) ~= "string" or slotId == "" then
    return false, "missing slot id"
  end
  local fs = persistFs(nil)
  local opts = SaveData.loadOptions(fs)
  opts.saveSlots = opts.saveSlots or {}
  local reg = opts.saveSlots[version]
  if not reg or not reg.list then return false, "slot not registered" end
  local found = false
  for _, id in ipairs(reg.list) do
    if id == slotId then found = true break end
  end
  if not found then return false, "slot not registered" end
  local label = type(name) == "string" and name:match("^%s*(.-)%s*$") or nil
  if label == "" then label = nil end
  reg.names = reg.names or {}
  reg.names[slotId] = label
  if next(reg.names) == nil then reg.names = nil end
  opts.saveSlots[version] = reg
  SaveData.saveOptions(opts, fs)
  return true
end

-- Point the active slot at slotId (registering it if new) and persist the
-- choice to options.lua; also update the process-global cache so the very
-- next save/load lands in the chosen slot.
function SaveData.setActiveSlot(version, slotId)
  version = version or GameVersion.get()
  if not knownVersion(version) then return nil end
  local fs = persistFs(nil)
  local opts = SaveData.loadOptions(fs)
  opts.saveSlots = opts.saveSlots or {}
  local reg = opts.saveSlots[version] or { list = {}, active = nil }
  local found = false
  for _, id in ipairs(reg.list) do
    if id == slotId then found = true break end
  end
  if not found then reg.list[#reg.list + 1] = slotId end
  reg.active = slotId
  opts.saveSlots[version] = reg
  SaveData.saveOptions(opts, fs)
  slotsChecked[version] = true
  activeSlotCache[version] = slotId
  return slotId
end

-- Register a new empty slot for the version and return its id.  Does NOT
-- write a save file and does NOT change the active slot: an empty slot
-- means the title screen offers NEW GAME only.  Ids are "slot%d+",
-- allocated one past the highest existing number so a reused id can never
-- collide with a lingering file.
function SaveData.createSlot(version)
  version = version or GameVersion.get()
  if not knownVersion(version) then return nil end
  local fs = persistFs(nil)
  ensureVersionSlots(version, fs)
  local opts = SaveData.loadOptions(fs)
  opts.saveSlots = opts.saveSlots or {}
  local reg = opts.saveSlots[version] or { list = {}, active = nil }
  -- past every registered id AND every slot file on disk, so a file left by
  -- a lost registry (or a deleted slot's backups) is never written over
  local id = freeSlotId(fs, version, reg.list)
  reg.list[#reg.list + 1] = id
  opts.saveSlots[version] = reg
  SaveData.saveOptions(opts, fs)
  return id
end

-- The active slot id in use for a version (resolved once per process like
-- saveNames does), or nil when none is registered and the flat legacy path is
-- in use.  Public so the launcher's save Import/Export glue can name an export
-- after the slot it came from without reaching into the private cache.
function SaveData.activeSlot(version)
  version = version or GameVersion.get()
  if not knownVersion(version) then return nil end
  local fs = persistFs(nil)
  ensureVersionSlots(version, fs)
  return activeSlotCache[version] or nil
end

-- Write saveTable into an existing slot's file (SaveSerializer.encode), through
-- the same fs seam every other save/load call uses (so portable mode keeps
-- working) and the same .tmp-witness / .bak recovery discipline SaveData.save
-- uses for the flat path.  Used by the launcher's save-import glue, which has
-- already registered the slot via createSlot but written no bytes yet; unlike
-- SaveData.save this targets a specific slot and never rebuilds meta or touches
-- options.  Returns true, or false + an error string on a failed write.
function SaveData.writeSlot(version, slotId, saveTable)
  version = version or GameVersion.get()
  if not knownVersion(version) then return false, "unknown version" end
  if type(slotId) ~= "string" then return false, "missing slot id" end
  if type(saveTable) ~= "table" then return false, "missing save table" end
  local main, bak = slotNames(version, slotId)
  local encoded = SaveSerializer.encode(saveTable)
  local fs = persistFs(nil)
  ensureParentDir(fs, main)
  -- atomic, previous good copy kept (SaveData.commitSave)
  return SaveData.commitSave(fs, main, bak, encoded, saveTable)
end

-- Delete a registered slot: remove its main/.bak/.tmp files, drop it from the
-- options registry, and if it was active point active at another remaining
-- slot (or clear active when the list is empty).  Returns true, or false +
-- an error string when the id is unknown / not registered.
function SaveData.deleteSlot(version, slotId)
  version = version or GameVersion.get()
  if not knownVersion(version) then return false, "unknown version" end
  if type(slotId) ~= "string" or slotId == "" then
    return false, "missing slot id"
  end
  local fs = persistFs(nil)
  ensureVersionSlots(version, fs)
  local opts = SaveData.loadOptions(fs)
  opts.saveSlots = opts.saveSlots or {}
  local reg = opts.saveSlots[version]
  if not reg or not reg.list then return false, "slot not registered" end
  local found, idx = false, nil
  for i, id in ipairs(reg.list) do
    if id == slotId then found = true; idx = i; break end
  end
  if not found then return false, "slot not registered" end

  -- NOT ERASED: moved to saves/<version>/deleted/, so a slot deleted by
  -- mistake (or one that only looked empty) can still be brought back with
  -- Tools -> Restore a Save.  A file whose copy did not verify stays put.
  local main, bak, tmp = slotNames(version, slotId)
  local trash = slotDir(version) .. "/deleted/" .. slotId .. "-" .. SaveSafety.stamp()
  ensureParentDir(fs, trash .. ".lua")
  for _, pair in ipairs({ { main, ".lua" }, { bak, ".lua.bak" }, { tmp, ".lua.tmp" } }) do
    local bytes = SaveSafety.read(fs, pair[1])
    if bytes then
      fs.write(trash .. pair[2], bytes)
      if SaveSafety.read(fs, trash .. pair[2]) == bytes then remove(fs, pair[1]) end
    end
  end

  table.remove(reg.list, idx)
  if reg.names then reg.names[slotId] = nil end
  if reg.active == slotId then
    reg.active = reg.list[1]  -- may be nil when the list is now empty
  end
  opts.saveSlots[version] = reg
  SaveData.saveOptions(opts, fs)
  slotsChecked[version] = true
  activeSlotCache[version] = reg.active or false
  return true
end

-- Test seam: drop the process-global slot cache so a suite can exercise
-- migration/resolution against a freshly injected filesystem.  Unused by
-- the game, which resolves each version exactly once per boot.
function SaveData.resetSlotState()
  for k in pairs(activeSlotCache) do activeSlotCache[k] = nil end
  for k in pairs(slotsChecked) do slotsChecked[k] = nil end
end

-- ------- meta

-- the version/engine/mod-set stamp every v2 save carries; mods is the
-- loaded list sorted by id and is the ground truth for the load-time
-- mod-set diff.  A nil mods list keeps the previous stamp's set so a
-- headless writer (the save editor) never wipes it.
function SaveData.buildMeta(mods, previous)
  local list
  if mods ~= nil then
    list = {}
    for _, mod in ipairs(mods) do
      list[#list + 1] = { id = mod.id, version = mod.version, api = mod.api }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
  else
    list = (type(previous) == "table" and previous.mods) or {}
  end
  return {
    format = Version.saveFormat,
    engine = Version.engine,
    savedAt = os.time(),
    mods = list,
  }
end

-- {added, removed, changed} between the set that wrote the save
-- (meta.mods) and the active loaded set; all three empty on a vanilla
-- load under vanilla
function SaveData.modsDiff(save, activeMods)
  local stored = {}
  for _, entry in ipairs((save.meta and save.meta.mods) or {}) do
    if type(entry) == "table" and entry.id then
      stored[entry.id] = entry.version or ""
    end
  end
  local diff = { added = {}, removed = {}, changed = {} }
  for _, mod in ipairs(activeMods or {}) do
    local was = stored[mod.id]
    if was == nil then
      diff.added[#diff.added + 1] = mod.id
    elseif was ~= mod.version then
      diff.changed[#diff.changed + 1] = { id = mod.id, from = was, to = mod.version }
    end
    stored[mod.id] = nil
  end
  for id in pairs(stored) do diff.removed[#diff.removed + 1] = id end
  table.sort(diff.added)
  table.sort(diff.removed)
  table.sort(diff.changed, function(a, b) return a.id < b.id end)
  return diff
end

-- one-line load notice for a non-empty diff ("This save was made with
-- 2 mods; 1 is no longer active"); nil when empty so a vanilla load
-- stays silent
function SaveData.modsDiffNotice(diff, meta)
  if type(diff) ~= "table" then return nil end
  local removed = #(diff.removed or {})
  local changed = #(diff.changed or {})
  local added = #(diff.added or {})
  if removed == 0 and changed == 0 and added == 0 then return nil end
  local wrote = #((type(meta) == "table" and meta.mods) or {})
  local parts = {}
  if removed > 0 then
    parts[#parts + 1] = removed .. (removed == 1 and " is" or " are") .. " no longer active"
  end
  if changed > 0 then
    parts[#parts + 1] = changed .. " changed version"
  end
  if added > 0 then
    parts[#parts + 1] = added .. " newly active"
  end
  return ("This save was made with %d mod%s; %s"):format(
    wrote, wrote == 1 and "" or "s", table.concat(parts, ", "))
end

-- ------- migrations

-- Ordered engine steps keyed on meta.format, each reproducing the inline
-- migration it replaced; a save already at the current format skips them
-- all.  Mod chains (recorded by Loader from mod.migrations:add) replay
-- against the version stored in meta.mods, in semver order, before the
-- validation pass -- so a mod repairs its own data instead of watching
-- it get quarantined.
local coreMigrations = {}

function SaveData.addCoreMigration(fromFormat, fn)
  coreMigrations[#coreMigrations + 1] =
    { from = fromFormat, seq = #coreMigrations + 1, fn = fn }
end

local function storedVersion(save, modId)
  for _, entry in ipairs((save.meta and save.meta.mods) or {}) do
    if type(entry) == "table" and entry.id == modId then
      return entry.version
    end
  end
  return nil
end

local function semverLt(a, b)
  local order = Semver.compare(a, b)
  return order ~= nil and order < 0
end

function SaveData.runMigrations(save, modChains, activeMods)
  table.sort(coreMigrations, function(a, b)
    if a.from ~= b.from then return a.from < b.from end
    return a.seq < b.seq
  end)
  -- every step whose from-format the save has not passed yet runs, in
  -- (from, registration) order; a save at the current format runs none
  local fmt = (save.meta and save.meta.format) or 1
  for _, m in ipairs(coreMigrations) do
    if m.from >= fmt then m.fn(save) end
  end
  -- a save that predates meta records an empty mod set: an old vanilla
  -- save becomes a v2 vanilla save
  save.meta = save.meta or { mods = {} }
  save.meta.format = Version.saveFormat
  for _, active in ipairs(activeMods or {}) do
    local modSave = save.modData and save.modData[active.id]
    local recorded = modChains and modChains[active.id]
    if modSave and recorded then
      local chain = {}
      for _, m in ipairs(recorded) do chain[#chain + 1] = m end
      table.sort(chain, function(a, b) return semverLt(a.since, b.since) end)
      local stored = storedVersion(save, active.id) or "0.0.0"
      for _, m in ipairs(chain) do
        if semverLt(stored, m.since) and not semverLt(active.version, m.since) then
          -- a throwing migration is skipped, not fatal: it would otherwise
          -- re-raise on every load and lock the player out of the save
          local ok, err = pcall(m.apply, modSave, save)
          if not ok then
            Logger.error("[%s] migration %s: %s -- skipped",
              active.id, tostring(m.since), tostring(err))
            break
          end
        end
      end
    end
  end
  return save
end

-- saves from before the trainer ID existed: backfill once on load
-- (like the OT backfill for old saves)
SaveData.addCoreMigration(1, function(save)
  if save.player and not save.player.id then
    save.player.id = math.random(0, 65535)
  end
end)

-- saves from before EVENT_BEAT_ROUTE12/16_SNORLAX existed: the object
-- was already hidden (Snorlax beaten) but the flag was never added,
-- and it can never be set again since the hidden object is
-- unreachable -- backfill it from the toggle so it isn't stuck forever
SaveData.addCoreMigration(1, function(save)
  if save.objectToggles and save.flags then
    local snorlaxRoutes = {
      { map = "ROUTE_12", obj = "ROUTE12_SNORLAX", flag = "EVENT_BEAT_ROUTE12_SNORLAX" },
      { map = "ROUTE_16", obj = "ROUTE16_SNORLAX", flag = "EVENT_BEAT_ROUTE16_SNORLAX" },
    }
    for _, r in ipairs(snorlaxRoutes) do
      local toggles = save.objectToggles[r.map]
      if toggles and toggles[r.obj] == false and not save.flags[r.flag] then
        save.flags[r.flag] = true
      end
    end
  end
end)

-- Migrate options that still live inside an old save.lua into the
-- standalone options file (once); load always re-attaches options.lua
-- afterwards either way
SaveData.addCoreMigration(1, function(save)
  if type(save.options) == "table"
      and not persistFs(nil).getInfo(OPTIONS_FILENAME) then
    SaveData.saveOptions(save.options)
  end
end)

-- settle the box shape (single `box` list -> 12 boxes) before the
-- validation pass walks it; Boxes keeps the lazy ensure for play paths
SaveData.addCoreMigration(1, function(save)
  Boxes.ensure(save)
end)

-- game version (Red vs Blue) prep: saves written before Blue support
-- existed carry no `version` tag, and Red is the only game that ever
-- shipped, so default every untagged save to Red.  from=2 so it catches
-- every pre-bump save (format 1 and 2) and is skipped once re-stamped to
-- the current format.
SaveData.addCoreMigration(2, function(save)
  if not save.version then
    save.version = "red"
  end
end)

-- #131 / follow-up to #50: Game Corner poster grunt used to stay on the
-- floor after defeat (defeatedTrainers only).  The #50 script now hides
-- him via objectToggles, but saves that already beat him never got the
-- toggle -- he still blocks the hideout switch.  from=3 so every pre-4
-- save reconciles once, then is skipped after re-stamp.
SaveData.addCoreMigration(3, function(save)
  local defeated = save.defeatedTrainers
  if not defeated or not defeated["GAME_CORNER_obj_11"] then return end
  save.objectToggles = save.objectToggles or {}
  local mapToggles = save.objectToggles.GAME_CORNER
  if not mapToggles then
    mapToggles = {}
    save.objectToggles.GAME_CORNER = mapToggles
  end
  if mapToggles.GAMECORNER_ROCKET ~= false then
    mapToggles.GAMECORNER_ROCKET = false
  end
end)

-- ------- write

-- Game progress only; options are written separately via saveOptions.
-- If `data.options` is present it is also flushed to options.lua so an
-- F1 / in-game save keeps the live settings in sync, then stripped from
-- the game file.  mods (when given) refreshes the meta stamp; the write
-- itself rolls the last good save into .bak and stages the new bytes as
-- a .tmp witness before the swap, so a crash mid-write is recoverable.
-- Is there already a save file where the next save will land?
--
-- Sinnoh's save script needs this: the cartridge's `SaveData_DataExists`
-- decides whether the player is asked "There is already a saved file.  Is it
-- OK to overwrite it?", which the FIRST save into a file skips and every
-- later one shows (src/scrcmd.c ScrCmd_CheckSaveType).  The engine's answer is
-- the same question about the active slot, resolved through the same
-- saveNames/persistFs pair SaveData.save is about to write through, so the
-- file it reports on is the file that is about to be overwritten.
--
-- nil rather than false when it cannot be asked -- an unknown version, or no
-- filesystem at all under a headless check -- so a caller can tell "there is
-- no file" from "there was no way to look".
function SaveData.saveFileExists(version)
  version = version or GameVersion.get()
  if not knownVersion(version) then return nil end
  pcall(SaveData.ensureRecovered, version)
  local FILENAME = saveNames(version)
  local fs = persistFs(nil)
  if not (fs and fs.getInfo and FILENAME) then return nil end
  local ok, info = pcall(fs.getInfo, FILENAME)
  if not ok then return nil end
  return info ~= nil
end

-- ------- the safety layer (src/core/SaveSafety.lua, docs/save-safety.md)

-- What this process last read from / wrote to each save file, so a write can
-- tell that something else (the launcher's Pokewalker in another window, a
-- cloud sync) changed the file under a running game.
local knownBytes = {}
local loadedWalkerKeys = {}
-- name -> where a pre-load recovery (SaveData.ensureRecovered) found the save,
-- handed to the next load so the player is told
local lastRecovery = {}
local recoveryChecked = {}

-- test seam (tools/save_safety_check): forget what this process has read,
-- as a fresh launch would
function SaveData._resetSafetyState()
  for _, t in ipairs({ knownBytes, loadedWalkerKeys, lastRecovery, recoveryChecked }) do
    for k in pairs(t) do t[k] = nil end
  end
end

local function readReal(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local s = f:read("*a")
  f:close()
  return s
end

-- OTHER PLACES THIS GAME'S SAVES CAN BE.  The save directory is not one
-- fixed folder: portable mode moves it next to the executable, the fused and
-- unfused desktop builds use different %APPDATA% folders, the old identity
-- was "pokemon-love2d", and on Android getExternalFilesDir can name a
-- different volume (phone / adopted SD / internal fallback) from one run to
-- the next.  A save in one of those places is not gone, so loads and the
-- restore tool look there too -- read-only, never writing anywhere but the
-- current save directory.
local otherLocCache
function SaveData.otherLocations()
  if otherLocCache then return otherLocCache end
  local roots, seen = {}, {}
  local function norm(p) return (p:gsub("\\", "/"):gsub("/+$", ""):lower()) end
  local function add(p)
    if type(p) ~= "string" or p == "" then return end
    local k = norm(p)
    if seen[k] then return end
    seen[k] = true
    roots[#roots + 1] = p
  end
  if not (love and love.filesystem) then otherLocCache = roots; return roots end
  local saveDir = love.filesystem.getSaveDirectory and love.filesystem.getSaveDirectory() or nil
  local current = SaveData.portableBaseDir() or saveDir
  if current then seen[norm(current)] = true end
  if SaveData.portableBaseDir() then add(saveDir) else
    for _, base in ipairs(SaveData.gameFolders()) do add(base) end
  end
  local ident = saveDir and saveDir:gsub("\\", "/"):match("([^/]+)/*$") or "Gen2Recomp"
  local idents = { ident, "Gen2Recomp", "pokemon-love2d" }
  local osName = love.system and love.system.getOS and love.system.getOS() or ""
  local home = os.getenv("HOME") or os.getenv("USERPROFILE") or ""
  for _, id in ipairs(idents) do
    if osName == "Windows" then
      local appdata = os.getenv("APPDATA")
      if appdata then add(appdata .. "/LOVE/" .. id); add(appdata .. "/" .. id) end
    elseif osName == "Linux" then
      local xdg = os.getenv("XDG_DATA_HOME") or (home .. "/.local/share")
      add(xdg .. "/love/" .. id); add(xdg .. "/" .. id)
    elseif osName == "OS X" then
      add(home .. "/Library/Application Support/LOVE/" .. id)
      add(home .. "/Library/Application Support/" .. id)
    end
  end
  if osName == "Android" and saveDir then
    local pkg = saveDir:match("/Android/data/([^/]+)/") or saveDir:match("/data/data/([^/]+)/")
      or saveDir:match("/data/user/%d+/([^/]+)/")
    for _, row in ipairs(SaveData.externalDataDirs()) do
      local files = row.path:match("^(.*)/gamedata$") or row.path
      add(files .. "/save/" .. ident)
    end
    if pkg then
      add("/storage/emulated/0/Android/data/" .. pkg .. "/files/save/" .. ident)
      add("/sdcard/Android/data/" .. pkg .. "/files/save/" .. ident)
      add("/data/data/" .. pkg .. "/files/save/" .. ident)
      add("/data/user/0/" .. pkg .. "/files/save/" .. ident)
    end
  end
  add(SaveData.dataDirSetting and SaveData.dataDirSetting() or nil)
  otherLocCache = roots
  return roots
end

-- test seam: tools/save_safety_check points this at scratch folders
function SaveData._setOtherLocations(list) otherLocCache = list end

-- the same relative file in every other location, as fallback candidates
local function elsewhere(rel, out)
  for _, root in ipairs(SaveData.otherLocations()) do
    for _, suffix in ipairs({ "", ".tmp", ".bak" }) do
      local path = root .. "/" .. rel .. suffix
      out[#out + 1] = { label = "copy in " .. root, path = path,
                        read = function() return readReal(path) end }
    end
  end
  return out
end

-- slot ids with a readable save in another storage location (see
-- ensureVersionSlots: only asked when this location has none for the game)
function SaveData._foreignSlots(version)
  local out = {}
  if not knownVersion(version) then return out end
  for n = 1, 16 do
    local id = "slot" .. n
    local rel = (slotNames(version, id))
    local hit = false
    for _, root in ipairs(SaveData.otherLocations()) do
      for _, suffix in ipairs({ "", ".tmp", ".bak" }) do
        if not hit and SaveSafety.decodeSave(readReal(root .. "/" .. rel .. suffix)) then hit = true end
      end
    end
    if hit then out[#out + 1] = id end
  end
  return out
end

-- Copies of a slot kept outside its own folder, newest first: the Pokewalker's
-- pre-write backups, the cloud sync's local backups (both always in LOVE's
-- save directory), then the same slot in another storage location.
function SaveData._slotExtras(version, slotId)
  local out = {}
  local lfs = love and love.filesystem
  if lfs and lfs.getDirectoryItems and type(slotId) == "string" then
    local dir = "pokewalker_backups/" .. version
    local ok, items = pcall(lfs.getDirectoryItems, dir)
    local rows = {}
    if ok and type(items) == "table" then
      for _, item in ipairs(items) do
        if item:sub(1, #slotId + 1) == slotId .. "_" and item:match("%.lua$") then rows[#rows + 1] = item end
      end
    end
    table.sort(rows, function(a, b) return a > b end)
    for _, item in ipairs(rows) do
      local file = dir .. "/" .. item
      local y, mo, d, h, mi, se = item:match("_(%d%d%d%d)(%d%d)(%d%d)_(%d%d)(%d%d)(%d%d)_")
      out[#out + 1] = { label = "pokewalker backup", file = file,
        t = y and os.time({ year = tonumber(y), month = tonumber(mo), day = tonumber(d),
                            hour = tonumber(h), min = tonumber(mi), sec = tonumber(se) }) or nil,
        read = function() return SaveSafety.read(lfs, file) end }
    end
    for i = 1, 2 do
      local file = ("cloud_backups/%s/%s.%d.lua"):format(version, slotId, i)
      out[#out + 1] = { label = "cloud sync backup " .. i, file = file,
                        read = function() return SaveSafety.read(lfs, file) end }
    end
  end
  if knownVersion(version) and type(slotId) == "string" then
    elsewhere((slotNames(version, slotId)), out)
  end
  return out
end

local function legacyExtras(version)
  if not knownVersion(version) then return {} end
  return elsewhere((legacyNames(version)), {})
end

local function extrasFor(version)
  return function()
    local slot = activeSlotCache[version]
    if slot then return SaveData._slotExtras(version, slot) end
    return legacyExtras(version)
  end
end

-- ------- in use by a running game
--
-- <save>.open says which process has the save loaded and when it last
-- touched it.  The launcher's Pokewalker / event writers refuse a slot that a
-- game in ANOTHER window has open (a write there would be overwritten by that
-- game's next save); the game's own save also merges whatever was delivered
-- meanwhile (SaveSafety.mergeWalker), so the refusal is the first line, not
-- the only one.
SaveData.OPEN_FRESH = 15 * 60
local openMarkers = {}

local function markOpen(fs, name)
  local m = name .. ".open"
  pcall(fs.write, m, SaveSerializer.encode({ session = SaveSafety.session, t = os.time() }))
  openMarkers[m] = fs
end

-- an orderly quit lets go of every marker this process wrote
function SaveData.closeOpen()
  for m, fs in pairs(openMarkers) do
    local t = SaveSafety.decodeAny(SaveSafety.read(fs, m))
    if type(t) == "table" and t.session == SaveSafety.session and fs.remove then pcall(fs.remove, m) end
    openMarkers[m] = nil
  end
end

-- true (+ seconds since it was touched) when a game in another process has
-- this slot open
function SaveData.slotOpenElsewhere(version, slotId)
  if not (knownVersion(version) and type(slotId) == "string") then return false end
  -- a phone runs one copy of the app: a marker there is always left by a
  -- killed process (no love.quit), never by a live game
  local osName = love and love.system and love.system.getOS and love.system.getOS()
  if osName == "Android" or osName == "iOS" then return false end
  local fs = persistFs(nil)
  if not fs then return false end
  local main = slotNames(version, slotId)
  local t = SaveSafety.decodeAny(SaveSafety.read(fs, main .. ".open"))
  if type(t) ~= "table" or t.session == SaveSafety.session then return false end
  local age = os.time() - (tonumber(t.t) or 0)
  if age >= 0 and age < SaveData.OPEN_FRESH then return true, age end
  return false
end

-- ------- write

-- commitSave(fs, main, bak, encoded, live, reencode) -> ok, err
--
-- Every progress write goes through here (SaveData.save, writeSlot):
--   * the file being replaced is snapshotted first when it matters -- a
--     different playthrough replacing it ("replaced"), a file changed on disk
--     since this process read it ("external", and the walker's deliveries in
--     it are merged into `live` first), otherwise the throttled rolling copy;
--   * a main file that is missing while .tmp/.bak hold a save keeps those
--     ("orphan") before anything can rotate them away;
--   * then SaveSafety.atomicWrite (verified .tmp, rename, .bak = previous
--     GOOD copy, an unreadable previous copy kept as .corrupt-<stamp>).
-- `reencode` rebuilds the bytes when a merge changed `live`.
function SaveData.commitSave(fs, main, bak, encoded, live, reencode)
  local prevBytes = SaveSafety.read(fs, main)
  local prev = SaveSafety.decodeSave(prevBytes)
  if not prev then
    for _, f in ipairs({ main .. ".tmp", bak }) do
      local b = SaveSafety.read(fs, f)
      if b and b ~= encoded and SaveSafety.decodeSave(b) then SaveSafety.snapshot(fs, main, b, "orphan") end
    end
  elseif prevBytes ~= encoded then
    if type(live) == "table" and not SaveSafety.samePlaythrough(prev, live) then
      SaveSafety.snapshot(fs, main, prevBytes, "replaced")
      Logger.warn("save: %s held a different playthrough; kept a copy", main)
    elseif knownBytes[main] and knownBytes[main] ~= prevBytes then
      SaveSafety.snapshot(fs, main, prevBytes, "external")
      local n = 0
      if type(live) == "table" then
        n = SaveSafety.mergeWalker(prev, live, loadedWalkerKeys[main])
      end
      if n > 0 and reencode then encoded = reencode() end
      Logger.warn("save: %s changed on disk while the game had it open; kept a copy%s", main,
        n > 0 and (" and carried over " .. n .. " Pokewalker deliveries") or "")
    else
      SaveSafety.snapshot(fs, main, prevBytes)
    end
  end
  local ok, err = SaveSafety.atomicWrite(fs, main, encoded, { bak = bak, decode = SaveSafety.decodeSave })
  if ok then
    knownBytes[main] = encoded
    if type(live) == "table" then loadedWalkerKeys[main] = SaveSafety.walkerKeys(live) end
  end
  return ok, err
end

function SaveData.save(data, mods)
  -- a table that is not a playthrough (a freeze or a crash half-way through
  -- building one) is never written over a save
  if type(data) ~= "table" or type(data.player) ~= "table" then
    Logger.error("save refused: the game state has no player table")
    return false
  end
  -- write to the file matching this save's own version, not just the active
  -- one, so Blue/Yellow playthroughs land in save_blue.lua / save_yellow.lua
  local FILENAME, BACKUP_FILENAME = saveNames(data.version)
  if data.options then
    SaveData.saveOptions(data.options)
  end
  if mods ~= nil or data.meta == nil then
    data.meta = SaveData.buildMeta(mods, data.meta)
  end
  local function encode()
    local gameOnly = {}
    for k, v in pairs(data) do
      if k ~= "options" then gameOnly[k] = v end
    end
    return SaveSerializer.encode(gameOnly)
  end
  local fs = persistFs(nil)
  -- the active slot may live in saves/<version>/, which must exist before
  -- the .tmp/.bak/main writes land (a no-op for the flat legacy path)
  ensureParentDir(fs, FILENAME)
  local ok, err = SaveData.commitSave(fs, FILENAME, BACKUP_FILENAME, encode(), data, encode)
  if not ok then
    Logger.error("save failed: %s", tostring(err))
    return false
  end
  markOpen(fs, FILENAME)
  Logger.info("saved game")
  return true
end

-- ------- read

-- Before anything decides whether a save EXISTS (the title screens'
-- CONTINUE gates, the Sinnoh overwrite prompt), a main file that is missing
-- or unreadable while a good copy survives is put back -- once per file per
-- process -- so no menu offers only NEW GAME over a recoverable save.
function SaveData.ensureRecovered(version)
  version = version or GameVersion.get()
  if not knownVersion(version) then return nil end
  local FILENAME, BACKUP_FILENAME = saveNames(version)
  if recoveryChecked[FILENAME] then return lastRecovery[FILENAME] end
  recoveryChecked[FILENAME] = true
  local fs = persistFs(nil)
  if not fs then return nil end
  local ok, data, from, bytes = pcall(SaveSafety.loadBest, fs, FILENAME, BACKUP_FILENAME, extrasFor(version))
  if ok and data and from then
    ensureParentDir(fs, FILENAME)
    if SaveSafety.atomicWrite(fs, FILENAME, bytes, { bak = BACKUP_FILENAME, decode = SaveSafety.decodeSave }) then
      Logger.warn("%s was missing or unreadable; restored it from the %s copy", FILENAME, tostring(from))
      lastRecovery[FILENAME] = from
    end
  end
  return lastRecovery[FILENAME]
end

-- returns the parsed save plus where it came from ("tmp", "bak",
-- "bak-<stamp>", "pokewalker backup", ...) when the main file was gone or
-- corrupt and another copy was promoted; Game surfaces the recovery on the
-- load report
function SaveData.load(version)
  -- version defaults to the active game (set at boot from the launcher);
  -- an explicit version lets callers/tests load a specific game's save.
  local FILENAME, BACKUP_FILENAME = saveNames(version)
  local v = version or GameVersion.get()
  local fs = persistFs(nil)
  local data, recovered, bytes, state = SaveSafety.loadBest(fs, FILENAME, BACKUP_FILENAME, extrasFor(v))
  if data and recovered then
    Logger.warn("save.lua %s; recovered from %s copy",
      fs.getInfo(FILENAME) and "corrupt" or "missing", recovered)
    -- the unreadable main file is kept aside (.corrupt-<stamp>) by the write
    ensureParentDir(fs, FILENAME)
    SaveSafety.atomicWrite(fs, FILENAME, bytes, { bak = BACKUP_FILENAME, decode = SaveSafety.decodeSave })
  end
  if not data then
    if state == "unreadable" then
      Logger.error("load failed: no copy of %s decodes (every file kept; see Tools -> Restore a Save)",
        FILENAME)
    end
    return nil
  end
  recovered = recovered or lastRecovery[FILENAME]
  lastRecovery[FILENAME] = nil
  knownBytes[FILENAME] = SaveSafety.read(fs, FILENAME) or bytes
  loadedWalkerKeys[FILENAME] = SaveSafety.walkerKeys(data)
  markOpen(fs, FILENAME)
  SaveData.runMigrations(data)
  data.options = SaveData.optionsFor(version)
  Logger.info("loaded save")
  return data, recovered
end

-- ------- recovery tool (launcher Tools -> Restore a Save)

local function fileTime(fs, file)
  local ok, info = pcall(fs.getInfo, file)
  return ok and info and tonumber(info.modtime) or nil
end

-- Every copy of a slot there is: the current file first, then the rest
-- newest first.  Rows: { label, when (os.time or nil), ok (decodes as a
-- save), name, meta, size, current, read = fn -> bytes }.
function SaveData.slotBackups(version, slotId)
  if not (knownVersion(version) and type(slotId) == "string") then return {} end
  local fs = persistFs(nil)
  local main, bak, tmp = slotNames(version, slotId)
  local rows, seenBytes = {}, {}
  local current
  local function add(label, read, when, isCurrent)
    local okR, bytes = pcall(read)
    if not (okR and type(bytes) == "string" and bytes ~= "") then return end
    if seenBytes[bytes] then return end
    seenBytes[bytes] = true
    local save = SaveSafety.decodeSave(bytes)
    local okS, name, meta = pcall(SaveData.slotSummary, save, version)
    local row = { label = label, when = when, ok = save ~= nil, current = isCurrent or nil,
                  name = okS and name or nil, meta = okS and meta or nil, size = #bytes,
                  read = function() return bytes end }
    if isCurrent then current = row else rows[#rows + 1] = row end
  end
  local function fsRead(f) return function() return SaveSafety.read(fs, f) end end
  add("current file", fsRead(main), fileTime(fs, main), true)
  add("staged write (.tmp)", fsRead(tmp), fileTime(fs, tmp))
  add("previous save (.bak)", fsRead(bak), fileTime(fs, bak))
  for _, e in ipairs(SaveSafety.listBackups(fs, main)) do
    add(e.tag and ("snapshot (" .. e.tag .. ")") or "snapshot", fsRead(e.file), e.t)
  end
  if fs.getDirectoryItems then
    local okD, items = pcall(fs.getDirectoryItems, slotDir(version))
    for _, item in ipairs(okD and items or {}) do
      if item:sub(1, #slotId + 13) == slotId .. ".lua.corrupt-" then
        local f = slotDir(version) .. "/" .. item
        add("unreadable copy kept aside", fsRead(f), SaveSafety.stampTime(item))
      end
    end
  end
  for _, e in ipairs(SaveData._slotExtras(version, slotId)) do
    add(e.label, e.read, e.t or (e.file and love and love.filesystem and fileTime(love.filesystem, e.file)))
  end
  table.sort(rows, function(a, b) return (a.when or 0) > (b.when or 0) end)
  if current then table.insert(rows, 1, current) end
  return rows
end

-- Put one of slotBackups' rows back as the slot's save.  The current file is
-- snapshotted first ("prerestore"), so a restore can itself be undone.
function SaveData.restoreBackup(version, slotId, row)
  if not (knownVersion(version) and type(slotId) == "string") then return false, "unknown slot" end
  if type(row) ~= "table" or type(row.read) ~= "function" then return false, "no copy chosen" end
  local bytes = row.read()
  if not SaveSafety.decodeSave(bytes) then return false, "that copy does not read as a save" end
  local fs = persistFs(nil)
  local main, bak = slotNames(version, slotId)
  ensureParentDir(fs, main)
  local cur = SaveSafety.read(fs, main)
  if cur and cur ~= bytes then SaveSafety.snapshot(fs, main, cur, "prerestore") end
  local ok, err = SaveSafety.atomicWrite(fs, main, bytes, { bak = bak, decode = SaveSafety.decodeSave })
  knownBytes[main] = nil
  recoveryChecked[main] = nil
  return ok, err
end

-- Slots deleted from the launcher (deleteSlot moves them to
-- saves/<version>/deleted/), newest first, as slotBackups-style rows.
function SaveData.deletedSlots(version)
  if not knownVersion(version) then return {} end
  local fs = persistFs(nil)
  local dir = slotDir(version) .. "/deleted"
  local rows = {}
  if not fs.getDirectoryItems then return rows end
  local ok, items = pcall(fs.getDirectoryItems, dir)
  for _, item in ipairs(ok and items or {}) do
    local slot, stamp = item:match("^(slot%d+)%-(%d+%-%d+)%.lua$")
    if slot then
      local f = dir .. "/" .. item
      local bytes = SaveSafety.read(fs, f)
      if not SaveSafety.decodeSave(bytes) then bytes = SaveSafety.read(fs, f .. ".bak") end
      local save = SaveSafety.decodeSave(bytes)
      local okS, name, meta = pcall(SaveData.slotSummary, save, version)
      rows[#rows + 1] = { label = "deleted " .. slot, slot = slot, when = SaveSafety.stampTime(stamp),
        ok = save ~= nil, name = okS and name or nil, meta = okS and meta or nil,
        size = bytes and #bytes or 0, read = function() return bytes end }
    end
  end
  table.sort(rows, function(a, b) return (a.when or 0) > (b.when or 0) end)
  return rows
end

-- Bring a deleted slot (or any row) back as a NEW slot; returns its id.
function SaveData.restoreAsNewSlot(version, row, label)
  if type(row) ~= "table" or type(row.read) ~= "function" then return nil, "no copy chosen" end
  local save = SaveSafety.decodeSave(row.read())
  if not save then return nil, "that copy does not read as a save" end
  local id = SaveData.createSlot(version)
  if not id then return nil, "could not make a slot" end
  local ok, err = SaveData.writeSlot(version, id, save)
  if not ok then return nil, err end
  if label then pcall(SaveData.renameSlot, version, id, label) end
  return id
end

-- ------- validation and quarantine

local function known(tbl, id)
  return id ~= nil and type(tbl) == "table" and tbl[id] ~= nil
end

-- only out-of-range values move; a vanilla save passes through untouched
local function clamp(n, lo, hi, fallback)
  if type(n) ~= "number" then return fallback end
  if n < lo then return lo end
  if n > hi then return hi end
  return n
end

local function ensureOrphaned(save)
  if not save.orphaned then
    save.orphaned = { mons = {}, items = {} }
  end
  save.orphaned.mons = save.orphaned.mons or {}
  save.orphaned.items = save.orphaned.items or {}
  return save.orphaned
end

-- quarantined ids whose content reappeared (mod re-enabled) go home
-- again: mons through the PC deposit, items through the bag with the PC
-- as overflow
local function reclaim(save, data, report)
  local orphaned = save.orphaned
  if not orphaned then return end
  for i = #(orphaned.mons or {}), 1, -1 do
    local mon = orphaned.mons[i]
    if type(mon) == "table" and known(data.pokemon, mon.species) then
      table.remove(orphaned.mons, i)
      local box = Boxes.deposit(save, mon)
      if box then
        report.restoredMons[#report.restoredMons + 1] =
          { species = mon.species, box = box }
      else
        -- every box full: stays quarantined rather than vanishing
        table.insert(orphaned.mons, i, mon)
      end
    end
  end
  for i = #(orphaned.items or {}), 1, -1 do
    local entry = orphaned.items[i]
    if type(entry) == "table" and known(data.items, entry.id) then
      table.remove(orphaned.items, i)
      if entry.from == "pcItems" or type(save.inventory) ~= "table"
          or not Bag.add(save, entry.id, entry.count or 1, data) then
        save.pcItems = save.pcItems or {}
        save.pcItems[entry.id] = (save.pcItems[entry.id] or 0) + (entry.count or 1)
      end
      report.restoredItems[#report.restoredItems + 1] =
        { id = entry.id, count = entry.count or 1 }
    end
  end
end

-- mirrors Protocol.unpackMon's clamp discipline for the fields play
-- indexes; the level floor widens to 1 because a freshly caught level-1
-- mon can legitimately sit in a save
local function scrubKnownMon(mon, data)
  if type(mon.dvs) == "table" then
    for stat, v in pairs(mon.dvs) do mon.dvs[stat] = clamp(v, 0, 15, 0) end
  end
  if type(mon.statExp) == "table" then
    for stat, v in pairs(mon.statExp) do mon.statExp[stat] = clamp(v, 0, 65535, 0) end
  end
  mon.level = clamp(mon.level, 1, 100, 1)
  -- Box mons imported from a real .sav carry NO stat block: box_struct stops
  -- before MON_LEVEL/MON_STATS, so src/save_convert/GenSave.lua decodeMon
  -- only fills `stats` for party slots.  Every HP-bar draw then nil-indexes
  -- mon.stats: the status screen opened in the box (#233) and the party list
  -- after withdrawing one (#304).  The original derives them on demand
  -- (status_screen.asm:66-76, add_mon.asm _MoveMon); deriving once here means
  -- every later reader (menus, battle, items, SGB bar zones, the link
  -- fingerprint) sees a party-shaped mon.  Runs after the level clamp above
  -- so the derived stats use a sane level.  A save that already has stats is
  -- untouched.
  Stats.ensure(data.pokemon and data.pokemon[mon.species], mon)
  local moves = mon.moves
  if type(moves) ~= "table" then return end
  local hadMoves = #moves > 0
  for j = #moves, 1, -1 do
    local slot = moves[j]
    local id = type(slot) == "table" and slot.id or slot
    if not known(data.moves, id) then table.remove(moves, j) end
  end
  while #moves > 4 do table.remove(moves) end
  if hadMoves and #moves == 0 then
    -- data-driven repair so a total conversion without TACKLE still heals
    local fallback = (data.constants and data.constants.fallbackMove) or "TACKLE"
    local def = data.moves and data.moves[fallback]
    if def then
      moves[1] = { id = fallback, pp = def.pp }
    end
  end
end

-- `slots` is how many places the list HAS, not how many are filled: a party is
-- a dense six, but an imported Gen 3 box keeps every mon at the slot the
-- cartridge put it in and `#` on a table like that answers 0 rather than
-- "twenty-nine".  Walked by length, every mon past the first hole went
-- unchecked -- never validated against the dataset, never repaired by
-- scrubKnownMon -- which is how a box full of Pokemon could arrive with moves
-- the engine cannot run.  A missing slot is skipped rather than closed up,
-- because closing it would move somebody.
local function scrubMonList(list, where, save, data, report, slots)
  if type(list) ~= "table" then return end
  for i = math.max(slots or 0, #list), 1, -1 do
    local mon = list[i]
    if mon ~= nil
       and (type(mon) ~= "table" or not known(data.pokemon, mon.species)) then
      list[i] = nil
      ensureOrphaned(save)
      save.orphaned.mons[#save.orphaned.mons + 1] = mon
      report.lostMons[#report.lostMons + 1] =
        { species = type(mon) == "table" and mon.species or nil, from = where }
    elseif mon ~= nil then
      scrubKnownMon(mon, data)
    end
  end
end

local function scrubItemMap(map, where, save, data, report)
  local badges={}
  if where=='inventory' and data.isGen4Cache then
    for _,entry in ipairs(Badges.list(data)) do badges[Badges.itemFor(entry)]=entry end
  end
  if type(map) ~= "table" then return end
  for id, count in pairs(map) do
    if badges[id] then
      Badges.set(save,badges[id],true,'platinum')
    elseif not known(data.items, id) then
      map[id] = nil
      ensureOrphaned(save)
      save.orphaned.items[#save.orphaned.items + 1] =
        { id = id, count = count, from = where }
      report.lostItems[#report.lostItems + 1] =
        { id = id, count = count, from = where }
    end
  end
end

local function scrubMaps(save, data, report)
  local boot = (data.field and data.field.boot) or {}
  local spawn = { map = boot.startMap or "REDS_HOUSE_2F",
                  x = boot.startX or 3, y = boot.startY or 6 }
  -- heal point first, so the player fallback below always lands somewhere
  -- valid; boot's heal cell (threaded from field.boot) is the last resort
  if save.lastHeal and not known(data.maps, save.lastHeal.map) then
    local heal = boot.lastHeal or spawn
    report.remappedMaps[#report.remappedMaps + 1] =
      { id = save.lastHeal.map, to = heal.map, field = "lastHeal" }
    save.lastHeal = { map = heal.map, x = heal.x, y = heal.y }
  end
  if save.player and not known(data.maps, save.player.map) then
    local heal = save.lastHeal or spawn
    report.remappedMaps[#report.remappedMaps + 1] =
      { id = save.player.map, to = heal.map, field = "player" }
    save.player.map, save.player.x, save.player.y = heal.map, heal.x, heal.y
  end
  if save.lastOutdoor and not known(data.maps, save.lastOutdoor.id) then
    report.remappedMaps[#report.remappedMaps + 1] =
      { id = save.lastOutdoor.id, field = "lastOutdoor" }
    save.lastOutdoor = nil
  end
  if save.lastHeal and type(save.lastHeal.outdoor) == "table"
      and not known(data.maps, save.lastHeal.outdoor.id) then
    save.lastHeal.outdoor = nil
  end
end

-- Walks every content id the save references against the merged data and
-- quarantines unknowns instead of letting them nil-index later: mons move
-- to save.orphaned (the LOST box), items are removed with a report row,
-- locations fall back to the heal point.  Reclaims quarantined content
-- whose id reappeared first.  On a mod-free save every membership test
-- passes and the save comes back untouched.
function SaveData.validate(save, data)
  Boxes.load(data) -- validate slots against this cartridge, never a prior preview
  local report = { lostMons = {}, lostItems = {}, remappedMaps = {},
                   restoredMons = {}, restoredItems = {} }
  -- the clock, in the one shape the rest of the engine can do arithmetic on
  -- (see SaveData.playSeconds) -- before anything else, because a save that
  -- reaches Game:update with a table here throws on its first frame
  if save.playTime ~= nil and tonumber(save.playTime) == nil then
    save.playTime = SaveData.playSeconds(save)
    report.repairedPlayTime = true
  end
  reclaim(save, data, report)
  scrubMonList(save.party, "party", save, data, report)
  for b, box in ipairs(save.boxes or {}) do
    scrubMonList(box, "box " .. b, save, data, report, Boxes.capacity())
  end
  local daycare = save.daycare
  if type(daycare) == "table" and type(daycare.mon) == "table" then
    if not known(data.pokemon, daycare.mon.species) then
      ensureOrphaned(save)
      save.orphaned.mons[#save.orphaned.mons + 1] = daycare.mon
      report.lostMons[#report.lostMons + 1] =
        { species = daycare.mon.species, from = "daycare" }
      daycare.mon = nil
    else
      scrubKnownMon(daycare.mon, data)
    end
  end
  -- Gen2 boards two mons plus a pending EGG under daycare.breed
  local breed = type(daycare) == "table" and daycare.breed or nil
  if type(breed) == "table" then
    for _, key in ipairs({ 1, 2, "egg" }) do
      local entry = breed[key]
      local mon = key == "egg" and entry or (type(entry) == "table" and entry.mon)
      if type(mon) == "table" then
        if not known(data.pokemon, mon.species) then
          ensureOrphaned(save)
          save.orphaned.mons[#save.orphaned.mons + 1] = mon
          report.lostMons[#report.lostMons + 1] =
            { species = mon.species, from = "daycare" }
          breed[key] = nil
        else
          scrubKnownMon(mon, data)
        end
      end
    end
    -- The Route 34 / Day-Care object callbacks stage the whole cast off
    -- ENGINE_DAY_CARE_*, so a save written before those flags existed would
    -- keep the yard empty and the MAN indoors until the next deposit.
    if GameVersion.isGen2() and save.flags then
      require("src.pokemon.DayCare").syncFlags(save)
    end
  end
  if not GameVersion.isGen2() then
    scrubItemMap(save.inventory, "inventory", save, data, report)
    scrubItemMap(save.pcItems, "pcItems", save, data, report)
    if type(save.bagOrder) == "table" then
      for i = #save.bagOrder, 1, -1 do
        if not known(data.items, save.bagOrder[i]) then
          table.remove(save.bagOrder, i)
        end
      end
    end
  end
  scrubMaps(save, data, report)
  local dex = save.pokedex
  if type(dex) == "table" then
    for _, key in ipairs({ "seen", "owned" }) do
      if type(dex[key]) == "table" then
        for id in pairs(dex[key]) do
          if not known(data.pokemon, id) then dex[key][id] = nil end
        end
      end
    end
  end
  -- hall of fame rosters keep their shape: an unknown species blanks in
  -- place so the team stays the size it won at, with the rest of the mon
  -- (level etc.) intact for display
  -- Gen3 stores the induction COUNT here (including zero), not rosters.
  -- Keep it numeric: Champion/Mystery Gift code reads and increments it.
  local rosters = type(save.hallOfFame) == "table" and save.hallOfFame or {}
  for _, entry in ipairs(rosters) do
    if type(entry) == "table" then
      for i = 1, #entry do
        local mon = entry[i]
        if type(mon) == "table" and mon.species ~= nil
            and not known(data.pokemon, mon.species) then
          mon.species = nil
        end
      end
    end
  end
  -- BERRY TREES A SAVE PREDATING THEM NEVER GOT.
  --
  -- Reported from play, after the plots were made to draw what is growing in
  -- them: "berry trees never appeared really".  Two things were wrong and the
  -- art was only one of them -- the other is here.
  --
  -- Hoenn is not planted by the player.  The cartridge's new-game script puts
  -- eighty trees in the ground fruiting, and SaveData.newGame copies that set
  -- (boot.initialBerryTrees, built from the run of `setberrytree` commands the
  -- importer read).  A save STARTED BEFORE that existed has no
  -- `gen3BerryTrees` at all, so every one of Hoenn's 88 plots reads stage
  -- zero -- and a plot with nothing in it is deliberately invisible.  The
  -- trees were not failing to draw; there was nothing planted to draw.
  --
  -- ONLY WHEN THE FIELD IS ABSENT.  A save that HAS the table has been
  -- playing with these trees -- picked, watered, replanted -- and an empty
  -- one is a legitimate state (every berry taken).  So this fills a gap and
  -- never overwrites an answer: the moment the key exists, this does nothing.
  local boot = data and data.field and data.field.boot
  if type(boot) == "table" and type(boot.initialBerryTrees) == "table"
     and save.gen3BerryTrees == nil then
    local trees, n = {}, 0
    for id, tree in pairs(boot.initialBerryTrees) do
      if type(id) == "number" and type(tree) == "table" then
        local copy = {}
        for k, v in pairs(tree) do
          copy[k] = (k == "watered") and {} or v
        end
        trees[id] = copy
        n = n + 1
      end
    end
    if n > 0 then
      save.gen3BerryTrees = trees
      report.plantedBerryTrees = n
    end
  end

  -- an empty quarantine leaves no residue, so a vanilla save re-encodes
  -- byte-identically
  local orphaned = save.orphaned
  if orphaned and #(orphaned.mons or {}) == 0 and #(orphaned.items or {}) == 0 then
    save.orphaned = nil
  end
  return report
end

function SaveData.emptyReport(report)
  -- a bare validate report (the save editor's probe) carries no modsDiff;
  -- restoreSave attaches one so a version bump alone still surfaces
  local diff = report.modsDiff
  return #report.lostMons == 0 and #report.lostItems == 0
    and #report.remappedMaps == 0 and #report.restoredMons == 0
    and #report.restoredItems == 0 and not report.recovered
    and (not diff or (#diff.added == 0 and #diff.removed == 0 and #diff.changed == 0))
end

-- ------- new game

-- boot is Data.field.boot, threaded in by Game: this module must not reach
-- into Data itself.  Every read falls back to the Red literal it replaced,
-- so an absent or partial config still produces the vanilla new game.
-- Where blackouts and ESCAPE ROPE return to for a given boot config.
--
-- In vanilla this is NOT the spawn. wLastBlackoutMap is zero-filled at new
-- game and PALLET_TOWN is map 0, so the player starts in the bedroom
-- (special_warps.asm NewGameWarp) but blacks out to Pallet Town's fly_warp
-- cell (5, 6). A world that moves the spawn without naming a heal point
-- keeps the two together -- it may have no Pallet Town at all.
--
-- Shared with the Hall of Fame reset, which pokered writes as a literal
-- (HallOfFameResetEventsAndSaveScript: wLastBlackoutMap := PALLET_TOWN)
-- rather than deriving from the spawn.
function SaveData.defaultHeal(boot)
  boot = type(boot) == "table" and boot or {}
  local h = boot.lastHeal
  if h then return { map = h.map, x = h.x, y = h.y } end
  local map = boot.startMap or "REDS_HOUSE_2F"
  if map == "REDS_HOUSE_2F" then return { map = "PALLET_TOWN", x = 5, y = 6 } end
  return { map = map, x = boot.startX or 3, y = boot.startY or 6 }
end

-- Post-credits home (issue #103).  pokered left the player in HALL_OF_FAME
-- after jp Init; this port relocates CONTINUE instead, and retargets
-- LAST_MAP exits (Red's house mats) at the heal-point town so leaving the
-- house does not dump the player back at Indigo Plateau.
--
-- The landing spot is the blackout point, not the NewGameWarp bedroom:
-- HallOfFameResetEventsAndSaveScript sets wLastBlackoutMap := PALLET_TOWN,
-- so resuming puts the player outside the front door.  Spawning them back
-- in the upstairs bedroom was a port-only detour (#253).  Non-vanilla
-- spawns are unaffected -- defaultHeal returns boot's own start map for
-- those, which is what the bedroom branch resolved to anyway.
-- Marks postGameHomeOk so a later intentional HoF save is not relocated.
function SaveData.applyPostGameHome(save, boot)
  boot = type(boot) == "table" and boot or {}
  local heal = SaveData.defaultHeal(boot)
  save.lastHeal = { map = heal.map, x = heal.x, y = heal.y }
  save.lastOutdoor = { id = heal.map, x = heal.x, y = heal.y }
  save.player = save.player or {}
  save.player.map = heal.map
  save.player.x = heal.x
  save.player.y = heal.y
  save.player.facing = boot.startFacing or "down"
  save.postGameHomeOk = true
  return heal
end

-- ---------------------------------------------------------------------------
-- THE CHAMPION SAVE WARP (Emerald special 343, SetChampionSaveWarp).
--
-- The cartridge keeps this as one bit -- saveBlock2 byte 9, bit 7,
-- CHAMPION_SAVEWARP -- and the Hall of Fame script sets it immediately
-- before saving.  The save that lands on the cart therefore records a player
-- standing in the Hall of Fame, which is a room with no exit; the bit is
-- what stops that from mattering.  On the NEXT continue the cartridge reads
-- it, clears it, and warps the player to their own bedroom instead of to
-- where the save says they are.
--
-- Two halves, and they are kept apart on purpose: the special sets the bit
-- and nothing else, and Game:restoreSave spends it.  A save written by a
-- version that only had the first half still resumes correctly once the
-- second half exists, because the bit is on the save rather than in the
-- moment.
SaveData.CHAMPION_SAVEWARP = 0x80

function SaveData.hasChampionSaveWarp(save)
  local flags = math.floor(tonumber(
    type(save) == "table" and save.specialSaveWarpFlags or 0) or 0)
  return flags % (SaveData.CHAMPION_SAVEWARP * 2)
         >= SaveData.CHAMPION_SAVEWARP
end

-- `orr` on a byte, written the way Lua can say it: setting a bit already set
-- must not add it twice.
function SaveData.setChampionSaveWarp(save)
  if type(save) ~= "table" then return end
  if SaveData.hasChampionSaveWarp(save) then return end
  save.specialSaveWarpFlags =
    math.floor(tonumber(save.specialSaveWarpFlags) or 0)
    + SaveData.CHAMPION_SAVEWARP
end

-- Spend it: the bedroom the game started in, which is where Emerald's own
-- warp goes, and the bit clears whether or not there is a start map to go
-- to so a dataset without one does not re-warp on every load.
function SaveData.applyChampionSaveWarp(save, boot)
  if not SaveData.hasChampionSaveWarp(save) then return false end
  save.specialSaveWarpFlags =
    math.floor(tonumber(save.specialSaveWarpFlags) or 0)
    - SaveData.CHAMPION_SAVEWARP
  boot = type(boot) == "table" and boot or {}
  if not boot.startMap then return false end
  save.player = save.player or {}
  save.player.map = boot.startMap
  save.player.x = boot.startX or save.player.x
  save.player.y = boot.startY or save.player.y
  save.player.facing = boot.startFacing or "down"
  return true
end

-- Softlocked 0.1.11 saves: still standing in HALL_OF_FAME after credits,
-- with lastOutdoor on Indigo.  One-shot rescue on CONTINUE.
function SaveData.needsPostGameRescue(save)
  if not (save and save.player and save.player.map == "HALL_OF_FAME") then
    return false
  end
  if save.postGameHomeOk then return false end
  local hof = save.hallOfFame
  return type(hof) == "table" and #hof > 0
end

-- the boot config is shared data; a new save must never alias it
local function copyItemMap(src)
  local out = {}
  for id, n in pairs(src) do
    if type(id) == "string" and type(n) == "number" then out[id] = n end
  end
  return next(out) and out or nil
end

-- A SAVE THAT PREDATES THE OPENING FLAGS, REPAIRED IN PLACE.
--
-- Sinnoh's opening state is NEW-GAME state: 112 `setflag`s that keep the
-- actors whose stories have not started off the map.  A save made while that
-- state was not reaching the engine has none of them, and no amount of
-- reloading will add them -- the player is left with the rival's mother
-- standing on the tile her own house's exit warp occupies, which is not a
-- cosmetic fault: it is unwinnable.  Reported from play four times, the last
-- as *"i cant get out of the house because his mom is blocking my path"*.
--
-- NEVER TOUCHED IS THE WHOLE TEST, and it is only answerable because
-- `Flags.clear` writes `false` rather than erasing the key -- it exists
-- precisely so "a script cleared this" can be told from "no script has ever
-- had an opinion here".  So a story the player has genuinely advanced past
-- leaves `false` behind and is left alone, and only the flags whose scripts
-- have never run are put back.  That makes this safe to run on EVERY load
-- rather than once behind a stamp, and a stamp is the thing most likely to be
-- wrong in a save that is already wrong.
--
-- Gen 4 only.  Gen 3 ships the same seam and its saves were never written
-- without it, and Gen 1/Gen 2/Crystal/Prism have their own opening state that
-- this must not touch.
function SaveData.repairOpeningFlags(save, boot)
  if type(save) ~= "table" or type(boot) ~= "table" then return 0 end
  if not GameVersion.isGen4() then return 0 end

  local flags, vars = 0, 0
  if type(boot.initialFlags) == "table" then
    save.flags = save.flags or {}
    for _, name in ipairs(boot.initialFlags) do
      if type(name) == "string" and save.flags[name] == nil then
        save.flags[name] = true
        flags = flags + 1
      end
    end
  end
  if type(boot.initialVars) == "table" then
    save.gen4Vars = save.gen4Vars or {}
    for _, row in ipairs(boot.initialVars) do
      local id, value = tonumber(row.id), tonumber(row.value)
      if id and value and save.gen4Vars[id] == nil then
        save.gen4Vars[id] = value
        vars = vars + 1
      end
    end
  end

  if flags > 0 or vars > 0 then
    Logger.info("gen4 save repair: restored %d opening flag(s) and %d var(s) "
                .. "this save never recorded", flags, vars)
  end
  return flags + vars
end

function SaveData.newGame(boot)
  boot = type(boot) == "table" and boot or {}
  local map = boot.startMap or "REDS_HOUSE_2F"
  local x, y = boot.startX or 3, boot.startY or 6
  local heal = SaveData.defaultHeal(boot)
  local save = {
    meta = { format = Version.saveFormat, mods = {} },
    -- which game this playthrough is (Red vs Blue).  Only Red ships today;
    -- boot carries the choice once Blue support lands.
    version = boot.version or "red",
    player = {
      map = map,
      x = x,
      y = y,
      facing = boot.startFacing or "down",
      name = boot.playerName or "RED",
      rival = boot.rivalName or "BLUE",
      -- 16-bit trainer ID rolled at new game (wPlayerID, filled from
      -- hRandomAdd in OakSpeech)
      id = math.random(0, 65535),
    },
    flags = {},
    inventory = {},
    -- Vanilla Gen1 seeds one Potion in the player's item PC
    -- (wBoxItems / players_pc.asm); existing saves keep whatever they
    -- already have -- this only applies to New Game.
    --
    -- THE ID HAS TO BE THE DATASET'S OWN, not the literal "POTION".  Gen 2
    -- imports name every item off the cartridge as ITEM_nnn, so a hardcoded
    -- "POTION" here is an id no Gen 2 script ever gives -- and the bag is a
    -- map keyed by id, so the PC's potion and the one Elm's aide hands over
    -- landed in TWO SLOTS both reading "POTION".  bootConfig resolves the
    -- right id against the loaded item table and passes it as boot.pcItems;
    -- the Gen 1 literal stays as the fallback for a dataset-free caller.
    pcItems = boot.pcItems and copyItemMap(boot.pcItems) or { POTION = 1 },
    party = {},
    box = {},
    money = boot.startMoney or 3000,
    defeatedTrainers = {},
    pokedex = { seen = {}, owned = {} },
    -- where blackouts and ESCAPE ROPE return to (updated by nurses);
    -- copied, never aliased, so a save never writes back into Data
    lastHeal = { map = heal.map or map, x = heal.x or x, y = heal.y or y },
    -- Interiors inherit the SGB palette of the last outdoor map. wLastMap
    -- is zero-filled at new game and PALLET_TOWN is map 0, so before the
    -- player has ever been outdoors that palette is Pallet Town's -- which
    -- matters because the vanilla spawn (REDS_HOUSE_2F) is itself indoors.
    -- Without this the palette falls through to the ROUTE default.
    lastOutdoor = { id = heal.map or map, x = heal.x or x, y = heal.y or y },
    repelSteps = 0,
    -- per-mod persistence (mod.save) lives under here, keyed by mod id
    modData = {},
    -- Live options from options.lua (or defaults); New Game keeps the
    -- player's audio/display/battle preferences, with this generation's
    -- overrides laid over them (SaveData.optionsFor).
    options = SaveData.optionsFor(nil),
  }
  -- MAP SCENES THAT DO NOT START AT ZERO.
  --
  -- The Gen 2 script VM keeps scene ids in save.g2Scenes, and an absent key
  -- reads as 0.  That is right for nearly every map, but the ROM's new-game
  -- routine writes a few scene bytes directly -- Goldenrod City, Bellchime
  -- Trail and the Battle Tower approach all open on scene 1 -- and a scene
  -- sitting at 0 arms a cutscene the game considers already retired.
  if type(boot.initialScenes) == "table" then
    local scenes = {}
    for mapId, value in pairs(boot.initialScenes) do
      if type(mapId) == "string" and type(value) == "number" then
        scenes[mapId] = value
      end
    end
    if next(scenes) then save.g2Scenes = scenes end
  end
  -- FLAGS A NEW GAME STARTS WITH SET.
  --
  -- Gen 1 and Gen 2 open with every flag clear, and for those that is right.
  -- Gen 3 does not: a set flag HIDES its object there, so the cartridge's own
  -- new-game script sets a batch of them to keep the NPCs whose stories have
  -- not started off the map.  Without it every gated character in the region
  -- is standing there from the first frame.
  if type(boot.initialFlags) == "table" then
    for _, name in ipairs(boot.initialFlags) do
      if type(name) == "string" then save.flags[name] = true end
    end
  end

  -- ...AND THE VARS THAT COME WITH THEM, which only Gen 4 has.
  --
  -- Sinnoh's new-game script sets three (`0x4070 = 1`, `0x4093 = 1`,
  -- `0x4040 = 9`) alongside its 112 flags, and a var is not a flag: Gen 4
  -- keeps them in their own store, which is where `Gen4Commands` reads them
  -- from.  Written as ids rather than names because a Gen 4 var has no name
  -- -- the cartridge addresses them by number and so does every script that
  -- compares one.
  if type(boot.initialVars) == "table" then
    save.gen4Vars = save.gen4Vars or {}
    for _, row in ipairs(boot.initialVars) do
      local id, value = tonumber(row.id), tonumber(row.value)
      if id and value then save.gen4Vars[id] = value end
    end
  end

  -- SAY WHETHER THE OPENING STATE WAS APPLIED AT ALL.
  --
  -- This only runs on a NEW GAME, which is the whole of the answer to "the
  -- character who should be hidden is still there" -- and from inside the game
  -- a save that predates the flags looks exactly like flags that did not work.
  -- One line, once, so the log settles it.
  if type(boot.initialFlags) == "table" or type(boot.initialVars) == "table" then
    Logger.info("new game: applied %d opening flag(s) and %d var(s)",
                #(boot.initialFlags or {}), #(boot.initialVars or {}))
  end

  -- BERRY TREES A NEW GAME STARTS WITH GROWING.
  --
  -- Hoenn is not planted by the player: the cartridge's new-game script puts
  -- eighty trees in the ground, all fruiting, and Route 104's are the first
  -- ones anybody meets.  Data.lua builds the record from the run of
  -- setberrytree commands the importer read; this copies it, deeply, so that
  -- watering one tree in one save cannot reach into another.
  if type(boot.initialBerryTrees) == "table" then
    local trees = {}
    for id, tree in pairs(boot.initialBerryTrees) do
      if type(id) == "number" and type(tree) == "table" then
        local copy = {}
        for k, v in pairs(tree) do
          copy[k] = (k == "watered") and {} or v
        end
        trees[id] = copy
      end
    end
    if next(trees) then save.gen3BerryTrees = trees end
  end

  -- a total conversion reshapes the skeleton (spawn, party, money)
  -- before anything reads it; unhooked this returns save unchanged
  --
  -- `boot.noHooks` ASKS FOR THE SHAPE WITHOUT THE EVENT.
  --
  -- Not every caller of this is starting a playthrough. The map editor builds
  -- one purely so its tab rail has counters to draw (tools/save-editor
  -- App.lua, map mode) -- and firing `save.new_game` there told every
  -- installed mod that a new game had begun, from inside a tool with no world
  -- booted and nothing for a handler to reach. One that took the event at
  -- face value took the editor down with it.
  --
  -- Callers that ARE starting a playthrough pass nothing and are unaffected.
  if boot.noHooks then return save end
  return Runtime.call("save.new_game", function(s) return s end, save)
end

return SaveData
