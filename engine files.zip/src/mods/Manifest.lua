-- Manifest v2: a strict superset of v1, so every shipped v1 manifest stays
-- valid.  Pure (no filesystem): the loader's validate phase owns the checks
-- that need to stat a file, this owns shape, vocabulary and range grammar.
local Logger = require("src.core.Logger")
local Semver = require("src.mods.Semver")
local Version = require("src.core.Version")

local Manifest = {}

Manifest.PROFILES = { content = true, overhaul = true, total_conversion = true }
Manifest.PERMISSIONS = { network = true, filesystem = true, engine_internals = true }

-- link-relevant registries; a mod that writes into one of these while
-- declaring affects_link = false gets an attributed warning from the loader
Manifest.LINK_REGISTRIES = {
  pokemon = true, moves = true, type_chart = true,
  statuses = true, move_effects = true,
}

local function array(value)
  if value == nil then return {} end
  assert(type(value) == "table", "manifest arrays must be tables")
  return value
end

-- api 2 treats vocabulary violations as load errors; api 1 keeps loading and
-- gets an attributed warning so v1 mods never break on a field they predate
local function violation(strict, id, message)
  if strict then error(message, 0) end
  Logger.warn("[%s] %s", tostring(id), message)
end

-- "id" or "id@<range>"; a malformed id or range fails for every api level
-- because there is no sane fallback reading for it
local function parseSpecs(list, field)
  local specs = {}
  for _, entry in ipairs(list) do
    assert(type(entry) == "string" and entry ~= "",
      field .. " entries must be non-empty strings")
    local id, range = entry:match("^([%w_%-]+)@(.+)$")
    if not id then
      id = entry:match("^([%w_%-]+)$")
      assert(id, ("malformed %s entry %q"):format(field, entry))
      range = nil
    end
    local ok, err = Semver.validRange(range)
    assert(ok, ("malformed %s range in %q: %s"):format(field, entry, tostring(err)))
    specs[#specs + 1] = { id = id, range = range }
  end
  return specs
end

-- Optional GitHub repo for launcher auto-update / other-versions.
-- Accepts "owner/repo" or a github.com URL; empty/absent means no updates.
function Manifest.parseGithub(value)
  if value == nil or value == "" then return nil end
  assert(type(value) == "string", "github must be a string")
  local trimmed = value:match("^%s*(.-)%s*$") or value
  if trimmed == "" then return nil end
  local owner, repo = trimmed:match(
    "^https?://github%.com/([%w%._%-]+)/([%w%._%-]+)/?$")
  if not owner then
    owner, repo = trimmed:match(
      "^https?://github%.com/([%w%._%-]+)/([%w%._%-]+)%.git/?$")
  end
  if not owner then
    owner, repo = trimmed:match("^([%w%._%-]+)/([%w%._%-]+)$")
  end
  assert(owner and repo and owner ~= "" and repo ~= "",
    "github must be owner/repo or a github.com URL")
  repo = repo:gsub("%.git$", "")
  return owner .. "/" .. repo
end

-- conflicts + incompatible (alias) merged, first-wins on duplicate ids
-- `required_games`: [{ version, name }], the cartridges a mod needs imported.
--
-- Tolerant of a bare list of version strings, because that is what a human
-- hand-editing this file will write, and the display name is recoverable from
-- the version anyway.
local function parseRequiredGames(raw)
  local list = raw and raw.required_games
  if type(list) ~= "table" then return nil end
  local out = {}
  for _, entry in ipairs(list) do
    local version, name
    if type(entry) == "string" then
      version = entry
    elseif type(entry) == "table" then
      version = type(entry.version) == "string" and entry.version or nil
      name = type(entry.name) == "string" and entry.name or nil
    end
    if version and version ~= "" then
      out[#out + 1] = { version = version, name = name or version:upper() }
    end
  end
  return out[1] and out or nil
end

-- `maps`: the map ids a content mod patches, declared rather than discovered.
--
-- WHY DECLARE SOMETHING THE ENTRY FILE ALREADY SAYS. The entry file only says
-- it once it has RUN, and the mod set is built once a boot -- so between
-- installing a map pack and restarting, the only honest answer to "what is in
-- this?" was silence. Worse than silence in practice: a pack replacing an
-- earlier version of itself still had the OLD one's claims in the registry, so
-- the editor showed the previous contents with no sign they were stale.
--
-- The manifest is the one part of a mod that is read WITHOUT running it, so a
-- list here is answerable at install time, on the install screen, before the
-- zip is even unpacked. Advisory, never authoritative: what a mod actually
-- patches is what it patches, and the registry remains the truth once loaded.
-- `generations`: [1, 2] -- the generations a mod is written for.
--
-- Validated to the generations that exist (ModGens.COUNT -- 1 to 5) and
-- sorted, so the set is comparable and
-- an out-of-range entry is dropped rather than widening the mod's claim.  An
-- empty or malformed list reads as "unstated" (nil), NOT as "none": a mod that
-- says nothing intelligible must keep working exactly as it did.
local function parseGenerations(raw)
  local list = raw and raw.generations
  if type(list) ~= "table" then return nil end
  local seen, out = {}, {}
  for _, entry in ipairs(list) do
    local n = tonumber(entry)
    -- WAS `n <= 3`, which silently dropped a mod's claim to Gen 4 (and would
    -- have dropped Gen 5): a Platinum mod that said "generations": [4] read as
    -- saying nothing at all
    if n and n % 1 == 0 and n >= 1 and n <= require("src.mods.ModGens").COUNT and not seen[n] then
      seen[n] = true
      out[#out + 1] = n
    end
  end
  table.sort(out)
  return out[1] and out or nil
end

local function parseMaps(raw)
  local list = raw and raw.maps
  if type(list) ~= "table" then return nil end
  local out = {}
  for _, entry in ipairs(list) do
    if type(entry) == "string" and entry ~= "" then out[#out + 1] = entry end
  end
  return out[1] and out or nil
end

local function mergeConflictLists(conflicts, incompatible)
  local seen, out = {}, {}
  for _, list in ipairs({ array(conflicts), array(incompatible) }) do
    for _, entry in ipairs(list) do
      if not seen[entry] then
        seen[entry] = true
        out[#out + 1] = entry
      end
    end
  end
  return out
end

-- Drop bytes that are not valid UTF-8 (malformed sequences, overlongs,
-- surrogates, > U+10FFFF) and a leading BOM.  LÖVE's text renderer raises
-- "Invalid UTF-8" from love.graphics.print/printf, so any manifest string a
-- panel may draw must be scrubbed here -- the one place every mod manifest
-- passes through -- or a single mangled description crashes the whole MODS
-- panel instead of misrendering one card.
local function scrubUtf8(s)
  if type(s) ~= "string" then return s end
  s = s:gsub("^\239\187\191", "")
  local out, i, n = {}, 1, #s
  while i <= n do
    local b = s:byte(i)
    local len
    if b < 0x80 then len = 1
    elseif b >= 0xC2 and b <= 0xDF then len = 2
    elseif b >= 0xE0 and b <= 0xEF then len = 3
    elseif b >= 0xF0 and b <= 0xF4 then len = 4
    end
    local ok = len ~= nil and i + len - 1 <= n
    if ok and len > 1 then
      for j = i + 1, i + len - 1 do
        local c = s:byte(j)
        if c < 0x80 or c > 0xBF then ok = false; break end
      end
      if ok then
        -- boundary lead bytes narrow their second byte: no overlongs
        -- (E0/F0), no surrogates (ED), nothing past U+10FFFF (F4)
        local b2 = s:byte(i + 1)
        if (b == 0xE0 and b2 < 0xA0) or (b == 0xED and b2 > 0x9F)
            or (b == 0xF0 and b2 < 0x90) or (b == 0xF4 and b2 > 0x8F) then
          ok = false
        end
      end
    end
    if ok then
      out[#out + 1] = s:sub(i, i + len - 1)
      i = i + len
    else
      i = i + 1
    end
  end
  return table.concat(out)
end

function Manifest.validate(raw, path)
  assert(type(raw) == "table", "manifest must be an object")
  -- scrubbed in place so every later reader agrees, including the launcher's
  -- badge derivation, which reads raw.category rather than the validated copy
  raw.name = scrubUtf8(raw.name)
  raw.version = scrubUtf8(raw.version)
  raw.description = scrubUtf8(raw.description)
  raw.category = scrubUtf8(raw.category)
  assert(type(raw.id) == "string" and raw.id:match("^[%w_%-]+$"),
    "manifest id must contain only letters, numbers, _ or -")
  assert(type(raw.name) == "string" and raw.name ~= "", "manifest name is required")
  assert(type(raw.version) == "string" and raw.version ~= "", "manifest version is required")
  assert(type(raw.entry) == "string" and raw.entry ~= "", "manifest entry is required")

  -- absent means 1: full v1 compat, schema violations downgrade to warnings
  assert(raw.api == nil or tonumber(raw.api) ~= nil, "manifest api must be a number")
  local api = tonumber(raw.api) or 1
  assert(api >= 1 and api % 1 == 0, "manifest api must be a positive integer")
  assert(api <= Version.modApi, ("requires mod API %d; this engine provides %d")
    :format(api, Version.modApi))
  local strict = api >= 2

  local profile = raw.profile or "content"
  if not Manifest.PROFILES[profile] then
    violation(strict, raw.id, ("unknown profile %q"):format(tostring(profile)))
    profile = "content"
  end

  local permissions, permissionSet = {}, {}
  for _, name in ipairs(array(raw.permissions)) do
    if Manifest.PERMISSIONS[name] then
      permissions[#permissions + 1] = name
      permissionSet[name] = true
    else
      violation(strict, raw.id, ("unknown permission %q"):format(tostring(name)))
    end
  end

  local gameVersionOk, gameVersionErr = Semver.validRange(raw.game_version)
  assert(gameVersionOk, ("malformed game_version %q: %s")
    :format(tostring(raw.game_version), tostring(gameVersionErr)))

  local github = Manifest.parseGithub(raw.github)

  -- A fork keeps `github` for credit but must not chase upstream's releases:
  -- its version line is its own, and "update" there would overwrite the fork.
  assert(raw.update_check == nil or type(raw.update_check) == "boolean",
    "update_check must be a boolean")
  local updateCheck = raw.update_check ~= false

  assert(raw.experimental == nil or type(raw.experimental) == "boolean",
    "experimental must be a boolean")
  local experimental = raw.experimental == true

  -- #501: a translation declares itself here.  Neither the ROM's dialogue
  -- nor the engine's own strings are hashed into the link surface
  -- (src/link/Fingerprint.lua header), so an English install and a Spanish
  -- one run the same lockstep simulation, exactly as two regional carts on
  -- a real cable did.  The flag is only the author's claim;
  -- Handshake.onlineBlockers checks it against the ops the mod actually
  -- appended before online play trusts it.
  assert(raw.language == nil or type(raw.language) == "boolean",
    "language must be a boolean")
  local language = raw.language == true

  -- overhauls and total conversions are assumed to move the link
  -- fingerprint unless the manifest says otherwise; content packs and
  -- declared translations are not
  local affectsLink = profile ~= "content" and not language
  if type(raw.affects_link) == "boolean" then affectsLink = raw.affects_link end

  local function optionalFile(value, field)
    if value == nil then return nil end
    assert(type(value) == "string" and value ~= "", field .. " must be a file path")
    return value
  end

  local conflicts = mergeConflictLists(raw.conflicts, raw.incompatible)

  -- `support`: where to thank the mod's creator -- a Ko-fi, a Patreon, a
  -- PayPal page. The launcher's mod card turns it into a "Support the
  -- creator" button. ONLY http(s) is accepted, because the button hands it
  -- to the OS to open: a `file:` or custom-scheme link from a downloaded
  -- manifest is not something a click on a donate button should run. A bad
  -- value is dropped with a warning rather than refusing the whole mod.
  local support = raw.support or raw.support_url
  if support ~= nil then
    if type(support) == "string" and support:match("^https?://[%w%-%.]+%.%a+")
       and not support:find("%s") then
      support = scrubUtf8(support)
    else
      violation(false, raw.id, ("support must be an http(s) URL, got %q")
        :format(tostring(support)))
      support = nil
    end
  end

  return {
    id = raw.id,
    name = raw.name,
    version = raw.version,
    entry = raw.entry,
    api = api,
    priority = tonumber(raw.priority) or 0,
    dependencies = array(raw.dependencies),
    optional_dependencies = array(raw.optional_dependencies),
    conflicts = conflicts,
    incompatible = array(raw.incompatible),
    dependencySpecs = parseSpecs(array(raw.dependencies), "dependencies"),
    optionalSpecs = parseSpecs(array(raw.optional_dependencies), "optional_dependencies"),
    conflictSpecs = parseSpecs(conflicts, "conflicts"),
    category = raw.category or "OTHER",
    game_version = raw.game_version,
    description = raw.description or "",
    github = github,
    support = support,
    updateCheck = updateCheck,
    experimental = experimental,
    profile = profile,
    language = language,
    affects_link = affectsLink,
    permissions = permissions,
    permissionSet = permissionSet,
    options_schema = optionalFile(raw.options_schema, "options_schema"),
    -- Base files the mod needs but cannot ship -- a Stadium 2 cartridge, a
    -- second game's ROM.  Declared here, satisfied by the launcher, read by
    -- the mod out of its own folder (src/mods/ModImports.lua).
    requiredImports = require("src.mods.ModImports").parse(raw),
    -- Cartridges that must be IMPORTED for this mod to mean anything -- a
    -- different thing from requiredImports above, which is a file the player
    -- hands over and the launcher writes into the mod's folder.
    --
    -- A map pack exported from the map editor carries maps copied out of
    -- another game and tilesets adopted from it BY REFERENCE: it ships no
    -- cartridge content, so it needs the reader's own extraction to resolve
    -- against. Nothing to supply, nothing to write -- the requirement is
    -- satisfied by having imported that game, and this is how the launcher
    -- knows to ask before the mod is ever run.
    requiredGames = parseRequiredGames(raw),
    -- WHICH GENERATIONS THIS MOD IS FOR.
    --
    -- A mod written against Gen 1 and Gen 2 loaded under Emerald does not
    -- announce itself -- it half-applies.  One shipped mod asks the host its
    -- generation, gets 3, refuses to route anything, and logs that refusal
    -- once per frame; its Gen 2 battle transition is unavailable so its screen
    -- bridge stays installed with nothing to draw (a white screen after any
    -- menu), and its Gen 1 type names resolve against nothing.  Every symptom
    -- is downstream of running it somewhere it was never for.
    --
    -- The launcher has had per-generation switches since the chips went in;
    -- what it could not know was which generations a mod SUPPORTS, so it could
    -- not default them or refuse.  Declared here, it can do both.  Absent
    -- means all supported generations, which is every mod that predates the field.
    generations = parseGenerations(raw),
    -- Which maps this mod says it touches; see parseMaps. Absent on every mod
    -- that predates the field, which is why nothing may depend on it.
    maps = parseMaps(raw),
    -- Ids this mod used to publish under.  Four things key on a mod's id and
    -- none of them is inside the mod (enable state, options, per-save state,
    -- storage), so a rename orphans all four unless it is declared here; see
    -- src/mods/ModRename.lua for what that adoption is and is not allowed to
    -- do.  Validated rather than trusted: these become table keys and path
    -- components.
    previousIds = require("src.mods.ModRename")
      .previousIds({ id = raw.id, previous_ids = raw.previous_ids }),
    assets_transforms = optionalFile(raw.assets_transforms, "assets_transforms"),
    path = path,
    raw = raw,
  }
end

return Manifest
