-- Trainer/wild move selection with the per-class "move choice
-- modification" layers from data/trainers/move_choices.asm
-- (engine/battle/trainer_ai.asm):
--   mod 1: heavily discourage zero-power status-ailment moves when the
--          player already has a status condition (they would fail)
--   mod 2: encourage stat-modifying (and neighbouring) move effects,
--          but only on the second move selection per enemy mon
--          (wAILayer2Encouragement == 1)
--   mod 3: encourage moves whose type is super effective against the
--          player (even non-damaging ones), discourage not-very-
--          effective/no-effect types when a "better move" is known
-- Faithful port of AIEnemyTrainerChooseMoves
-- (engine/battle/trainer_ai.asm:3-257): every candidate move starts at a
-- base score of 10; mod 1 adds 5, mod 2 subtracts 1, mod 3 subtracts 1
-- (super-effective) or adds 1 (not-effective when a better move exists);
-- the MINIMUM-scored move is chosen, ties broken uniformly among the
-- tied minima (core.asm:2971-3002).  A non-minimal move is never
-- selectable.  Respects Disable (and PP only when the ruleset depletes
-- enemy PP -- Gen 1 AI never reads wEnemyMonPP).

local TypeChart = require("src.battle.TypeChart")
local Strings = require("src.core.Strings")

local TrainerAI = {}

local HEAL_AMOUNT = { POTION = 20, SUPER_POTION = 50, HYPER_POTION = 200 }
local X_STAT = { X_ATTACK = "attack", X_DEFEND = "defense", X_SPEED = "speed" }

-- The trainer's ai_classes record from the merged registry; the direct
-- require covers battles built without a loader.  A trainer record's
-- aiClass field picks a record other than its own id.
function TrainerAI.classFor(battle)
  local trainer = battle and battle.trainer
  if not trainer then return nil end
  local id = trainer.aiClass or trainer.id
  local classes = battle.data and battle.data.ai_classes
  if classes then return classes[id] end
  return require("data.scripts.ai_classes")[id]
end

-- Item use / switching per trainer class (engine/battle/trainer_ai.asm
-- via the ai_classes registry).  Runs before move choice each enemy
-- turn; returns an action { special = "aiItem"/"aiSwitch", ... } or nil.
-- battle.aiUses is initialized per enemy Pokémon (wAICount).
-- ---------------------------------------------------------------------------
-- GEN 3: ShouldUseItem (battle_ai_switch_items.c)
--
-- A Gen 1 trainer's item use hangs off its CLASS -- ai_classes above, keyed
-- by OPP_BROCK and the rest.  A Gen 3 trainer carries its own bag: four item
-- slots in its gTrainers record, packed from the first with no holes.  There
-- is no class table and no wAICount; every slot may be spent once.
--
-- The slot rule is the interesting half.  `if (i != 0 && validMons >
-- (itemsNo - i) + 1) continue;` -- itemsNo is the count the battle STARTED
-- with, so with a full bench only the first item is reachable and the rest
-- unlock as the bench empties.  A gym leader with three FULL RESTOREs and
-- six Pokemon left may spend one; at three left, two; at two left, all
-- three.  That is why the rematch leaders feel like they heal "once per
-- stretch" rather than every time they drop below a quarter.
--
-- Hoenn's trainers only ever carry FULL RESTORE, HYPER POTION, SUPER POTION
-- and POTION (178/40/13/2 of the 254 slots filled), so the cartridge's
-- GetAI_ItemType lands on AI_ITEM_FULL_RESTORE and AI_ITEM_HEAL_HP and
-- nothing else; the X-stat, GUARD SPEC and status-cure arms have no trainer
-- in the game to reach them.  This reads the item's own heal amount rather
-- than assuming one, so a mod that hands a trainer a MAX POTION is covered.
-- The amount the cartridge itself compares against: gItemEffectTable's own
-- argument byte, which extractItemEffects already reads.  $FF (a full heal)
-- and $FE (half) are sentinels there rather than amounts, and `ShouldUseItem`
-- compares the RAW byte -- so MAX POTION's test is "more than 255 damage
-- taken", which is why in practice it only ever fires on the quarter rule.
local function gen3HealAmount(battle, item)
  local ok, ItemEffects = pcall(require, "src.inventory.ItemEffects")
  if ok and ItemEffects and ItemEffects.gen3RecordFor then
    local r = ItemEffects.gen3RecordFor(item, battle and battle.data)
    if r and r.heal then
      local a = r.amount
      if type(a) == "number" then return a end
      if a == "all" then return 255 end
      if a == "half" then return 254 end
      return 0
    end
    if r then return nil end -- a Gen 3 item that is not a heal at all
  end
  return HEAL_AMOUNT[item]
end

function TrainerAI.gen3ItemAction(battle)
  local trainer = battle.trainer
  local items = trainer and trainer.items
  if type(items) ~= "table" or #items == 0 then return nil end
  local enemy = battle.enemy
  -- the same empty-slot guard the class path needs: a foe lifted off the
  -- field in a double battle has nobody to heal
  if not (enemy and enemy.mon and enemy.mon.stats) then return nil end

  -- validMons counts every party member still standing, the ACTIVE one
  -- included (the cartridge walks all six slots and tests hp ~= 0)
  local valid = 0
  for _, mon in ipairs(battle.enemyParty or {}) do
    if (mon.hp or 0) > 0 then valid = valid + 1 end
  end

  local used = battle.gen3ItemsUsed or {}
  battle.gen3ItemsUsed = used
  local itemsNo = #items
  local hp, maxHp = enemy.mon.hp or 0, enemy.mon.stats.hp or 1
  local quarter = math.floor(maxHp / 4)

  for slot = 1, itemsNo do
    local i = slot - 1 -- the cartridge's own index, which the rule is in
    if not used[slot] and not (i ~= 0 and valid > (itemsNo - i) + 1) then
      local item = items[slot]
      local heal = gen3HealAmount(battle, item)
      if item == "FULL_RESTORE" then
        -- AI_ITEM_FULL_RESTORE: breaks out at hp >= maxHP/4 and at hp == 0
        if hp > 0 and hp < quarter then
          return { special = "aiItem", item = item, slot = slot }
        end
      elseif heal then
        -- AI_ITEM_HEAL_HP: below a quarter, or once the damage taken
        -- exceeds what the item would put back (so none of it is wasted)
        if hp > 0 and (hp < quarter or (maxHp - hp) > heal) then
          return { special = "aiItem", item = item, slot = slot }
        end
      end
    end
  end
  return nil
end

function TrainerAI.classAction(battle)
  if battle.kind ~= "trainer" or not battle.trainer then return nil end
  -- a trainer carrying its own bag (Gen 3) is answered from the bag; there
  -- is no ai_classes record for it and no per-Pokemon use counter
  local carried = TrainerAI.gen3ItemAction(battle)
  if carried then return carried end
  local class = TrainerAI.classFor(battle)
  if not class then return nil end
  if (battle.aiUses or 0) <= 0 then return nil end
  local rng = battle.rng
  local enemy = battle.enemy
  -- a double battle lifts a fainted foe off the field at once and only
  -- replaces it when the turn ends, so this slot can be empty while the
  -- other one fights on -- and a trainer with nobody there uses no item
  if not (enemy and enemy.mon) then return nil end
  local roll = rng(0, 255)

  -- Agatha's dedicated switch roll comes before her item roll
  if class.switchChance and roll < class.switchChance then
    return TrainerAI.switchAction(battle)
  end

  if class.onStatus then
    if enemy.mon.status then
      return { special = "aiItem", item = class.item }
    end
    return nil
  end

  if class.chance and roll >= class.chance then return nil end

  if class.switch then
    return TrainerAI.switchAction(battle)
  end
  if class.hpBelow
     and enemy.mon.hp >= math.floor(enemy.mon.stats.hp / class.hpBelow) then
    if class.switchBelow
       and enemy.mon.hp < math.floor(enemy.mon.stats.hp / class.switchBelow) then
      return TrainerAI.switchAction(battle)
    end
    return nil
  end
  return { special = "aiItem", item = class.item }
end

-- AISwitchIfEnoughMons (engine/battle/trainer_ai.asm:554-582): counts ALL
-- unfainted party mons including the active one and switches when that
-- total is >= 2 (cp 2 / jp nc) -- i.e. whenever at least ONE non-active
-- mon can still fight.  Switch to the first (lowest-index) such backup,
-- matching EnemySendOutFirstMon (core.asm:1292-1341).
function TrainerAI.switchAction(battle)
  local alive = {}
  for i, mon in ipairs(battle.enemyParty or {}) do
    if mon.hp > 0 and i ~= battle.enemyIndex then
      table.insert(alive, i)
    end
  end
  if #alive < 1 then return nil end
  return { special = "aiSwitch", index = alive[1] }
end

-- Apply an aiItem action to the enemy battler; returns messages.
function TrainerAI.useItem(battle, item)
  local enemy = battle.enemy
  local trainerName = battle.trainer.name
  local itemName = battle.data.items[item] and battle.data.items[item].name or item
  local msgs = { Strings("%s\nused %s!", trainerName, itemName) }
  -- HOENN'S ANSWER FIRST.  An Emerald item is run by gItemEffectTable's own
  -- blob, which extractItemEffects already reads and ItemEffects already
  -- knows how to apply -- including the FULL RESTORE that clears status and
  -- the active TOXIC counter with it.  The Gen 1 arms below are keyed by
  -- names Emerald's items do not carry, so without this a trainer's FULL
  -- RESTORE would have healed by the Gen 1 table's rules or not at all.
  local okEffects, ItemEffects = pcall(require, "src.inventory.ItemEffects")
  if okEffects and ItemEffects and ItemEffects.gen3RecordFor
     and ItemEffects.gen3RecordFor(item, battle.data) then
    local _, said = ItemEffects.use(battle.data, nil, item, enemy.mon, battle)
    if type(said) == "table" then
      for _, m in ipairs(said) do msgs[#msgs + 1] = m end
    end
    return msgs
  end
  if item == "FULL_HEAL" then
    enemy.mon.status = nil
    enemy.toxicCounter = nil
  elseif item == "FULL_RESTORE" then
    enemy.mon.hp = enemy.mon.stats.hp
    enemy.mon.status = nil
    enemy.toxicCounter = nil
  elseif HEAL_AMOUNT[item] then
    enemy.mon.hp = math.min(enemy.mon.stats.hp, enemy.mon.hp + HEAL_AMOUNT[item])
  elseif X_STAT[item] then
    local stat = X_STAT[item]
    enemy.stages[stat] = math.min(6, (enemy.stages[stat] or 0) + 1)
    table.insert(msgs, Strings("%s's\n%s rose!", enemy.name, stat:upper()))
  elseif item == "GUARD_SPEC" then
    enemy.mist = true
    table.insert(msgs, Strings("%s's\nprotected against\nstat changes!", enemy.name))
  end
  return msgs
end

-- AIMoveChoiceModification1's StatusAilmentMoveEffects table: the two
-- sleep effects (EFFECT_01 is the unused one), poison and paralysis.
local STATUS_EFFECTS = {
  EFFECT_01 = true, SLEEP_EFFECT = true, POISON_EFFECT = true,
  PARALYZE_EFFECT = true,
}

-- AIMoveChoiceModification2 encourages the two effect ranges
-- ATTACK_UP1_EFFECT..BIDE_EFFECT and ATTACK_UP2_EFFECT..POISON_EFFECT
-- (both exclusive of the upper bound): every stat modifier plus the
-- effects laid out between them in the constant list.
local ENCOURAGE_EFFECTS = {
  -- $0A ATTACK_UP1_EFFECT .. $19 HAZE_EFFECT
  ATTACK_UP1_EFFECT = true, DEFENSE_UP1_EFFECT = true, SPEED_UP1_EFFECT = true,
  SPECIAL_UP1_EFFECT = true, ACCURACY_UP1_EFFECT = true, EVASION_UP1_EFFECT = true,
  PAY_DAY_EFFECT = true, SWIFT_EFFECT = true,
  ATTACK_DOWN1_EFFECT = true, DEFENSE_DOWN1_EFFECT = true, SPEED_DOWN1_EFFECT = true,
  SPECIAL_DOWN1_EFFECT = true, ACCURACY_DOWN1_EFFECT = true, EVASION_DOWN1_EFFECT = true,
  CONVERSION_EFFECT = true, HAZE_EFFECT = true,
  -- Gen 2 splits $0D/$0E and $15/$16 into the two Special halves
  SP_ATK_UP1_EFFECT = true, SP_DEF_UP1_EFFECT = true,
  SP_ATK_DOWN1_EFFECT = true, SP_DEF_DOWN1_EFFECT = true,
  -- $32 ATTACK_UP2_EFFECT .. $41 REFLECT_EFFECT
  ATTACK_UP2_EFFECT = true, DEFENSE_UP2_EFFECT = true, SPEED_UP2_EFFECT = true,
  SPECIAL_UP2_EFFECT = true, ACCURACY_UP2_EFFECT = true, EVASION_UP2_EFFECT = true,
  HEAL_EFFECT = true, TRANSFORM_EFFECT = true,
  ATTACK_DOWN2_EFFECT = true, DEFENSE_DOWN2_EFFECT = true, SPEED_DOWN2_EFFECT = true,
  SPECIAL_DOWN2_EFFECT = true, ACCURACY_DOWN2_EFFECT = true, EVASION_DOWN2_EFFECT = true,
  LIGHT_SCREEN_EFFECT = true, REFLECT_EFFECT = true,
  SP_ATK_UP2_EFFECT = true, SP_DEF_UP2_EFFECT = true,
  SP_ATK_DOWN2_EFFECT = true, SP_DEF_DOWN2_EFFECT = true,
}

-- AIMoveChoiceModification3 .betterMoveFound: a "better move" is any
-- known move (PP and Disable ignored) with the Super Fang, fixed-damage
-- or Fly effect, or any damaging move of a different type than the move
-- being judged.
local BETTER_EFFECTS = {
  SUPER_FANG_EFFECT = true, SPECIAL_DAMAGE_EFFECT = true, FLY_EFFECT = true,
}

local function hasBetterMove(battler, judged, battle)
  for _, mv in ipairs(battler.curMoves) do
    local d = battle.data.moves[mv.id]
    if d then
      if BETTER_EFFECTS[d.effect] then return true end
      if d.type ~= judged.type and d.power > 0 then return true end
    end
  end
  return false
end

-- The three vanilla passes as ai_classes layer records: vanilla is just the
-- first registrant, so a mod patches one instead of reimplementing trainer
-- AI.  src/mods/Builtins.lua registers them; chooseMove dispatches through
-- whatever the registry holds and falls back here when a battle was built
-- without a loader.  view.encourageTurn is wAILayer2Encouragement == 1.
TrainerAI.LAYERS = {
  LAYER_1 = { kind = "layer", score = function(view, def, score)
    -- `add $5`: heavily discourage a zero-power status move that would
    -- fail because the player is already statused
    if def and view.target.mon.status and def.power == 0
       and STATUS_EFFECTS[def.effect] then
      return score + 5
    end
    return score
  end },
  LAYER_2 = { kind = "layer", score = function(view, def, score)
    if def and view.encourageTurn and ENCOURAGE_EFFECTS[def.effect] then
      return score - 1 -- `dec [hl]`: slightly encourage
    end
    return score
  end },
  -- AIGetTypeEffectiveness only reads the FIRST matching TypeEffects row for
  -- (move type vs either defender type) -- no dual-type product -- and runs
  -- for non-damaging moves too.  The table holds no value-10 rows, so
  -- >10 / <10 reproduces the oracle's compare against $10.
  LAYER_3 = { kind = "layer", score = function(view, def, score)
    if not def then return score end
    local row = TypeChart.rows(def.type, view.target.curTypes)[1]
    if row and row > 10 then
      return score - 1 -- `dec [hl]`: encourage a super-effective move
    elseif row and row < 10 and hasBetterMove(view.user, def, view.battle) then
      return score + 1 -- `inc [hl]`: discourage when a better move is known
    end
    return score
  end },
}

-- vanilla registrations, kept beside the other Builtins delegations
function TrainerAI.registerInto(registry, _, owner)
  for id, record in pairs(TrainerAI.LAYERS) do
    registry:register(id, record, owner)
  end
end

function TrainerAI.chooseMove(battler, rng, battle)
  rng = rng or love.math.random
  -- Gen 1: SelectEnemyMove never consults wEnemyMonPP; Struggle only when
  -- every move slot is missing/disabled (core.asm:2957-2999). modern_clean
  -- depletes enemy PP and falls back to Struggle when none remain.
  local unlimited = battle and battle.ruleset and battle.ruleset.enemyUnlimitedPP
  local usable = {}
  for i, mv in ipairs(battler.curMoves) do
    if battler.disabledSlot ~= i and (unlimited or mv.pp > 0) then
      table.insert(usable, mv)
    end
  end
  if #usable == 0 then
    return { id = "STRUGGLE", pp = 1, struggle = true }
  end

  -- wAILayer2Encouragement starts at 0 on each enemy send-out and gains
  -- 1 per executed enemy move, so layer 2 (which needs it == 1) only
  -- fires on the second move selection of each enemy mon.  The port
  -- counts selections instead of executions; they only diverge across
  -- turns locked into a multi-turn move, which skip selection entirely.
  local encourageTurn = (battler.aiLayer2 or 0) == 1
  battler.aiLayer2 = (battler.aiLayer2 or 0) + 1

  -- HOENN HAS ITS OWN PROGRAM FOR THIS, and it is the cartridge's, not a
  -- layer stack: gTrainers[].aiFlags names bytecode scripts, the importer
  -- decodes them and src/battle/Gen3AI.lua runs them.  It answers nil for a
  -- trainer the cartridge gave no flags, for a build with no decoded program,
  -- and for a script this engine cannot run end to end yet -- and nil means
  -- "no opinion", so everything below is exactly what it was.
  if battle then
    local okAI, Gen3AI = pcall(require, "src.battle.Gen3AI")
    if okAI and type(Gen3AI) == "table" then
      local foes = battle.foesOf and battle:foesOf(battler) or nil
      if foes and #foes > 1 then
        -- TWO OF THEM TO AIM AT, so the answer is a move AND a target: the
        -- cartridge scores every pair and takes the best one.  The target is
        -- left where the player's own answer is left, so the move resolves
        -- through exactly the same path a chosen target already does.
        local okPick, move, target =
          pcall(Gen3AI.chooseAction, battle, battler, usable, foes)
        if okPick and move then
          if target and battler.position then
            battle.chosenTargets = battle.chosenTargets or {}
            battle.chosenTargets[battler.position] = target
          end
          return move
        end
      else
        local target = (foes and foes[1]) or battle.player
        local okPick, picked = pcall(Gen3AI.chooseMove, battle, battler, target,
                                     usable)
        if okPick and picked then return picked end
      end
    end
  end

  local mods = battle and battle.enemyAIMods or nil
  if not mods or #mods == 0 or not battle then
    return usable[rng(1, #usable)]
  end

  -- aiMods entries may name registered ai_classes layer records; a number n
  -- resolves through "LAYER_<n>", which is how the vanilla three are keyed.
  -- A battle built without a loader has no merged registry, so the built-in
  -- records answer directly.
  local classes = battle.data and battle.data.ai_classes
  local layers, view = {}, nil
  for _, mod in ipairs(mods) do
    local id = type(mod) == "string" and mod or ("LAYER_" .. tostring(mod))
    local record = classes and classes[id]
    if not (record and record.score) then record = TrainerAI.LAYERS[id] end
    if record and record.score then
      layers[#layers + 1] = record.score
      view = view or { battle = battle, user = battler, target = battle.player,
                       data = battle.data, rng = rng,
                       encourageTurn = encourageTurn }
    end
  end

  -- AIEnemyTrainerChooseMoves (engine/battle/trainer_ai.asm:3-257): every
  -- usable move starts at a base score of 10; the class's modification
  -- functions adjust it additively, then the MINIMUM-scored move is chosen
  -- with ties broken uniformly among the minima (core.asm:2971-3002 rolls a
  -- fresh byte among the value-1 slots).  A non-minimal move is never
  -- selectable.
  local scores = {}
  for i, mv in ipairs(usable) do
    local def = battle.data.moves[mv.id]
    local s = 10
    for _, score in ipairs(layers) do
      s = score(view, def, s) or s
    end
    scores[i] = s
  end
  local best = math.huge
  for _, s in ipairs(scores) do
    if s < best then best = s end
  end
  local minima = {}
  for i, s in ipairs(scores) do
    if s == best then minima[#minima + 1] = usable[i] end
  end
  if #minima == 1 then return minima[1] end
  return minima[rng(1, #minima)]
end

return TrainerAI
