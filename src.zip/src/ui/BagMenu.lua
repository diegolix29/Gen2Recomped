-- The bag: lists inventory, uses items via ItemEffects.
-- opts.battle = BattleState when opened mid-battle (balls throwable,
-- using an item consumes the turn).

local ItemEffects = require("src.inventory.ItemEffects")
local ListMenu = require("src.ui.ListMenu")
local TextBox = require("src.render.TextBox")
local Font = require("src.render.Font")

local BagMenu = {}

local Bag = require("src.inventory.Bag")
local Strings = require("src.core.Strings")

-- The money line under the bag, with the cartridge's own sign -- Kanto's
-- U+00A5 is the JAPANESE YEN KANJI in Platinum's font.  See
-- GameVersion.moneySign.
local function moneyLine(game)
  local sign = require("src.core.GameVersion").moneySign()
  return ("%s%d"):format(sign, (game.save or {}).money or 0)
end

-- Gen2's pack has four pages (engine/items/pack.asm): ITEM, BALL, KEY ITEM
-- and TM/HM, switched with LEFT/RIGHT.  The pocket lives on the item record
-- (ItemAttributes byte 5); a cache from before that was extracted -- and
-- every Gen1 item -- is classified from the fields the port already has, so
-- the page split degrades to something sensible rather than emptying.
local POCKETS = {
  { key = "ITEM", title = "ITEMS" },
  { key = "BALL", title = "BALLS" },
  { key = "KEY_ITEM", title = "KEY ITEMS" },
  { key = "TM_HM", title = "TM/HM" },
}

local function pocketOf(def, id)
  if def and def.pocket then return def.pocket end
  if def and def.machine then return "TM_HM" end
  if def and def.ball then return "BALL" end
  if def and def.keyItem then return "KEY_ITEM" end
  if type(id) == "string" and (id:find("^TM_") or id:find("^HM_")) then
    return "TM_HM"
  end
  return "ITEM"
end

-- acquisition order like wBagItems (Bag.order), not alphabetical
local function buildItems(game, pocket)
  local items = {}
  for _, id in ipairs(Bag.order(game.save)) do
    local def = game.data.items[id]
    if not pocket or pocketOf(def, id) == pocket then
      table.insert(items, {
        value = id,
        label = def and def.name or id,
        right = "x" .. game.save.inventory[id],
      })
    end
  end
  return items
end

local function consume(game, id)
  Bag.remove(game.save, id, 1)
end

local function save_name(game)
  return game.save.player.name
end

local function showMessages(game, msgs, onDone)
  if not msgs or #msgs == 0 then
    if onDone then onDone() end
    return
  end
  game.stack:push(TextBox.new(game, table.concat(msgs, "\f"), onDone))
end

-- FireRed's Rare Candy result window lives on the party screen and has two
-- pages: first the six stat gains, then the six resulting values.  The source
-- window is sLevelUpStatsWindowTemplate at (19,1), 10x11 tiles with a standard
-- frame around it (party_menu.c / pokemon_special_anim_scene.c).
local Gen3LevelUpStats = {}
Gen3LevelUpStats.__index = Gen3LevelUpStats

function Gen3LevelUpStats.new(game, beforeStats, afterStats, onDone)
  return setmetatable({ game = game, before = beforeStats or {},
                        after = afterStats or {}, page = 1,
                        onDone = onDone }, Gen3LevelUpStats)
end

function Gen3LevelUpStats:uiSize() return 240, 160 end
function Gen3LevelUpStats:wantsFillScale() return true end

function Gen3LevelUpStats:update()
  local input = self.game.input
  if not (input:wasPressed("a") or input:wasPressed("b")) then return end
  pcall(function() require("src.core.Sound").play(self.game.data, "Press_AB") end)
  if self.page == 1 then
    self.page = 2
    return
  end
  self.game.stack:pop()
  if self.onDone then self.onDone() end
end

function Gen3LevelUpStats:draw()
  -- AddWindow is 10x11 interior tiles at (19,1); DrawStdFrame adds the one-tile
  -- border, reaching exactly to the GBA screen's right edge.
  Font.drawBox(18, 0, 12, 13)
  love.graphics.setColor(0, 0, 0, 1)
  local rows = {
    { "MAX. HP", "hp" }, { "ATTACK", "attack" },
    { "DEFENSE", "defense" }, { "SP. ATK", "spatk" },
    { "SP. DEF", "spdef" }, { "SPEED", "speed" },
  }
  for i, row in ipairs(rows) do
    local y = 8 + (i - 1) * 15
    Font.draw(row[1], 152, y)
    local after = tonumber(self.after[row[2]]) or 0
    local value
    if self.page == 1 then
      local before = tonumber(self.before[row[2]]) or 0
      local diff = after - before
      value = (diff >= 0 and "+" or "-") .. tostring(math.abs(diff))
    else
      value = tostring(after)
    end
    Font.draw(value, 224 - Font.width(value), y)
  end
  love.graphics.setColor(1, 1, 1, 1)
end

-- HOW MANY ARE LEFT, ON WHATEVER SCREEN ASKED.
--
-- Reported from play as a blue screen: "bad argument #1 to 'ipairs' (table
-- expected, got nil)" the moment a POTION was used from Hoenn's bag.  This
-- flow is shared -- useItem is published precisely so the Gen 3 bag does not
-- carry a second copy of what a POTION MEANS -- and its contract said `list`
-- only has to answer close().  One place broke that contract: the count
-- refresh reached straight into `list.items`, which is Gen 1/2's ListMenu row
-- array, and Emerald's bag is a different screen with no such field.
--
-- THE PCALL AROUND THE CALL DID NOT CATCH IT, and could not: Gen3BagMenu:act
-- wraps useItem, but the throw happens later, inside the party picker's
-- onSwitch, after act has returned.  Wrapping it wider would have hidden the
-- bug rather than fixed it -- what is wrong is the contract, so the contract
-- is what this widens: a screen answers close(), and refreshes itself either
-- by carrying `items` rows or by answering rebuild().
local function refreshCount(game, list, id)
  if not list then return end
  if type(list.items) == "table" then
    for i, it in ipairs(list.items) do
      if it.value == id then
        local left = game.save.inventory[id]
        if left then it.right = "x" .. left else table.remove(list.items, i) end
        break
      end
    end
    list.index = math.min(list.index or 1, math.max(1, #list.items))
    return
  end
  if type(list.rebuild) == "function" then pcall(list.rebuild, list) end
end

-- published so the suite can drive the seam itself: the throw this replaced
-- happened inside a party picker's callback, which no test can reach by
-- calling useItem and waiting
BagMenu.refreshCount = refreshCount

-- run the use-flow for an item on a chosen target.  `picker` is the party
-- menu when it was opened with keepOpen (HP medicine only): it is still on
-- the stack, so every exit that prints has to close it afterwards.  For
-- every other item the picker popped itself first and closePicker's identity
-- check makes it a no-op (#252).
local function useOn(game, battle, id, target, list, moveIndex, picker)
  local result, payload, extra = ItemEffects.use(game.data, game.save, id, target,
                                                 battle, moveIndex, game.overworld)
  local function closePicker()
    if picker then picker:close() end
  end

  -- field POKé FLUTE: play the tune, then the no-effect text
  if result == "flute_field" then
    require("src.core.Sound").play(game.data, "Pokeflute")
    showMessages(game, payload)
    return
  end

  -- field POKé FLUTE next to a not-yet-beaten Snorlax: "had effect" text,
  -- then the woke-up/battle sequence (data/scripts/story.lua snorlaxWake)
  if result == "flute_wake" then
    list:close()
    require("src.core.Sound").play(game.data, "Pokeflute")
    showMessages(game, payload, function()
      local ow = game.overworld
      local mod = ow and require("data.scripts.init").get(extra.mapId)
      if ow and mod and mod.snorlaxWake then
        ow.runner:run(mod.snorlaxWake.script, { npc = extra.npc })
      end
    end)
    return
  end

  if result == "vs_seeker" then
    list:close()
    local outcome, count = require("src.world.VsSeeker").use(game.data, game.save,
                                                               game.overworld)
    if outcome == "charging" then
      showMessages(game, { Strings("The V.S. SEEKER's\nBATTERY isn't charged.\nIt needs %d more steps.", count) })
    elseif outcome == "no_trainers" then
      showMessages(game, { Strings("There are no TRAINERS\nwithin range.") })
    elseif outcome == "none" then
      showMessages(game, { Strings("The TRAINERS are\nnot ready to battle.") })
    else
      require("src.core.Sound").play(game.data, "Press_AB")
      showMessages(game, { Strings("The V.S. SEEKER\nfound %d TRAINER%s ready!", count,
        count == 1 and "" or "S") })
    end
    return
  end

  if result == "consumed_escape" then -- Poké Doll
    consume(game, id)
    list:close()
    showMessages(game, payload, function()
      -- ItemUsePokeDoll sets wEscapedFromBattle and never touches
      -- wBattleResult, so a script that reads the result afterwards sees
      -- 0 -- "defeated". The ghost MAROWAK's script keys on exactly that
      -- (the Poke Doll trick); the flag lets it tell this escape from an
      -- ordinary RUN, which writes $2.
      battle.pokeDollEscape = true
      battle.result = "run"
      battle.afterQueue = "finish"
      battle.phase = "messages"
    end)
    return
  end

  -- THE EXPLORER KIT: down to the Underground, and back up again.
  --
  -- Both of the cartridge's entry points do the same one thing --
  -- UseExplorerKitFromMenu and UseExplorerKitInField each build a
  -- MapChangeUndergroundContext and run FieldTask_MapChangeToUnderground -- so
  -- there is one arm here and not two.
  --
  -- THE ORDER OF THESE TWO TESTS MATTERS. `canUse` refuses underground, on
  -- purpose, because CanUseExplorerKit does: it reads the map label and the
  -- Underground's is "Mystery Zone". So "am I down there already?" has to be
  -- asked first, or climbing out would be answered with the refusal for being
  -- down there.
  if result == "explorer_kit" then
    local Underground = require("src.world.Gen4Underground")
    local ow = game.overworld
    if Underground.isUnderground(ow) then
      list:close()
      local up, why = Underground.leave(game, ow)
      -- A refusal here is not cosmetic: it means nothing recorded where the
      -- player came down, and saying so beats a silent no-op in a place with
      -- no other way out.
      if not up then
        require("src.core.Logger").warn(
          "explorer kit: could not leave the Underground -- %s", tostring(why))
      end
      return
    end
    local can, why = Underground.canUse(game, ow)
    if not can then
      -- STAND-IN WORDING. The cartridge prints
      -- CommonStrings_Text_CantDoThatRightNow from TEXT_BANK_COMMON_STRINGS
      -- with the player's name substituted (BagContext_FormatErrorMessage, the
      -- `default` arm). That bank is not in this dataset -- searched, not
      -- assumed -- so this is a paraphrase of the string's own name and should
      -- be replaced by the real line the moment the bank is joined. The reason
      -- goes to the log rather than the screen, because the cartridge gives the
      -- player one generic refusal for all eight causes.
      require("src.core.Logger").info("explorer kit refused: %s", tostring(why))
      showMessages(game, { Strings("%s!\nYou can't do that right now.",
                                   game.save.player.name) })
      return
    end
    list:close()
    Underground.enter(game, ow)
    return
  end
  if result == "bicycle" then
    -- StartMenu_Item .useOrTossItem (engine/menus/start_sub_menus.asm):
    -- while BIT_ALWAYS_ON_BIKE of wStatusFlags6 is set -- the Cycling Road,
    -- armed by the forced-bike tiles and cleared by the Route 16/18 gate
    -- scripts -- the BICYCLE refuses with _CannotGetOffHereText and jumps
    -- back to ItemMenuLoop, so the bag stays open and no dismount happens
    -- (#513).  The gate sits ahead of UseItem, before ItemUseBicycle ever
    -- runs, which is why it precedes list:close() here.
    if game.save.forcedBike then
      showMessages(game, { Strings("You can't get off\nhere.") })
      return
    end
    list:close()
    local ow = game.overworld
    local Music = require("src.core.Music")
    -- IsBikeRidingAllowed (home/overworld.asm) for Gen1, BikeFunction
    -- .CheckEnvironment for Gen2; the overworld owns both rules.
    local function bikeAllowed()
      return ow and ow:bikeAllowed(ow.map.id) or false
    end
    -- WHICH BIKE.  Hoenn has two and they ride differently: the Mach Bike
    -- climbs muddy slopes at speed, and the Acro Bike hops and wheelies over
    -- the five behaviours Collision already knows about but nothing ever
    -- gave it a rider for.  Kanto's single BICYCLE passes nil and rides as
    -- neither, which is exactly what it did before.
    if game.save.onBike then
      game.save.onBike = false
      game.save.bikeKind = nil
      Music.playMap(game.data, ow and ow.map.id, false)
      showMessages(game, { Strings("%s got off\nthe BICYCLE.", save_name(game)) })
    elseif bikeAllowed() then
      game.save.onBike = true
      game.save.bikeKind = payload
      Music.playMap(game.data, ow.map.id, true)
      showMessages(game, { Strings("%s got on\nthe BICYCLE!", save_name(game)) })
    else
      showMessages(game, { Strings("No cycling\nallowed here.") })
    end
    return
  end

  if result == "fish" then
    list:close()
    local ow = game.overworld
    local p = ow and ow.player
    if ow and p then
      local fx, fy = p:facingCell()
      if ow.map:inBounds(fx, fy) and ow.map:isWaterCell(fx, fy) then
        ow:goFishing(id)
        return
      end
    end
    showMessages(game, { Strings("No good! It's not\neven near water.") })
    return
  end

  if result == "ball" then
    if not battle then
      showMessages(game, { Strings("OAK: %s!\nThis isn't the\ntime to use that!",
                              game.save.player.name) })
      return
    end
    consume(game, id)
    list:close()
    -- Catching/AnimPlayer key off the Gen1 ball ids
    battle:throwBall(ItemEffects.alias(id, game.data.items[id]))
    return
  end

  if result == "learn" or result == "learnkept" then
    local moveId = payload
    local mdef = game.data.moves[moveId]
    local function teach()
      -- PIKAHAPPY_USEDTMHM on a successful teach (item_effects.asm:2500)
      local function taught()
        require("src.world.PikachuFollower")
          .modifyHappiness(game.save, "USEDTMHM", target)
      end
      if #target.moves < 4 then
        table.insert(target.moves, { id = moveId, pp = mdef.pp })
        showMessages(game, { Strings("%s learned\n%s!", target.nickname or
          game.data.pokemon[target.species].name, mdef.name) })
        if result == "learn" then consume(game, id) end
        taught()
      else
        require("src.ui.Screens").push(game, "MoveLearnMenu", target, moveId,
          function(learned)
            if learned and result == "learn" then consume(game, id) end
            if learned then taught() end
          end)
      end
    end
    list:close()
    teach()
    return
  end

  -- the TOWN MAP screen (engine/menus/town_map.asm)
  if result == "townmap" then
    -- KANTO AND HOENN HAVE THEIR OWN MAP, AND IT IS NOT THIS ONE.
    --
    -- Reported from play with a screenshot: using the TOWN MAP in FireRed put
    -- up the Game Boy screen, and because a Gen 3 cache carries none of the
    -- Game Boy town-map art that screen fell through to its LIST layout --
    -- a banner and six rows reading MAP G03 N07, MAP G03 N08, MAP G03 N09.
    --
    -- The right screen was already built and already had its data: the wall
    -- map in a Pokemon Centre opens it through openRegionMap, which picks
    -- Hoenn's rectangles or FireRed's own cartridge grid.  The bag simply
    -- never asked.  It asks first now, and keeps the Game Boy screen as the
    -- fallback for the generations that own it.
    local ow = game and game.overworld
    if ow and ow.openRegionMap and ow:openRegionMap() then return end
    local ok = pcall(function()
      require("src.ui.Screens").push(game, "TownMap")
    end)
    if not ok then
      showMessages(game, { Strings("The TOWN MAP is\nunreadable here.") })
    end
    return
  end

  -- THE POKeBLOCK CASE.  Forty slots, and the screen that feeds them is the
  -- only thing in this port that moves a Pokemon's condition.
  if result == "pokeblock_case" then
    local ok = pcall(function()
      require("src.ui.Screens").push(game, "Gen3PokeblockCase", {})
    end)
    if not ok then
      showMessages(game, { Strings("The CASE won't open.") })
    end
    return
  end

  -- FireRed's TEACHY TV (teachy_tv.c).  It owns a full-screen tutorial menu,
  -- so close the bag first just as the cartridge fades out of ItemMenu.
  if result == "teachy_tv" then
    if list and list.close then list:close() end
    local ok = pcall(function()
      require("src.ui.Screens").push(game, "Gen3TeachyTV", {})
    end)
    if not ok then
      showMessages(game, { Strings("The TEACHY TV\nwon't turn on.") })
    end
    return
  end

  -- ITEMFINDER (engine/items/itemfinder.asm): responds if the current
  -- map still has an unfound hidden item
  if result == "itemfinder" then
    local ow = game.overworld
    local t = game.data.text
    if ow and ow:hasHiddenItemLeft() then
      showMessages(game, { t._ItemfinderFoundItemText
        or Strings("Yes! ITEMFINDER\nindicates there's\nan item nearby.") })
    else
      showMessages(game, { t._ItemfinderFoundNothingText
        or Strings("Nope! ITEMFINDER\nisn't responding.") })
    end
    return
  end

  -- POKé FLUTE in battle: not consumed, but uses the turn
  if result == "flute" then
    list:close()
    require("src.core.Sound").play(game.data, "Pokeflute")
    showMessages(game, payload, function() battle:itemUsed({}) end)
    return
  end

  if result == "escape_rope" then
    -- GEN 1 (ItemUseEscapeRope): only inside the dungeon tilesets
    -- (escape_rope_tilesets.asm), never in Agatha's room, and it sets
    -- BIT_ESCAPE_WARP so special_warps.asm warps to wLastBlackoutMap
    -- -- the last Pokémon Center town, same as Dig/Teleport (NOT the
    -- spot you entered the dungeon from).
    -- GEN 2 is a different item: see the escapePoint branch below.
    local ESCAPE_ROPE_TILESETS = { FOREST = true, CEMETERY = true,
                                   CAVERN = true, FACILITY = true,
                                   INTERIOR = true }
    -- Gen2 gates on the map header's environment byte instead
    -- (ENVIRONMENT_CAVE / ENVIRONMENT_DUNGEON, scripts/std_scripts.asm)
    local GEN2_ESCAPE_ROPE_ENVIRONMENTS = { [4] = true, [7] = true }
    -- GEN 3 SAYS IT IN THE MAP HEADER, one bit, and nothing read it.
    --
    -- The two tables above are Kanto's tileset names and Johto's environment
    -- bytes.  Hoenn has neither, so the gate below matched nothing on every
    -- one of the region's 518 maps and the ESCAPE ROPE could not be used
    -- anywhere -- in a cave, in Victory Road, in the Aqua Hideout, nowhere.
    -- The cartridge keeps it in the map header's flag byte
    -- (`allowEscaping`, alongside allowRunning and allowCycling, which are
    -- both already read), and it means Escape Rope, Dig and Teleport alike.
    local ow = game.overworld
    local gen3 = require("src.core.GameVersion").isGen3()
    local allowed
    if gen3 then
      allowed = ow and ow.map and ow.map.def and ow.map.def.allowEscaping == true
    else
      allowed = ow and (ESCAPE_ROPE_TILESETS[ow.map.def.tileset]
        or GEN2_ESCAPE_ROPE_ENVIRONMENTS[ow.map.def.environment])
    end
    -- Gen 2 does NOT share Gen 1's destination.  .DoDig copies wDigWarpNumber
    -- into wNextWarp, so the rope puts you back out through the entrance you
    -- came in by -- the cave mouth or the door -- not the last Pokemon Center.
    -- .CheckCanDig refuses when no entrance has been recorded, so an unreached
    -- dig warp is a "can't use that here", not a silent teleport somewhere
    -- else.
    local gen2 = require("src.core.GameVersion").generation() == 2
    local escapePoint = gen2 and ow and ow.escapePoint and ow:escapePoint()
    if gen2 and allowed and not escapePoint then allowed = false end

    if allowed and ow.map.id ~= "AGATHAS_ROOM" then
      list:close()
      consume(game, id)
      -- ESCAPE, carved on the Kabuto chamber wall, is an instruction.  The
      -- cartridge farcalls SpecialKabutoChamber on exactly this branch, before
      -- queueing the used-the-rope script (engine/events/overworld.asm:809);
      -- the chamber's own scene script plays the wall opening the next time
      -- the map loads.
      require("src.script.RuinsOfAlph").kabutoChamber(game)
      -- LeaveMapAnim spin-up + SFX_TELEPORT_EXIT_1, then a fade -- the shared
      -- departure helper Dig/Teleport also use.  Where it lands is the
      -- generation's business: Gen 1 the last Pokémon Center town door like
      -- Fly (#196), Gen 2 the recorded entrance.
      ow:beginTeleportOut(nil, { escape = escapePoint and true or nil })
    else
      showMessages(game, { Strings(
        "OAK: %s!\nThis isn't the\ntime to use that!",
        game.save.player.name) })
    end
    return
  end

  if result == "consumed" then
    consume(game, id)
    if extra and extra.evolveTo then
      list:close()
      local Evolution = require("src.pokemon.Evolution")
      Evolution.evolve(game, target, extra.evolveTo)
      return
    end
    -- RARE CANDY: after the level text, the stat window, any level-up
    -- moves and a level evolution follow (item_effects.asm .useRareCandy
    -- runs PrintStatsBox, LearnMoveFromLevelUp and TryEvolvingMon)
    if extra and extra.leveledTo and target then
      local GameVersion = require("src.core.GameVersion")
      local gen3Candy = GameVersion.get() == "firered" and picker ~= nil
      -- FireRed keeps the item-target party screen underneath the level-up
      -- message and stat window.  Older generations keep their existing flow.
      if gen3Candy then refreshCount(game, list, id) else list:close() end
      showMessages(game, payload, function()
        local function afterStats()
          local Experience = require("src.battle.Experience")
          local def = game.data.pokemon[target.species]
          local moves = Experience.movesLearnedAt(def, extra.leveledTo)
          local i = 0
          local function nextStep()
            i = i + 1
            local moveId = moves[i]
            if not moveId then
              local Evolution = require("src.pokemon.Evolution")
              local evoTo, evo = Evolution.pendingFor(game, target,
                                                     { kind = "levelup" })
              if gen3Candy and picker then picker:close() end
              if evoTo then
                Evolution.evolve(game, target, evoTo, nil, evo and evo.method)
              end
              return
            end
            for _, mv in ipairs(target.moves) do
              if mv.id == moveId then return nextStep() end
            end
            local mdef = game.data.moves[moveId]
            if #target.moves < 4 then
              table.insert(target.moves, { id = moveId, pp = mdef.pp })
              local name = target.nickname or def.name
              showMessages(game, { Strings("%s learned\n%s!", name, mdef.name) },
                           nextStep)
            else
              require("src.ui.Screens").push(game, "MoveLearnMenu",
                                             target, moveId, nextStep)
            end
          end
          nextStep()
        end
        if gen3Candy then
          game.stack:push(Gen3LevelUpStats.new(game, extra.beforeStats,
                                               extra.afterStats, afterStats))
        else
          local StatBox = require("src.battle.BattleState").StatBox
          game.stack:push(StatBox.new(game, target, afterStats))
        end
      end)
      return
    end
    -- refresh counts on whichever screen asked
    refreshCount(game, list, id)
    -- HP medicine: fill the bar in the still-open picker first, then print
    -- and close, the order item_effects.asm .doneHealing runs in
    -- (SFX_HEAL_HP -> UpdateHPBar2 -> RedrawPartyMenu prints the message).
    -- Only a keepOpen picker is still on the stack to animate: every other
    -- item, and every in-battle use, popped it in PartyMenu before onSwitch,
    -- and takes the pop-then-print path below -- which is the path that
    -- spends the battle turn.  #252, #379
    -- ...AND ONLY A PICKER THAT CAN ANIMATE IS ASKED TO.
    --
    -- This screen is whichever party picker the generation opened, and it
    -- took `animateTo` on faith: Hoenn's opens Gen3PartyMenu, which had no
    -- such method, and every out-of-battle potion in the game crashed here.
    -- Gen3PartyMenu has one now -- but the message must print either way, so
    -- a picker that cannot animate falls through to the plain path rather
    -- than taking the game down with it.
    if picker and picker.keepOpen and extra and extra.healedFrom and target
       and type(picker.animateTo) == "function" then
      picker:animateTo(target, extra.healedFrom, function()
        showMessages(game, payload, closePicker)
      end)
      return
    end
    if battle then
      list:close()
      showMessages(game, payload, function() battle:itemUsed({}) end)
    else
      showMessages(game, payload, closePicker)
    end
    return
  end

  -- .healingItemNoEffect prints over the still-drawn party menu too, so the
  -- refusal closes the picker the same way (#252)
  showMessages(game, payload, closePicker) -- failed
end

local function pickTargetAndUse(game, battle, id, list)
  -- pick a target from the party
  -- the ETHERs and PP UP open the move menu after picking a mon
  -- (ItemUsePPRestore / ItemUsePPUp); the ELIXERs hit every move
  local def = game.data.items[id]
  local key = ItemEffects.alias(id, def)
  local wantsMove = key == "ETHER" or key == "MAX_ETHER" or key == "PP_UP"
  local opts = {
    pickOnly = true,
    -- HP medicine animates its bar with the picker still up (#252).  Only
    -- out of battle: the in-battle tail closes the bag list underneath
    -- first, which needs the picker already gone.
    keepOpen = (not battle) and (ItemEffects.healsHP(id)
      or (id == "RARE_CANDY"
          and require("src.core.GameVersion").get() == "firered")),
    onSwitch = function(mon, picker)
      if not wantsMove then
        useOn(game, battle, id, mon, list, nil, picker)
        return
      end
      local rows = {}
      for mi, mv in ipairs(mon.moves) do
        local mdef = game.data.moves[mv.id]
        table.insert(rows, {
          value = mi,
          label = mdef and mdef.name or mv.id,
          right = ("%d"):format(mv.pp),
        })
      end
      -- WHICH MOVE, ON WHICHEVER CARTRIDGE IS LOADED.
      --
      -- ListMenu paints the Game Boy's 160x144 white page, so an ETHER used
      -- in Hoenn or Kanto opened a Gen 1 screen mid-way through a Gen 3 item
      -- flow -- the same leak the PC's item storage had.  There is no ripped
      -- move-picker window to reuse here, but `Menu` is bordered with the
      -- CARTRIDGE'S own nine-slice (Font.drawBox reads the extracted
      -- sWindowFrames), so on Gen 3 it is that frame and that font rather
      -- than the Game Boy's page.  PP rides in the label, which is where a
      -- one-column window has to put it.
      local okV, V = pcall(require, "src.core.GameVersion")
      if okV and V.isGen3() then
        local items = {}
        for _, row in ipairs(rows) do
          items[#items + 1] = {
            label = ("%s  %s"):format(row.label, row.right),
            onSelect = function()
              useOn(game, battle, id, mon, list, row.value)
            end,
          }
        end
        local picker = require("src.ui.Menu").new(game, items,
                                                  { tx = 0, ty = 0, tw = 16 })
        function picker:uiSize() return 240, 160 end
        game.stack:push(picker)
        return
      end
      game.stack:push(ListMenu.new(game, "Which move?", rows, {
        onChoose = function(row, l)
          l:close()
          useOn(game, battle, id, mon, list, row.value)
        end,
      }))
    end,
  }
  -- TM/HM: open the party menu in Gen 1's TM/HM display mode so each mon
  -- shows ABLE / NOT ABLE from its learnset and the prompt reads "Use TM on
  -- which POKeMON?" (engine/items/item_effects.asm ItemUseTMHM ->
  -- party_menu.asm TM/HM type). Stones and other pickOnly items keep the
  -- plain HP layout (Gen 1 shows no ABLE/NOT ABLE for them), so gate
  -- strictly on def.machine. #210
  if def and def.machine then
    opts.tmhm = { move = def.machine.move, kind = def.machine.kind }
  end
  require("src.ui.Screens").push(game, "PartyMenu", opts)
end

local function useItem(game, battle, id, list)
  local def = game.data.items[id]
  -- ItemUseTMHM checks wIsInBattle before BootedUpTMText
  if battle and def and def.machine then
    local _, payload = ItemEffects.use(game.data, game.save, id, nil, battle)
    showMessages(game, payload)
    return
  end
  if ItemEffects.needsTarget(id, def) and not ItemEffects.isBall(id) then
    -- TMs/HMs boot up and announce their move before the target picker
    -- (ItemUseTMHM: BootedUpTMText / BootedUpHMText + TeachMachineMoveText)
    if def and def.machine then
      local moveDef = game.data.moves[def.machine.move]
      local moveName = moveDef and moveDef.name or def.machine.move
      -- HOENN SAYS IT DIFFERENTLY, and asks.  Emerald's machine flow is
      -- "Booted up a TM." / "It contained {MOVE}." and then a question --
      -- "Teach {MOVE} to a POKeMON?" -- which the party picker only follows
      -- on a yes.  Both lines and the question are the cartridge's own
      -- (constants.gen3ItemText), so this is Hoenn's wording rather than
      -- Johto's with the exclamation marks filed off.
      local cart = (game.data.constants or {}).gen3ItemText
      if cart and type(cart.contained) == "string" then
        local asks = cart.contained:gsub("{VAR1}", moveName)
                                   :gsub("{STR_VAR1}", moveName)
        local booted = (def.machine.kind == "HM" and cart.bootedHM)
                       or cart.bootedTM
        local TextBox2 = require("src.render.TextBox")
        local function ask()
          -- `choice` IS THE CALLBACK, not a flag that turns one on.  Handed
          -- a boolean, TextBox reaches the yes/no answer and calls `true`,
          -- which is where "Teach {MOVE} to a POKeMON?" died.
          game.stack:push(TextBox2.new(game, asks, nil, {
            choice = function(yes)
              if yes then pickTargetAndUse(game, battle, id, list) end
            end,
          }))
        end
        if booted then showMessages(game, { booted }, ask) else ask() end
        return
      end
      local booted = def.machine.kind == "HM"
        and "Booted up an HM!" or Strings("Booted up a TM!")
      showMessages(game, { booted, Strings("It contained\n%s!", moveName) },
        function() pickTargetAndUse(game, battle, id, list) end)
      return
    end
    pickTargetAndUse(game, battle, id, list)
  else
    useOn(game, battle, id, nil, list)
  end
end

-- PUBLISHED, so the Gen 3 bag can use an item without carrying a second
-- copy of what using one MEANS.  Emerald's bag is a different SCREEN --
-- five pockets, a description panel, its own art -- but a POTION does the
-- same thing in Hoenn as in Johto, and the two screens disagreeing about
-- that is the bug this seam exists to prevent.
--
-- WHAT A SCREEN HAS TO ANSWER: close(), and -- if it wants its own row for
-- the item to show the new count -- either an `items` row array or
-- rebuild().  A screen that answers neither still works; its list simply
-- keeps the count it was drawn with until it is rebuilt.
BagMenu.useItem = useItem

-- GSC's GiveItem: pick a party mon, then hand it the item.  A mon that is
-- already holding something is offered the swap (TryGiveItemToMon).
-- TryGiveItemToMon: hand `id` to `mon`, offering the swap when it is already
-- holding something.  Key items and mail stay in the pack.
local function handOver(game, mon, id, onChanged, opts)
  local def = game.data.items[id]
  local name = (def and def.name) or id
  local monName = mon.nickname
    or (game.data.pokemon[mon.species] or {}).name or "?"
  if require("src.pokemon.Party").isEgg(mon) then
    showMessages(game, { Strings("An EGG can't hold\nan item.") })
    return
  end
  if def and def.keyItem then
    showMessages(game, { Strings("%s can't be\nheld.", name) })
    return
  end
  local held = mon.item
  local function hand()
    local changed
    if opts and opts.giveHeld then
      changed = opts.giveHeld(mon, id)
    else
      require("src.inventory.Bag").giveHeld(game.save, mon, id, game.data)
      changed = true
    end
    if changed == false then
      showMessages(game, { Strings("No room left to\nstore items.") })
      return false
    end
    if onChanged then onChanged() end
    return true
  end
  if not held then
    if hand() then
      showMessages(game, { Strings("%s is now holding\n%s.", monName, name) })
    end
    return
  end
  local heldName = (game.data.items[held] or {}).name or held
  local ChoiceBox = require("src.ui.ChoiceBox")
  showMessages(game, {
    Strings("%s is already\nholding %s.", monName, heldName),
    Strings("Switch items?"),
  }, function()
    game.stack:push(ChoiceBox.new(game, function(yes)
      if not yes then return end
      if hand() then
        showMessages(game, { Strings("Took %s and\nmade it hold %s.",
          heldName, name) })
      end
    end))
  end)
end

-- PUBLISHED for the party screen's own GIVE, which asks the question the
-- other way round: Emerald's party menu picks the POKeMON first and then
-- opens the bag, and what happens when the pick lands is the same thing.
BagMenu.handOver = handOver

-- GSC's GiveItem (pack.asm): pick a party mon, then hand it the item.
local function giveItem(game, id, onChanged)
  require("src.ui.Screens").push(game, "PartyMenu", {
    pickOnly = true,
    onSwitch = function(mon) handOver(game, mon, id, onChanged) end,
  })
end

-- PUBLISHED for the same reason useItem is: Emerald's bag asks GIVE from its
-- own context menu, and handing an item to a party member means the same
-- thing in Hoenn as in Johto.
BagMenu.giveItem = giveItem

-- swap the two marked rows inside save.bagOrder by their item ids
local function swapRows(game, list)
  local a = list.items[list.swapIndex] and list.items[list.swapIndex].value
  local b = list.items[list.index] and list.items[list.index].value
  list.swapIndex = nil
  if not (a and b) or a == b then return end
  local order = Bag.order(game.save)
  local ia, ib
  for i, id in ipairs(order) do
    if id == a then ia = i end
    if id == b then ib = i end
  end
  if ia and ib then order[ia], order[ib] = order[ib], order[ia] end
end

-- _CGB_PackPals.PackPals (2:$596F): six palettes, then an attrmap that puts
-- 1 over the left half of the header row, 2 over the right half, 3 down the
-- cursor column, 4 on the pocket-name box and 5 on the pack picture.
local PACK_PALS = {
  { { 255, 255, 255 }, { 123, 123, 255 }, { 0, 0, 255 }, { 0, 0, 0 } },
  { { 255, 255, 255 }, { 123, 123, 255 }, { 0, 0, 255 }, { 0, 0, 0 } },
  { { 255, 90, 255 }, { 123, 123, 255 }, { 0, 0, 255 }, { 0, 0, 0 } },
  { { 255, 255, 255 }, { 123, 123, 255 }, { 0, 0, 255 }, { 255, 0, 0 } },
  { { 255, 255, 255 }, { 123, 123, 255 }, { 255, 0, 0 }, { 0, 0, 0 } },
  { { 255, 255, 255 }, { 58, 156, 58 }, { 58, 156, 58 }, { 0, 0, 0 } },
}

local function packPalettes()
  local P = require("src.render.PaletteFX")
  return {
    P.whole(PACK_PALS[1]),
    P.zone(PACK_PALS[2], 0, 0, 9, 0),
    P.zone(PACK_PALS[3], 10, 0, 19, 0),
    P.zone(PACK_PALS[4], 7, 2, 7, 10),
    P.zone(PACK_PALS[5], 0, 7, 4, 9),
    P.zone(PACK_PALS[6], 0, 3, 4, 5),
  }
end

function BagMenu.new(game, opts)
  opts = opts or {}
  local battle = opts.battle
  local list
  -- Gen2 pages the pack; Gen1's bag is one flat list (pocket = nil)
  local gen2 = require("src.core.GameVersion").isGen2()
  local pocketIndex = gen2 and (opts.pocketIndex or 1) or nil
  local function pocketKey()
    return pocketIndex and POCKETS[pocketIndex].key or nil
  end
  local function refresh(l)
    l.items = buildItems(game, pocketKey())
    l.index = math.min(l.index, math.max(1, #l.items))
    l.scroll = 0
  end
  list = ListMenu.new(game, pocketIndex and POCKETS[pocketIndex].title or "ITEMS",
    buildItems(game, pocketKey()), {
    kind = "bag",
    pocketIndex = pocketIndex and (pocketIndex - 1) or 0,
    onPocketSwitch = pocketIndex and function(l, delta)
      pocketIndex = ((pocketIndex - 1 + delta) % #POCKETS) + 1
      l.pocketIndex = pocketIndex - 1
      l.title = POCKETS[pocketIndex].title
      l.swapIndex = nil
      l.index = 1
      refresh(l)
      require("src.core.Sound").play(game.data, "Press_AB")
    end or nil,
    -- WHAT THE BOTTOM BOX SAYS.
    --
    -- Gen 1's bag has no description box; the money line is what it shows
    -- there.  Gen 2's PACK does, and it is the item's own description,
    -- repainted on every cursor move (UpdateItemDescription) -- so a money
    -- string here was not just the wrong content, it was the wrong KIND of
    -- content, and it never changed as the player scrolled.
    --
    -- A function of the highlighted row rather than a value, because what it
    -- says depends on where the cursor is (see ListMenu's footer resolve).
    --
    -- Falls back to the money line when the description is missing.  That is
    -- not defensive padding: `ItemDescriptions` was not extracted at all
    -- until now, so every cache imported before this carries none and would
    -- otherwise show an empty box on every row.  Re-importing fills them in.
    footer = gen2 and function(_, row)
      local def = row and row.value and game.data.items[row.value]
      local text = def and def.description
      if type(text) == "string" and text ~= "" then return text end
      return moneyLine(game)
    end or moneyLine(game),
    -- B returns to the start menu when the bag was opened from it
    onCancel = opts.onCancel,
    -- SELECT reorders items like the original bag (swap_items.asm).  A
    -- pocket page is a filtered view of Bag.order, so the swap is done by
    -- item id rather than by row number.
    onSelectKey = function(item, l)
      if not item then return end
      if not l.swapIndex then
        l.swapIndex = l.index
        return
      end
      swapRows(game, l)
      require("src.core.Sound").play(game.data, "Swap")
      refresh(l)
    end,
    onChoose = function(item)
      local id = item.value
      local def = game.data.items[id]
      if list.swapIndex then -- A also completes a pending swap
        swapRows(game, list)
        require("src.core.Sound").play(game.data, "Swap")
        refresh(list)
        return
      end
      if opts.giveTo then
        -- opened from MonMenu's ITEM -> GIVE: the pick hands straight over
        list:close()
        handOver(game, opts.giveTo, id, nil)
        return
      end
      if battle then -- no tossing mid-battle
        useItem(game, battle, id, list)
        return
      end
      -- USE / TOSS submenu (the original's item options).
      -- data/text_boxes.asm USE_TOSS_MENU_TEMPLATE: box (13,10)-(19,14),
      -- text at (15,11); start_sub_menus.asm then sets wTopMenuItemY/X to
      -- 11/14 for the cursor.  Menu's own geometry reproduces all of that
      -- from the box alone, so this needs opts rather than a change to the
      -- shared Menu.  The old 12/10/8/6 box was a column too wide and a row
      -- too tall, which left the labels stranded near its top edge (#284).
      --
      -- Gen 2 has held items, so pack.asm's .ItemBallsKey_LoadSubmenu picks
      -- one of six headers instead: USE only when the item does something,
      -- GIVE and TOSS only when it is not a key item, always QUIT.  Its box
      -- is on the LEFT (menu_coords 0, y, SCREEN_WIDTH - 14, TEXTBOX_Y - 1)
      -- and grows upward from the text box.
      local Menu = require("src.ui.Menu")
      -- HOENN HIDES IT TOO.  Emerald's bag leaves TOSS off the list for
      -- anything gItems[].importance calls important, exactly as Gen 2 does
      -- for a key item -- and the refusal inside onSelect below was already
      -- generation-agnostic, so the only thing wrong was that Gen 3 still
      -- OFFERED the option and then refused it.  Gen 1's bag really does
      -- offer TOSS on everything, so it keeps the old behaviour.
      local keyish = (not def) or def.keyItem
                     or ItemEffects.alias(id, def):find("^HM_") ~= nil
      local hidesToss = gen2 or require("src.core.GameVersion").isGen3()
      local tossable = not (hidesToss and keyish)
      local options = {
        { label = Strings("USE"), onSelect = function()
            useItem(game, battle, id, list)
          end },
      }
      if gen2 and tossable then
        options[#options + 1] = { label = Strings("GIVE"),
          onSelect = function()
            giveItem(game, id, function() refresh(list) end)
          end }
      end
      if tossable then
        options[#options + 1] = { label = Strings("TOSS"), onSelect = function()
            -- KeyItemFlags + HMs decide tossability (not price:
            -- MOON STONE is price 0 but tossable)
            if not def or def.keyItem
               or ItemEffects.alias(id, def):find("^HM_") then
              showMessages(game, { Strings("That's too impor-\ntant to toss!") })
              return
            end
            local QuantityBox = require("src.ui.QuantityBox")
            game.stack:push(QuantityBox.new(game, {
              max = game.save.inventory[id] or 1,
              onDone = function(qty)
                if not qty then return end
                local ChoiceBox = require("src.ui.ChoiceBox")
                game.stack:push(ChoiceBox.new(game, function(yes)
                  if not yes then return end
                  Bag.remove(game.save, id, qty)
                  refresh(list)
                  showMessages(game, { Strings("Threw away\n%s.", def and def.name or id) })
                end))
              end,
            }))
          end }
      end
      -- SEL: the property byte's CANT_SELECT bit is what Pack's
      -- .selectable branches read, so the six key items GSC lets you put on
      -- the SELECT button (BICYCLE, ITEMFINDER, the three rods) offer it and
      -- nothing else does.
      if gen2 and def and def.registerable then
        options[#options + 1] = { label = Strings("SEL"), onSelect = function()
            game.save.registeredItem = id
            require("src.core.Sound").play(game.data, "Press_AB")
            showMessages(game, { Strings("Registered the\n%s.",
              def.name or id) })
          end }
      end
      if gen2 then
        options[#options + 1] = { label = Strings("QUIT"), onSelect = function() end }
      end
      local th = #options * 2 + 1
      game.stack:push(Menu.new(game, options, gen2
        and { tx = 0, ty = 12 - th, tw = 7, th = th }
        or { tx = 13, ty = 10, tw = 7, th = th }))
    end,
  })
  if gen2 then list.sgbPalettes = packPalettes end
  return list
end

BagMenu.POCKETS = POCKETS
BagMenu.pocketOf = pocketOf

-- WHETHER AN ITEM MAY LIVE ON THE SELECT BUTTON, which the two cartridges
-- decide differently -- and the difference is why Hoenn's registration did
-- nothing.
--
-- GSC asks the ITEM: the property byte's CANT_SELECT bit names the six key
-- items you may put there (see the SEL row above), and the Gen 2 extractor
-- carries it as `registerable`.
--
-- EMERALD ASKS THE POCKET.  Its bag offers USE / REGISTER / CANCEL for the
-- whole KEY ITEMS pocket and per-item nothing, which is why Gen3BagMenu
-- already offers REGISTER off the pocket's own action list
-- (RomExtractorGen3:itemMenuActions) rather than off a flag.  No Hoenn item
-- carries `registerable` at all -- so asking for one here answered no for
-- every one of them, and the answer was not merely "nothing happened": the
-- line below CLEARS the registration on a no, so a Gen 3 save that reached
-- this would have quietly forgotten the item it had just registered.
function BagMenu.canRegister(game, id)
  local data = game and game.data
  local def = data and data.items and data.items[id]
  if not def then return false end
  local GameVersion = require("src.core.GameVersion")
  if GameVersion.isGen3() then
    -- ASKED OF HOENN'S OWN BAG, not answered here: its pocket names are the
    -- cartridge's and it folds them onto the engine's before it looks the
    -- action list up, and a second fold written out here is a second fold to
    -- keep in step.
    local ok, yes = pcall(function()
      return require("src.ui.Gen3BagMenu").canRegister(game, id)
    end)
    return (ok and yes) and true or false
  end
  return def.registerable and true or false
end

-- The SELECT button's registered item (home/menu.asm CheckRegisteredItem):
-- the pack never opens, so the use flow runs against a stub list.  A
-- registration the player no longer holds is dropped and nothing happens,
-- which is .CheckRegisteredNo.
function BagMenu.useRegistered(game)
  local id = game.save.registeredItem
  if not id then return false end
  if not BagMenu.canRegister(game, id) or not game.save.inventory[id] then
    -- SAID OUT LOUD, because the two ways this refuses look identical from
    -- the outside and both look like the button doing nothing: an item the
    -- player no longer carries, and an item this cartridge will not put on
    -- SELECT at all.  Three reports in a row on this button were each one
    -- log line away from being one.
    require("src.core.Logger").warn(
      "registered item %s dropped: carried=%s, may sit on SELECT=%s",
      tostring(id), tostring(game.save.inventory[id] ~= nil),
      tostring(BagMenu.canRegister(game, id)))
    game.save.registeredItem = nil
    return false
  end
  useItem(game, nil, id, { close = function() end, items = {}, index = 1 })
  return true
end

return BagMenu
